import 'package:raise/env/app_env_type.dart';
import 'package:raise/env/config_handler.dart';

Future<void> main() async {
  await handleConfig(AppEnvType.dev);
}
