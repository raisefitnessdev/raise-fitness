import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:raise/core/theme/colors/app_colors.dart';
import 'package:raise/core/theme/text/app_text_style.dart';

import '../constants/gaps.dart';

enum _AppTextButton {
  minPrimaryColor,
  minWhiteColor,
  minCustomColor,
  maxPrimaryColor,
  maxWhiteColor,
  maxCustomColor,
}

class AppTextButton extends StatelessWidget {
  const AppTextButton._(
      {super.key,
      required _AppTextButton appTextButton,
      required this.text,
      required this.enabled,
      this.onPressed,
      Color? bgColor,
      Color? borderColor,
      double? textSize,
      double? maxHeight,
      double? borderRadius,
      Gradient? gradient,
      dynamic icon,
      MainAxisAlignment? mainAlignment,
      Color? txtColor})
      : _appTextButton = appTextButton,
        _textColor = txtColor,
        _bgColor = bgColor,
        _borderColor = borderColor,
        _gradient = gradient,
        maxHeight = maxHeight ?? 55,
        _borderRadius = borderRadius,
        _icon = icon,
        _textSize = textSize,
        _mainAlignment = mainAlignment;

  final _AppTextButton _appTextButton;
  final String text;
  final bool enabled;
  final VoidCallback? onPressed;

  final Color? _bgColor;
  final Color? _borderColor;
  final Color? _textColor;
  final double? _textSize;
  final double? _borderRadius;
  final dynamic _icon;

  final Gradient? _gradient;

  final double minWidth = 100;
  final double maxWidth = double.maxFinite;

  final double minHeight = 40;
  final double maxHeight;
  final MainAxisAlignment? _mainAlignment;

  factory AppTextButton.minPrimary(
      {Key? key,
      required String text,
      bool enabled = true,
      VoidCallback? onPressed}) {
    return AppTextButton._(
      key: key,
      appTextButton: _AppTextButton.minPrimaryColor,
      text: text,
      enabled: enabled,
      onPressed: onPressed,
    );
  }

  factory AppTextButton.minWhite(
      {Key? key, required String text, VoidCallback? onPressed}) {
    return AppTextButton._(
      key: key,
      appTextButton: _AppTextButton.minWhiteColor,
      text: text,
      enabled: true,
      onPressed: onPressed,
    );
  }

  factory AppTextButton.maxPrimary(
      {Key? key,
      required String text,
      bool enabled = true,
      VoidCallback? onPressed}) {
    return AppTextButton._(
      key: key,
      appTextButton: _AppTextButton.maxPrimaryColor,
      text: text,
      enabled: enabled,
      onPressed: onPressed,
    );
  }

  factory AppTextButton.maxWhite(
      {Key? key, required String text, VoidCallback? onPressed}) {
    return AppTextButton._(
      key: key,
      appTextButton: _AppTextButton.maxWhiteColor,
      text: text,
      enabled: true,
      onPressed: onPressed,
    );
  }

  factory AppTextButton.minCustom({
    Key? key,
    required String text,
    required Color bgColor,
    required Color txtColor,
    Color? borderColor,
    VoidCallback? onPressed,
    double? textSize,
    double? maxHeight,
    Gradient? gradient,
    double? borderRadius,
    dynamic icon,
  }) {
    return AppTextButton._(
      key: key,
      appTextButton: _AppTextButton.minCustomColor,
      text: text,
      enabled: true,
      bgColor: bgColor,
      gradient: gradient,
      borderColor: borderColor,
      txtColor: txtColor,
      onPressed: onPressed,
      textSize: textSize,
      maxHeight: maxHeight,
      borderRadius: borderRadius,
      icon: icon,
    );
  }

  factory AppTextButton.maxCustom({
    Key? key,
    required String text,
    VoidCallback? onPressed,
    Color? bgColor,
    Color? borderColor,
    Color? txtColor,
    Gradient? gradient,
    double? textSize,
    double? maxHeight,
    double? borderRadius,
    dynamic icon,
    MainAxisAlignment? mainAlignment,
  }) {
    return AppTextButton._(
      key: key,
      appTextButton: _AppTextButton.maxCustomColor,
      text: text,
      enabled: true,
      bgColor: bgColor,
      borderColor: borderColor,
      borderRadius: borderRadius,
      gradient: gradient,
      txtColor: txtColor,
      onPressed: onPressed,
      textSize: textSize,
      maxHeight: maxHeight,
      icon: icon,
      mainAlignment: mainAlignment,
    );
  }

  @override
  Widget build(BuildContext context) {
    switch (_appTextButton) {
      case _AppTextButton.minPrimaryColor:
        return SizedBox(
          width: minWidth,
          height: minHeight,
          child: BouncingWidget(
            enable: enabled && onPressed != null,
            child: TextButton(
              style: Theme.of(context).textButtonTheme.style?.copyWith(
                    padding: WidgetStateProperty.all(EdgeInsets.zero),
                    foregroundColor: WidgetStateProperty.resolveWith(
                      (_) {
                        return AppColors.of(context).primary;
                      },
                    ),
                    backgroundColor: WidgetStateProperty.resolveWith(
                      (states) {
                        if (enabled) {
                          return AppColors.of(context).primary;
                        } else {
                          return AppColors.of(context).secondaryText;
                        }
                      },
                    ),
                  ),
              onPressed: onPressed,
              child: Text(
                text,
                style: AppTextStyle.s14_w600(
                  color: (enabled
                      ? AppColors.fixedColors.white
                      : AppColors.fixedColors.secondaryText),
                ),
              ),
            ),
          ),
        );

      case _AppTextButton.minWhiteColor:
        return SizedBox(
          width: minWidth,
          height: minHeight,
          child: BouncingWidget(
            enable: enabled && onPressed != null,
            child: TextButton(
              style: Theme.of(context).textButtonTheme.style?.copyWith(
                    padding: WidgetStateProperty.all(EdgeInsets.zero),
                    foregroundColor: WidgetStateProperty.resolveWith(
                      (_) {
                        return Colors.transparent;
                      },
                    ),
                    backgroundColor: WidgetStateProperty.resolveWith(
                      (states) {
                        return Colors.transparent;
                      },
                    ),
                  ),
              onPressed: onPressed,
              child: Text(
                text,
                style: AppTextStyle.s14_w500(
                  color: AppColors.of(context).darkTextColor,
                ),
              ),
            ),
          ),
        );

      case _AppTextButton.maxPrimaryColor:
        return SizedBox(
          width: maxWidth,
          height: maxHeight,
          child: BouncingWidget(
            enable: enabled && onPressed != null,
            child: TextButton(
              style: Theme.of(context).textButtonTheme.style?.copyWith(
                    padding: WidgetStateProperty.all(EdgeInsets.zero),
                    foregroundColor: WidgetStateProperty.resolveWith(
                      (_) {
                        return AppColors.of(context).primary;
                      },
                    ),
                    backgroundColor: WidgetStateProperty.resolveWith(
                      (states) {
                        if (enabled) {
                          return AppColors.of(context).primary;
                        } else {
                          return AppColors.of(context).secondaryText;
                        }
                      },
                    ),
                  ),
              onPressed: onPressed,
              child: Text(
                text,
                style: AppTextStyle.s16_w500(
                  color: (enabled
                      ? AppColors.fixedColors.white
                      : AppColors.fixedColors.secondaryText),
                ),
              ),
            ),
          ),
        );

      case _AppTextButton.maxWhiteColor:
        return SizedBox(
          width: maxWidth,
          height: maxHeight,
          child: BouncingWidget(
            enable: enabled && onPressed != null,
            child: TextButton(
              style: Theme.of(context).textButtonTheme.style?.copyWith(
                    padding: WidgetStateProperty.all(EdgeInsets.zero),
                    foregroundColor: WidgetStateProperty.resolveWith(
                      (_) {
                        return Colors.transparent;
                      },
                    ),
                    backgroundColor: WidgetStateProperty.resolveWith(
                      (states) {
                        return Colors.transparent;
                      },
                    ),
                  ),
              onPressed: onPressed,
              child: Text(
                text,
                style: AppTextStyle.s16_w500(
                  color: AppColors.of(context).secondaryText,
                ),
              ),
            ),
          ),
        );
      case _AppTextButton.minCustomColor:
        return SizedBox(
          width: minWidth,
          height: maxHeight,
          child: BouncingWidget(
            enable: enabled && onPressed != null,
            child: TextButton(
              style: Theme.of(context).textButtonTheme.style?.copyWith(
                    shape: WidgetStateProperty.all(RoundedRectangleBorder(
                        side: BorderSide(
                            color: _borderColor ?? Colors.transparent),
                        borderRadius:
                            BorderRadius.circular(_borderRadius ?? 16).r)),
                    padding: WidgetStateProperty.all(EdgeInsets.zero),
                    foregroundColor: WidgetStateProperty.resolveWith(
                      (_) {
                        return _bgColor;
                      },
                    ),
                    backgroundColor: WidgetStateProperty.resolveWith(
                      (states) {
                        if (enabled) {
                          return _bgColor;
                        } else {
                          return AppColors.of(context).black;
                        }
                      },
                    ),
                  ),
              onPressed: onPressed,
              child: Container(
                width: maxWidth,
                height: maxHeight,
                decoration: BoxDecoration(
                    border:
                        Border.all(color: _borderColor ?? Colors.transparent),
                    borderRadius: BorderRadius.circular(_borderRadius ?? 16).r,
                    gradient: _gradient),
                child: _icon != null
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          _icon.runtimeType == String
                              ? SvgPicture.asset(
                                  _icon,
                                  height: 20.r,
                                  width: 20.r,
                                  color: _textColor,
                                )
                              : Gaps.empty,
                          Gaps.hGap5,
                          Text(
                            text,
                            style: AppTextStyle.s14_w500(
                              color: _textColor!,
                            ).copyWith(fontSize: _textSize ?? 14),
                          ),
                          Gaps.hGap5,
                          _icon.runtimeType == IconData
                              ? Icon(
                                  _icon ?? Icons.arrow_forward_rounded,
                                  size: 20.r,
                                  color: _textColor,
                                )
                              : Gaps.empty,
                        ],
                      )
                    : Center(
                        child: Text(
                          text,
                          style: AppTextStyle.s14_w500(
                            color: _textColor!,
                          ).copyWith(fontSize: _textSize ?? 14),
                        ),
                      ),
              ),
            ),
          ),
        );
      case _AppTextButton.maxCustomColor:
        return SizedBox(
          width: maxWidth,
          height: maxHeight,
          child: BouncingWidget(
            enable: enabled && onPressed != null,
            child: TextButton(
              style: Theme.of(context).textButtonTheme.style?.copyWith(
                    shape: WidgetStateProperty.all(RoundedRectangleBorder(
                        side: BorderSide(
                            color: _borderColor ?? Colors.transparent),
                        borderRadius:
                            BorderRadius.circular(_borderRadius ?? 16).r)),
                    padding: WidgetStateProperty.all(EdgeInsets.zero),
                    foregroundColor: WidgetStateProperty.resolveWith(
                      (_) {
                        return _bgColor;
                      },
                    ),
                    backgroundColor: WidgetStateProperty.resolveWith(
                      (states) {
                        return _bgColor;
                      },
                    ),
                  ),
              onPressed: onPressed,
              child: Container(
                width: maxWidth,
                height: maxHeight,
                padding: _mainAlignment != null
                    ? const EdgeInsets.symmetric(horizontal: 14).r
                    : null,
                decoration: BoxDecoration(
                    border:
                        Border.all(color: _borderColor ?? Colors.transparent),
                    borderRadius: BorderRadius.circular(_borderRadius ?? 16).r,
                    gradient: _gradient),
                child: _icon != null
                    ? Row(
                        mainAxisAlignment:
                            _mainAlignment ?? MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          _icon.runtimeType == String
                              ? SvgPicture.asset(
                                  _icon,
                                  height: 20.r,
                                  width: 20.r,
                                  color: _textColor,
                                )
                              : Gaps.empty,
                          Gaps.hGap5,
                          Text(
                            text,
                            style: AppTextStyle.s14_w500(
                              color: _textColor!,
                            ).copyWith(fontSize: _textSize ?? 14),
                          ),
                          Gaps.hGap5,
                          _icon.runtimeType == IconData
                              ? Icon(
                                  _icon ?? Icons.arrow_forward_rounded,
                                  size: 20.r,
                                  color: _textColor,
                                )
                              : Gaps.empty,
                        ],
                      )
                    : Center(
                        child: Text(
                          text,
                          style: AppTextStyle.s14_w500(
                            color: _textColor!,
                          ).copyWith(fontSize: _textSize ?? 14),
                        ),
                      ),
              ),
            ),
          ),
        );
    }
  }
}

class BouncingWidget extends StatefulWidget {
  final Widget child;
  final bool enable;

  const BouncingWidget({
    super.key,
    required this.child,
    this.enable = true,
  });

  @override
  State<BouncingWidget> createState() => _BouncingWidgetState();
}

class _BouncingWidgetState extends State<BouncingWidget>
    with SingleTickerProviderStateMixin {
  late double _scale;
  late AnimationController _controller;

  @override
  void didUpdateWidget(BouncingWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.enable != widget.enable) {
      if (widget.enable) {
        // _controller.forward();
      } else {
        // _controller.reverse();
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 100,
      ),
      lowerBound: 0.0,
      upperBound: 0.03,
    )..drive(CurveTween(curve: Curves.elasticIn));
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _tapDown,
      onTapUp: _tapUp,
      onTapCancel: () {
        widget.enable ? _controller.reverse() : null;
      },
      child: AnimatedBuilder(
          animation: _controller,
          child: widget.child,
          builder: (_, child) {
            _scale = 1 - _controller.value;
            return Transform.scale(
              scale: _scale,
              child: child,
            );
          }),
    );
  }

  void _tapDown(TapDownDetails details) {
    widget.enable ? _controller.forward() : null;
  }

  void _tapUp(TapUpDetails details) {
    widget.enable ? _controller.reverse() : null;
  }
}
