import 'package:flutter/material.dart';
import 'package:raise/core/bloc/value_state_manager/value_state_manager_import.dart';
import 'package:raise/core/flutter-country-picker/lib/src/country.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';

import '../../../../core/constants/gaps.dart';
import '../../../../core/theme/text/app_text_style.dart';

class BuildCountryCode extends StatelessWidget {
  final ObsValue<Country?> bloc;
  final VoidCallback onTap;
  final Color? color;
  const BuildCountryCode({super.key, required this.bloc, required this.onTap, this.color});

  @override
  Widget build(BuildContext context) {
    return ObsValueConsumer(
      observable: bloc,
      builder: (context, state) {
        return GestureDetector(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  state?.flagEmoji ?? "",
                  style: AppTextStyle.s14_w400(color: context.colors.primary)
                      .copyWith(
                          // height: 1.5,
                          ),
                ),
                Gaps.hGap8,
                Text(
                  "+${state?.phoneCode ?? ""}",
                  style: AppTextStyle.s14_w400(color: color??context.colors.textColor)
                      .copyWith(
                          // height: 1.5,
                          ),
                ),
                // Gaps.hGap8,
                // SizedBox(
                //   height: 20,
                //   child: VerticalDivider(
                //     color: context.colors.textColor,
                //     thickness: 1,
                //     width: 0,
                //   ),
                // ),
              ],
            ),
          ),
        );
      },
    );
  }
}
