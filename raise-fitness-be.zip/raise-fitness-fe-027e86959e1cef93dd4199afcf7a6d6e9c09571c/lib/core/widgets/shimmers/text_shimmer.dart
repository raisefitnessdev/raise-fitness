import 'dart:math';

import 'package:flutter/material.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/widgets/shimmers/base_shimmer_widget.dart';

class TextShimmer extends StatelessWidget {
  final double lineWidthPercent;
  final MainAxisAlignment? mainAxisAlignment;

  const TextShimmer({super.key, this.lineWidthPercent = 0.5, this.mainAxisAlignment});

  factory TextShimmer.random({Key? key}) {
    double w = Random().nextDouble();
    if (w < 0.4) w = 0.4;
    return TextShimmer(key: key, lineWidthPercent: w);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: mainAxisAlignment?? MainAxisAlignment.start,
        children: [
          BaseShimmerWidget(
            child: Container(
              width: 200 * lineWidthPercent,
              height: 14,
              decoration: BoxDecoration(
                  color: context.colors.white,
                  borderRadius: const BorderRadius.all(Radius.circular(8))),
            ),
          ),
        ],
      ),
    );
  }
}
