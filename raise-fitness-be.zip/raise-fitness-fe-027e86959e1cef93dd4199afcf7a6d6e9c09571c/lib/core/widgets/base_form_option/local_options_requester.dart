import 'package:raise/core/http/models/result.dart';
import 'package:raise/core/widgets/base_form_option/base_options_requester.dart';

class LocalOptionsRequester<T> extends BaseOptionsRequester<T> {
  LocalOptionsRequester(
      {required super.valueMainTitleGetter, required List<T> options})
      : super(
            isRemotelySearch: false,
            immediatelyRequestOptions: true,
            fetcher: (searchTerm) async {
              return MyResult.isSuccess(options);
            });
}
