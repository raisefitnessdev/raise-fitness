import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../core/constants/gaps.dart';
import '../../../../core/theme/text/app_text_style.dart';

class BuildCustomSheetItem extends StatelessWidget {
  final String title;
  final Color? color, cardColor;
  final Function() onTap;
  final bool isSelected, noSelect;

  const BuildCustomSheetItem({
    super.key,
    required this.title,
    required this.onTap,
    required this.isSelected,
    this.noSelect = false,
    this.cardColor,
    this.color
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(12).r,
          border: Border(
            bottom: BorderSide(color: context.colors.greyWhite),
          ),
        ),
        child: Row(
          children: [
            Visibility(
              visible: !noSelect,
              child: Visibility(
                visible: isSelected,
                replacement: Icon(
                  Icons.circle_outlined,
                  size: 20.r,
                  color: context.colors.secondary,
                ),
                child: Icon(
                  Icons.check_circle_outline_outlined,
                  size: 20.r,
                  color: context.colors.secondary,
                ),
              ),
            ),
            Gaps.hGap10,
            Text(
              title,
              style: AppTextStyle.s14_w400(color:color?? context.colors.black),
            ),
          ],
        ),
      ),
    );
  }
}
