import 'package:flutter/material.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/localization/translate.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';

class EmptyListItemWidget extends StatelessWidget {
  const EmptyListItemWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Gaps.vGap128,
        Center(
            child: Text(
          Translate.of(context).no_items_found,
          style: AppTextStyle.s16_w400(color: context.colors.darkTextColor),
        )),
      ],
    );
  }
}
