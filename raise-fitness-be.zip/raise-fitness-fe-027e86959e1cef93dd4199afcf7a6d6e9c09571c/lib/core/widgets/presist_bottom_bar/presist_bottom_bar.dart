part of "presist_bottom_bar_imports.dart";

class PresistBottomBar extends StatefulWidget {
  final int index;
  const PresistBottomBar({super.key, this.index = 0});

  @override
  State<StatefulWidget> createState() => _PresistBottomBarState();
}

class _PresistBottomBarState extends State<PresistBottomBar> with TickerProviderStateMixin {
  late PresistBottomBarController controller = PresistBottomBarController();

  @override
  void initState() {
    controller.initBottomNavigation(this, widget.index);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ObsValueConsumer(
      observable: controller.navigationBarObs,
      builder: (context, value) {
        return Padding(
          padding: const EdgeInsets.all(24).r,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(100).r,
            child: AnimatedBottomNavigationBar.builder(
              itemCount: 4,
              onTap: (value) => controller.changeSelectPage(value, context),
              tabBuilder: (index, isActive) {
                return TabsItemWidget(
                  isActive: isActive,
                  icon: controller.tabs[index],
                  title: controller.titles[index],
                );
              },
              height: 70.h,
              activeIndex: value,
              backgroundColor: context.colors.backgroundLight,
              splashColor: context.colors.primary,
              gapLocation: GapLocation.none,
              splashSpeedInMilliseconds: 200,
            ),
          ),
        );
      },
    );
  }
}