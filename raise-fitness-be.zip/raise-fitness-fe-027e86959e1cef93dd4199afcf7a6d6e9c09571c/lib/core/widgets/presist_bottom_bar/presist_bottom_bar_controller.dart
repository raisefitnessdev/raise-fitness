part of "presist_bottom_bar_imports.dart";

class PresistBottomBarController {
  late TabController tabController;
  final ObsValue<int> navigationBarObs = ObsValue<int>.withInit(0);

  final BaseBloc<String> bloc = BaseBloc<String>();

  List<String> tabs = [
    Res.home,
    Res.packages,
    Res.profile,
    Res.settings,
  ];

  List<String> titles = [
    "Home",
    "Packages",
    "Profile",
    "Settings",
  ];

  void initBottomNavigation(TickerProvider ticker, int index) {
    tabController =
        TabController(length: 5, vsync: ticker, initialIndex: index);
  }

  void changeSelectPage(int index, BuildContext context) {
    tabController.animateTo(index);
    navigationBarObs.setValue(index);
    AutoRouter.of(context).push(Dashboard(index: index));
  }
}
