import 'package:flutter/material.dart';
import 'package:raise/core/helpers/color_helper.dart';
import 'package:raise/core/theme/colors/app_colors.dart';

class AppLightColors extends AppColors {
  @override
  Color get primary =>
      ColorHelper.hexToColor(const String.fromEnvironment("PRIMARY_COLOR"));

  @override
  Color get secondary =>
      ColorHelper.hexToColor(const String.fromEnvironment("SECONDARY_COLOR"));
  @override
  Color get textColor =>
      ColorHelper.hexToColor(const String.fromEnvironment("TEXT_COLOR"));

  @override
  Color get filedColor => const Color(0xff12191B);

  @override
  Color get inputBorder => const Color(0xffE3E3E3);

  @override
  Color get white => Colors.white;

  @override
  Color get background => const Color(0xff1E1E1E);

  @override
  Color get backgroundWhite => const Color(0xffECECEC);

  @override
  Color get black => Colors.black;

  @override
  Color get blackOpacity => const Color(0xff7B7B7B);

  @override
  Color get greyWhite => Colors.grey.withValues(alpha: .2);

  @override
  Color get disableGray => const Color(0xFFCBCBCB);

  @override
  Color get green => Colors.green;

  @override
  Color get green2 => const Color(0xff239397);

  @override
  Color get green3 => const Color(0xff83AA54);

  @override
  Color get green4 => const Color(0xff186669);

  @override
  Color get brown => const Color(0xffFFEA9F);

  @override
  // Color get primaryText => const Color(0xff2c979b);
  Color get primaryText => const Color(0xffFCFCFC);

  @override
  Color get darkTextColor => const Color(0xff4A5D62);

  @override
  Color get red => const Color(0xffEB3F3C);

  @override
  Color get backgroundLight => const Color(0xff0B0E10);

  @override
  Color get bgLight => const Color(0xffF4F4F4);

  @override
  Color get primaryGrey => const Color(0xffB9B9B9);

  @override
  Color get errorColor => const Color(0xffFF6969);

  @override
  Color get noticesTextColor => const Color(0xff16161D);

  @override
  Color get secondaryText => const Color(0xffD9D9D9);

  @override
  Color get vacantBgColor => const Color(0xff5A6568);
}
