import 'package:flutter/material.dart';

abstract class AppTheme {
  static var fontFamily = 'SpaceGrotesk';
  static var conthraxFamily = 'Conthrax';

  ThemeData get theme;

  // TextTheme get textTheme;

  ColorScheme get colorScheme;
}
