// dart format width=80
// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:auto_route/auto_route.dart' as _i21;
import 'package:flutter/material.dart' as _i22;
import 'package:raise/features/auth/data/models/user_info_model/user_info_model.dart'
    as _i24;
import 'package:raise/features/auth/presentation/pages/active_account/active_account_imports.dart'
    as _i1;
import 'package:raise/features/auth/presentation/pages/forget_password/forget_password_imports.dart'
    as _i7;
import 'package:raise/features/auth/presentation/pages/get_code_info/get_code_info_imports.dart'
    as _i8;
import 'package:raise/features/auth/presentation/pages/intro/intro_imports.dart'
    as _i9;
import 'package:raise/features/auth/presentation/pages/login/login_imports.dart'
    as _i12;
import 'package:raise/features/auth/presentation/pages/register/register_imports.dart'
    as _i16;
import 'package:raise/features/auth/presentation/pages/reset_password/reset_password_imports.dart'
    as _i17;
import 'package:raise/features/auth/presentation/pages/splash/splash_imports.dart'
    as _i19;
import 'package:raise/features/auth/presentation/pages/verify_otp/verify_otp_imports.dart'
    as _i20;
import 'package:raise/features/base/data/models/booking_model/booking_model.dart'
    as _i25;
import 'package:raise/features/base/data/models/class_model/class_model.dart'
    as _i23;
import 'package:raise/features/base/presentation/pages/class_details/class_details_imports.dart'
    as _i2;
import 'package:raise/features/base/presentation/pages/contact_us/contact_us_imports.dart'
    as _i3;
import 'package:raise/features/base/presentation/pages/dashboard/dashboard_imports.dart'
    as _i4;
import 'package:raise/features/base/presentation/pages/edit_profile/edit_profile_imports.dart'
    as _i5;
import 'package:raise/features/base/presentation/pages/faq/faq_imports.dart'
    as _i6;
import 'package:raise/features/base/presentation/pages/journey/journey_imports.dart'
    as _i10;
import 'package:raise/features/base/presentation/pages/journey_details/journey_details_imports.dart'
    as _i11;
import 'package:raise/features/base/presentation/pages/my_packages/my_packages_imports.dart'
    as _i13;
import 'package:raise/features/base/presentation/pages/notifications/notifications_imports.dart'
    as _i14;
import 'package:raise/features/base/presentation/pages/online_payment/online_payment_imports.dart'
    as _i15;
import 'package:raise/features/base/presentation/pages/settings/settings_imports.dart'
    as _i18;

/// generated route for
/// [_i1.ActiveAccount]
class ActiveAccount extends _i21.PageRouteInfo<ActiveAccountArgs> {
  ActiveAccount({
    _i22.Key? key,
    required String email,
    required bool isActivate,
    List<_i21.PageRouteInfo>? children,
  }) : super(
         ActiveAccount.name,
         args: ActiveAccountArgs(
           key: key,
           email: email,
           isActivate: isActivate,
         ),
         initialChildren: children,
       );

  static const String name = 'ActiveAccount';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<ActiveAccountArgs>();
      return _i1.ActiveAccount(
        key: args.key,
        email: args.email,
        isActivate: args.isActivate,
      );
    },
  );
}

class ActiveAccountArgs {
  const ActiveAccountArgs({
    this.key,
    required this.email,
    required this.isActivate,
  });

  final _i22.Key? key;

  final String email;

  final bool isActivate;

  @override
  String toString() {
    return 'ActiveAccountArgs{key: $key, email: $email, isActivate: $isActivate}';
  }
}

/// generated route for
/// [_i2.ClassDetails]
class ClassDetailsRoute extends _i21.PageRouteInfo<ClassDetailsRouteArgs> {
  ClassDetailsRoute({
    _i22.Key? key,
    required _i23.ClassModel details,
    List<_i21.PageRouteInfo>? children,
  }) : super(
         ClassDetailsRoute.name,
         args: ClassDetailsRouteArgs(key: key, details: details),
         initialChildren: children,
       );

  static const String name = 'ClassDetailsRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<ClassDetailsRouteArgs>();
      return _i2.ClassDetails(key: args.key, details: args.details);
    },
  );
}

class ClassDetailsRouteArgs {
  const ClassDetailsRouteArgs({this.key, required this.details});

  final _i22.Key? key;

  final _i23.ClassModel details;

  @override
  String toString() {
    return 'ClassDetailsRouteArgs{key: $key, details: $details}';
  }
}

/// generated route for
/// [_i3.ContactUs]
class ContactUsRoute extends _i21.PageRouteInfo<void> {
  const ContactUsRoute({List<_i21.PageRouteInfo>? children})
    : super(ContactUsRoute.name, initialChildren: children);

  static const String name = 'ContactUsRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i3.ContactUs();
    },
  );
}

/// generated route for
/// [_i4.Dashboard]
class Dashboard extends _i21.PageRouteInfo<DashboardArgs> {
  Dashboard({_i22.Key? key, int index = 0, List<_i21.PageRouteInfo>? children})
    : super(
        Dashboard.name,
        args: DashboardArgs(key: key, index: index),
        initialChildren: children,
      );

  static const String name = 'Dashboard';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<DashboardArgs>(
        orElse: () => const DashboardArgs(),
      );
      return _i4.Dashboard(key: args.key, index: args.index);
    },
  );
}

class DashboardArgs {
  const DashboardArgs({this.key, this.index = 0});

  final _i22.Key? key;

  final int index;

  @override
  String toString() {
    return 'DashboardArgs{key: $key, index: $index}';
  }
}

/// generated route for
/// [_i5.EditProfile]
class EditProfileRoute extends _i21.PageRouteInfo<EditProfileRouteArgs> {
  EditProfileRoute({
    _i22.Key? key,
    required _i24.UserInfoModel user,
    List<_i21.PageRouteInfo>? children,
  }) : super(
         EditProfileRoute.name,
         args: EditProfileRouteArgs(key: key, user: user),
         initialChildren: children,
       );

  static const String name = 'EditProfileRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<EditProfileRouteArgs>();
      return _i5.EditProfile(key: args.key, user: args.user);
    },
  );
}

class EditProfileRouteArgs {
  const EditProfileRouteArgs({this.key, required this.user});

  final _i22.Key? key;

  final _i24.UserInfoModel user;

  @override
  String toString() {
    return 'EditProfileRouteArgs{key: $key, user: $user}';
  }
}

/// generated route for
/// [_i6.FAQ]
class FAQRoute extends _i21.PageRouteInfo<void> {
  const FAQRoute({List<_i21.PageRouteInfo>? children})
    : super(FAQRoute.name, initialChildren: children);

  static const String name = 'FAQRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i6.FAQ();
    },
  );
}

/// generated route for
/// [_i7.ForgetPassword]
class ForgetPassword extends _i21.PageRouteInfo<void> {
  const ForgetPassword({List<_i21.PageRouteInfo>? children})
    : super(ForgetPassword.name, initialChildren: children);

  static const String name = 'ForgetPassword';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i7.ForgetPassword();
    },
  );
}

/// generated route for
/// [_i8.GetCodeInfo]
class GetCodeInfoRoute extends _i21.PageRouteInfo<void> {
  const GetCodeInfoRoute({List<_i21.PageRouteInfo>? children})
    : super(GetCodeInfoRoute.name, initialChildren: children);

  static const String name = 'GetCodeInfoRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i8.GetCodeInfo();
    },
  );
}

/// generated route for
/// [_i9.Intro]
class IntroRoute extends _i21.PageRouteInfo<void> {
  const IntroRoute({List<_i21.PageRouteInfo>? children})
    : super(IntroRoute.name, initialChildren: children);

  static const String name = 'IntroRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i9.Intro();
    },
  );
}

/// generated route for
/// [_i10.Journey]
class JourneyRoute extends _i21.PageRouteInfo<void> {
  const JourneyRoute({List<_i21.PageRouteInfo>? children})
    : super(JourneyRoute.name, initialChildren: children);

  static const String name = 'JourneyRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i10.Journey();
    },
  );
}

/// generated route for
/// [_i11.JourneyDetails]
class JourneyDetailsRoute extends _i21.PageRouteInfo<JourneyDetailsRouteArgs> {
  JourneyDetailsRoute({
    _i22.Key? key,
    required _i25.BookingModel details,
    List<_i21.PageRouteInfo>? children,
  }) : super(
         JourneyDetailsRoute.name,
         args: JourneyDetailsRouteArgs(key: key, details: details),
         initialChildren: children,
       );

  static const String name = 'JourneyDetailsRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<JourneyDetailsRouteArgs>();
      return _i11.JourneyDetails(key: args.key, details: args.details);
    },
  );
}

class JourneyDetailsRouteArgs {
  const JourneyDetailsRouteArgs({this.key, required this.details});

  final _i22.Key? key;

  final _i25.BookingModel details;

  @override
  String toString() {
    return 'JourneyDetailsRouteArgs{key: $key, details: $details}';
  }
}

/// generated route for
/// [_i12.Login]
class LoginRoute extends _i21.PageRouteInfo<void> {
  const LoginRoute({List<_i21.PageRouteInfo>? children})
    : super(LoginRoute.name, initialChildren: children);

  static const String name = 'LoginRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i12.Login();
    },
  );
}

/// generated route for
/// [_i13.MyPackages]
class MyPackagesRoute extends _i21.PageRouteInfo<void> {
  const MyPackagesRoute({List<_i21.PageRouteInfo>? children})
    : super(MyPackagesRoute.name, initialChildren: children);

  static const String name = 'MyPackagesRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i13.MyPackages();
    },
  );
}

/// generated route for
/// [_i14.Notifications]
class NotificationsRoute extends _i21.PageRouteInfo<void> {
  const NotificationsRoute({List<_i21.PageRouteInfo>? children})
    : super(NotificationsRoute.name, initialChildren: children);

  static const String name = 'NotificationsRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i14.Notifications();
    },
  );
}

/// generated route for
/// [_i15.OnlinePayment]
class OnlinePaymentRoute extends _i21.PageRouteInfo<OnlinePaymentRouteArgs> {
  OnlinePaymentRoute({
    _i22.Key? key,
    required String amount,
    required int packageId,
    List<_i21.PageRouteInfo>? children,
  }) : super(
         OnlinePaymentRoute.name,
         args: OnlinePaymentRouteArgs(
           key: key,
           amount: amount,
           packageId: packageId,
         ),
         initialChildren: children,
       );

  static const String name = 'OnlinePaymentRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<OnlinePaymentRouteArgs>();
      return _i15.OnlinePayment(
        key: args.key,
        amount: args.amount,
        packageId: args.packageId,
      );
    },
  );
}

class OnlinePaymentRouteArgs {
  const OnlinePaymentRouteArgs({
    this.key,
    required this.amount,
    required this.packageId,
  });

  final _i22.Key? key;

  final String amount;

  final int packageId;

  @override
  String toString() {
    return 'OnlinePaymentRouteArgs{key: $key, amount: $amount, packageId: $packageId}';
  }
}

/// generated route for
/// [_i16.Register]
class RegisterRoute extends _i21.PageRouteInfo<void> {
  const RegisterRoute({List<_i21.PageRouteInfo>? children})
    : super(RegisterRoute.name, initialChildren: children);

  static const String name = 'RegisterRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i16.Register();
    },
  );
}

/// generated route for
/// [_i17.ResetPassword]
class ResetPassword extends _i21.PageRouteInfo<ResetPasswordArgs> {
  ResetPassword({
    _i22.Key? key,
    required String code,
    List<_i21.PageRouteInfo>? children,
  }) : super(
         ResetPassword.name,
         args: ResetPasswordArgs(key: key, code: code),
         initialChildren: children,
       );

  static const String name = 'ResetPassword';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<ResetPasswordArgs>();
      return _i17.ResetPassword(key: args.key, code: args.code);
    },
  );
}

class ResetPasswordArgs {
  const ResetPasswordArgs({this.key, required this.code});

  final _i22.Key? key;

  final String code;

  @override
  String toString() {
    return 'ResetPasswordArgs{key: $key, code: $code}';
  }
}

/// generated route for
/// [_i18.Settings]
class SettingsRoute extends _i21.PageRouteInfo<void> {
  const SettingsRoute({List<_i21.PageRouteInfo>? children})
    : super(SettingsRoute.name, initialChildren: children);

  static const String name = 'SettingsRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i18.Settings();
    },
  );
}

/// generated route for
/// [_i19.Splash]
class SplashRoute extends _i21.PageRouteInfo<void> {
  const SplashRoute({List<_i21.PageRouteInfo>? children})
    : super(SplashRoute.name, initialChildren: children);

  static const String name = 'SplashRoute';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i19.Splash();
    },
  );
}

/// generated route for
/// [_i20.VerifyOTP]
class VerifyOTP extends _i21.PageRouteInfo<void> {
  const VerifyOTP({List<_i21.PageRouteInfo>? children})
    : super(VerifyOTP.name, initialChildren: children);

  static const String name = 'VerifyOTP';

  static _i21.PageInfo page = _i21.PageInfo(
    name,
    builder: (data) {
      return const _i20.VerifyOTP();
    },
  );
}
