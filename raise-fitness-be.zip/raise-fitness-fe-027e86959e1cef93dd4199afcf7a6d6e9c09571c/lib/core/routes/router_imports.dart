import 'package:auto_route/auto_route.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/features/auth/presentation/manager/routes/routes.dart';
import 'package:raise/features/base/presentation/manager/routes/routes.dart';

part 'router.dart';
