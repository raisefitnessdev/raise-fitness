// dart format width=80
// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:get_it/get_it.dart' as _i174;
import 'package:injectable/injectable.dart' as _i526;
import 'package:raise/core/helpers/firebase_analytics_helper.dart' as _i595;
import 'package:raise/core/helpers/global_context.dart' as _i557;
import 'package:raise/core/helpers/global_notification.dart' as _i482;
import 'package:raise/core/helpers/loading_helper.dart' as _i515;
import 'package:raise/core/helpers/services/file_service.dart' as _i393;
import 'package:raise/core/helpers/services/psermission_services.dart' as _i342;
import 'package:raise/core/helpers/share_services.dart' as _i1000;
import 'package:raise/core/helpers/shared_pref_service.dart' as _i966;
import 'package:raise/core/helpers/utilities.dart' as _i749;
import 'package:raise/core/http/dio_helper/actions/delete.dart' as _i991;
import 'package:raise/core/http/dio_helper/actions/get.dart' as _i1072;
import 'package:raise/core/http/dio_helper/actions/patch.dart' as _i739;
import 'package:raise/core/http/dio_helper/actions/post.dart' as _i420;
import 'package:raise/core/http/dio_helper/actions/put.dart' as _i883;
import 'package:raise/core/http/dio_helper/utils/dio_header.dart' as _i812;
import 'package:raise/core/http/dio_helper/utils/dio_options.dart' as _i28;
import 'package:raise/core/http/dio_helper/utils/handle_errors.dart' as _i508;
import 'package:raise/core/http/dio_helper/utils/handle_json_response.dart'
    as _i890;
import 'package:raise/core/http/dio_helper/utils/handle_request_body.dart'
    as _i396;
import 'package:raise/core/http/generic_http/generic_http.dart' as _i59;
import 'package:raise/core/network/network_info.dart' as _i341;
import 'package:raise/features/auth/data/data_sources/auth_data_source.dart'
    as _i1065;
import 'package:raise/features/auth/data/data_sources/auth_data_source_impl.dart'
    as _i175;
import 'package:raise/features/auth/data/repositories/auth_repository_impl.dart'
    as _i417;
import 'package:raise/features/auth/domain/repositories/auth_repository.dart'
    as _i403;
import 'package:raise/features/base/data/data_sources/home_remote_data_source.dart'
    as _i116;
import 'package:raise/features/base/data/data_sources/impl_home_remote_data_source.dart'
    as _i125;
import 'package:raise/features/base/data/repositories/impl_base_repository.dart'
    as _i658;
import 'package:raise/features/base/domain/repositories/base_repository.dart'
    as _i969;

extension GetItInjectableX on _i174.GetIt {
// initializes the registration of main-scope dependencies inside of GetIt
  _i174.GetIt init({
    String? environment,
    _i526.EnvironmentFilter? environmentFilter,
  }) {
    final gh = _i526.GetItHelper(
      this,
      environment,
      environmentFilter,
    );
    gh.factory<_i1000.ShareServices>(() => _i1000.ShareServices());
    gh.factory<_i393.AppFileService>(() => _i393.AppFileService());
    gh.factory<_i342.PermissionServices>(() => _i342.PermissionServices());
    gh.singleton<_i515.LoadingHelper>(() => _i515.LoadingHelper());
    gh.lazySingleton<_i341.NetworkInfoImpl>(() => _i341.NetworkInfoImpl());
    gh.lazySingleton<_i28.DioOptions>(() => _i28.DioOptions());
    gh.lazySingleton<_i508.HandleErrors>(() => _i508.HandleErrors());
    gh.lazySingleton<_i396.HandleRequestBody>(() => _i396.HandleRequestBody());
    gh.lazySingleton<_i890.HandleJsonResponse<dynamic>>(
        () => _i890.HandleJsonResponse<dynamic>());
    gh.lazySingleton<_i812.DioHeader>(() => _i812.DioHeader());
    gh.lazySingleton<_i739.Patch>(() => _i739.Patch());
    gh.lazySingleton<_i420.Post>(() => _i420.Post());
    gh.lazySingleton<_i991.Delete>(() => _i991.Delete());
    gh.lazySingleton<_i1072.Get>(() => _i1072.Get());
    gh.lazySingleton<_i883.Put>(() => _i883.Put());
    gh.lazySingleton<_i59.GenericHttpImpl<dynamic>>(
        () => _i59.GenericHttpImpl<dynamic>());
    gh.lazySingleton<_i557.GlobalContext>(() => _i557.GlobalContext());
    gh.lazySingleton<_i482.GlobalNotification>(
        () => _i482.GlobalNotification());
    gh.lazySingleton<_i749.Utilities>(() => _i749.Utilities());
    gh.lazySingleton<_i595.FirebaseAnalyticsHelper>(
        () => _i595.FirebaseAnalyticsHelper());
    gh.lazySingleton<_i966.SharedPrefService>(() => _i966.SharedPrefService());
    gh.factory<_i969.BaseRepository>(() => _i658.ImplBaseRepository());
    gh.factory<_i1065.AuthDataSource>(() => _i175.AuthDataSourceImpl());
    gh.factory<_i403.AuthRepository>(() => _i417.AuthRepositoryImpl());
    gh.factory<_i116.HomeRemoteDataSource>(
        () => _i125.ImplHomeRemoteDataSource());
    return this;
  }
}
