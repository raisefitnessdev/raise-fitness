import 'package:raise/core/constants/app_config.dart';

class ApiNames {
  static String baseUrl = AppConfig.instance.baseAPIUrl;
  static String version1Part = "v1/";

  static const String apiKey =
      // "rLtt6JWvbUHDDhsZnfpAhpYk4dxYDQkbcPTyGaKp2TYqQgG7FGZ5Th_WD53Oq8Ebz6A53njUoo1w3pjU1D4vs_ZMqFiz_j0urb_BH9Oq9VZoKFoJEDAbRZepGcQanImyYrry7Kt6MnMdgfG5jn4HngWoRdKduNNyP4kzcp3mRv7x00ahkm9LAK7ZRieg7k1PDAnBIOG3EyVSJ5kK4WLMvYr7sCwHbHcu4A5WwelxYK0GMJy37bNAarSJDFQsJ2ZvJjvMDmfWwDVFEVe_5tOomfVNt6bOg9mexbGjMrnHBnKnZR1vQbBtQieDlQepzTZMuQrSuKn-t5XZM7V6fCW7oP-uXGX-sMOajeX65JOf6XVpk29DP6ro8WTAflCDANC193yof8-f5_EYY-3hXhJj7RBXmizDpneEQDSaSz5sFk0sV5qPcARJ9zGG73vuGFyenjPPmtDtXtpx35A-BVcOSBYVIWe9kndG3nclfefjKEuZ3m4jL9Gg1h2JBvmXSMYiZtp9MR5I6pvbvylU_PP5xJFSjVTIz7IQSjcVGO41npnwIxRXNRxFOdIUHn0tjQ-7LwvEcTXyPsHXcMD8WtgBh-wxR8aKX7WPSsT1O8d8reb2aR7K3rkV3K82K_0OgawImEpwSvp9MNKynEAJQS6ZHe_J_l77652xwPNxMRTMASk1ZsJL";
      "MS8nCwsTb9a-Gqh_mdPW4smTnUkF4LcfmatJH0_6s3ZURXJWZ2NTv-F9dVV5oZ_4df2ppZGuG_nTz3C4oEHf7ch5z7B7v2TfvHIJCE9pZO7RButszGA30g7UHkxGU9M1CjA4WztqnybT66smwzxSguNLNlTfVXYTGrSpBXyFQ8pRM0q7D_ZYhvjzSDHenUmfzCplw8h8I0P6k8FRgYYdi3O5WEhKFakywrhAmFCN_4uI7qIyupkAVzx85vJbJpvrsmId_SP8nvf3YKr5Ik_KgWB5TDIOcetskKQp9Icb2yDeY7NnTZcDPGPkEpqQALlmu3jsAnk8iKm5tj1i9CZnr6kdiuhTU8jgPvMAywYa_QmvdGvZllyACKMaBO9n4R8cvP6FOG9JocsTyuFIXVhJW4H9aApPtmuTn3St2npni0ODMue_5uNdz0r2YYgOJjgGKlb1VJ6MKc6S0NdDqIdOXl6q-MyS-3WQzDOXI0s9X868lsxnZWCi0KQTfln7ZwCaNFi_PJYabFi_GXm4uowA-BmNawC1mr8ayZplzeTHbHJYbvJtWIQMVaya6l38J5bXWBqaekNdE0aJbe-Z29U4LgUawbOt-ULtIx5725QVxEiI39gGZz8VyyRy1sP_qS2QaiZ1LlTRQGrekU5akxTWMLsSf9h53uMKFc6TIqpv2UjOH-MYwNbzNxrMPlCUR3PUM4Rs9vrSHziK_ckr3s_nVzGNhzY";
  // auth routes
  static String login = "auth/login";
  static const String register = "auth/register";
  static const String activeAccount = "auth/active-account";
  static const String resendActivation = "auth/resend-activation-code";
  static const String resendConfirmation = "auth/resend-confirmation-code";
  static const String forgetPassword = "auth/forget-password";
  static const String resetPassword = "auth/reset-password";
  static const String checkForget = "auth/check-code";
  static const String classes = "classes";
  static const String packages = "packages";
  static const String myPackages = "my-packages";
  static const String profile = "profile";
  static const String updateProfile = "update-profile";
  static const String updatePassword = "change-password";
  static const String purchasePackage = "purchase-package";
  static const String activatePackage = "activate-package";
  static const String buyClass = "buy-class";
  static const String myClasses = "my-classes";
  static const String contactUs = "contact-us";
  static const String settings = "settings";
  static const String faqs = "faqs";
  static const String notifications = "notifications/all";
  static const String notificationCount = "notifications/unread-messages-count";
  static const String removeAccount = "remove-account";
  static const String changeStatus = "change-class-status";

  static String logOut = "${version1Part}auth/logout";
  static const String refreshToken = "auth";
  static const String savePublicKey = "users/";
  static const String updateUser = "users/";

  static const String switchNotify = "SwitchNotify";

  /// tenant routes
  static String getTenant = "${version1Part}tenant/list";

  static String getContract(String header) =>
      "${version1Part}contract/list?$header";

  static String renewContract(String id) =>
      "${version1Part}contract/renew?tts_id=$id";

  /// props and units routes
  static String properties = "${version1Part}tenant/properties/list";
  static String tenantPropUnits = "${version1Part}tenant/units";
  static String ownerPropUnits = "${version1Part}owner/units";
  static String ownerPropFilter = "${version1Part}owner/properties/filters";
  static String ownerProps(String header) =>
      "$version1Part/owner/properties/list$header";
  static String propDetails(String param) =>
      "${version1Part}owner/properties/details?prop_id=$param";
  static String propDetailsUnit(String header) =>
      "${version1Part}owner/properties/units/list?$header";
  static String propExpenses(String param) =>
      "${version1Part}owner/properties/expenses?prop_id=$param";

  /// maintenance routes
  static String maintenanceRequests(String header) =>
      "${version1Part}maintenance/list?$header";
  static String maintenanceServices = "${version1Part}maintenance/services";
  static String maintenanceAdd = "${version1Part}maintenance/add";
  static String getNotices = "${version1Part}notification/list";

  static String contractPayment(String id) =>
      "${version1Part}contract/payment/list?tts_id=$id";
  static String noticesUnread = "${version1Part}notification/unread-count";
  static String noticesRead = "${version1Part}notification/read";
  static String getBoolean = "${version1Part}boolean";

  /// General Links
  static String supportLink =
      "https://Raise Fitness.sa/service/submitticket.php?step=2&deptid=1";
}
