import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'auth_state.dart';

class AuthCubit extends Cubit<AuthState> {
  AuthCubit() : super(const AuthInitial());

  onUpdateAuth(bool authorized) {
    emit(AuthUpdated(authorized));
  }
}
