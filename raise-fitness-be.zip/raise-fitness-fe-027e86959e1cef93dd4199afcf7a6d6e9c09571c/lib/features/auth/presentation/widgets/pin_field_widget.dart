import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';

import 'package:pin_code_fields/pin_code_fields.dart';

class PinFieldWidget extends StatelessWidget {
  final Function(String) onComplete;
  final EdgeInsetsGeometry? margin;

  const PinFieldWidget({
    super.key,
    required this.onComplete,
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin ?? const EdgeInsets.symmetric(horizontal: 20),
      child: PinCodeTextField(
        length: 6,
        appContext: context,
        onChanged: (String value) {},
        backgroundColor: Colors.transparent,
        animationType: AnimationType.fade,
        pinTheme: PinTheme(
          shape: PinCodeFieldShape.box,
          borderRadius: BorderRadius.circular(12).r,
          fieldHeight: 55.h,
          fieldWidth: 50.w,
          inactiveColor: context.colors.greyWhite,
          activeColor: context.colors.backgroundWhite,
          selectedColor: context.colors.primary,
          selectedFillColor: context.colors.filedColor,
          inactiveFillColor: context.colors.filedColor,
          activeFillColor: context.colors.filedColor,
          disabledColor: context.colors.black,
        ),
        animationDuration: const Duration(milliseconds: 300),
        enableActiveFill: true,
        onCompleted: onComplete,
      ),
    );
  }
}
