import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';

class BuildRegisterWidget extends StatelessWidget {
  final bool isRegister;
  const BuildRegisterWidget({super.key, required this.isRegister});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: InkWell(
        onTap: () => isRegister? AutoRouter.of(context).push(const RegisterRoute()) : AutoRouter.of(context).push(const LoginRoute()),
        child: Text.rich(
          TextSpan(
              text: isRegister? "Don't Have account? " : "Have account? ",
              style: AppTextStyle.s14_w400(color: context.colors.textColor),
              children: <InlineSpan>[
                TextSpan(
                  text: isRegister? "Sign Up" : "Sign In",
                  style: AppTextStyle.s14_w500(color: context.colors.primary),
                ),
              ]),
        ),
      ),
    );
  }
}
