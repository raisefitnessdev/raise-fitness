import 'package:flutter/material.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';

class AuthAppBarWidget extends StatelessWidget implements PreferredSizeWidget {
  final GlobalKey<ScaffoldState>? scaffoldkey;
  final String? title;
  final Function()? onBack;
  final bool showBack;
  final List<Widget>? action;

  final Widget? leading;

  const AuthAppBarWidget({
    super.key,
    this.title,
    this.onBack,
    this.leading,
    this.showBack = true,
    this.scaffoldkey,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(start: 10, end: 20),
      child: AppBar(
        elevation: 0,
        centerTitle: true,
        title: title != null
            ? Text(
                title ?? "",
                style: AppTextStyle.s20_w600(color: context.colors.black),
              )
            : null,
        backgroundColor: Colors.transparent,
        leading: leading ??
            InkWell(
                onTap: () => scaffoldkey?.currentState!.openDrawer(),
                child: Icon(
                  Icons.more_vert_outlined,
                  color: context.colors.black,
                  size: 25,
                )),
        // Offstage(
        //   offstage: !showBack,
        //   child: InkWell(
        //     onTap: onBack ?? AutoRouter.of(context).pop,
        //     child: Icon(
        //       Icons.arrow_back_ios_new,
        //       size: 22,
        //       color: context.colors.black,
        //     ),
        //   ),
        // ),
        actions: const [
          Gaps.empty,
        ],
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(50);
}
