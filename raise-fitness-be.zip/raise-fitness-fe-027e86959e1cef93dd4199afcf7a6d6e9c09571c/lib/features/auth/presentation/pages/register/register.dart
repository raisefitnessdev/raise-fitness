part of 'register_imports.dart';

@RoutePage(name: 'RegisterRoute')
class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final RegisterController controller = RegisterController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const DefaultAppBar(
        title: "",
        showBack: true,
      ),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus,
        child: Column(
          children: [
            
            Flexible(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  const RegisterHeaderWidget(),
                  Gaps.vGap24,
                  RegisterFormWidget(controller: controller),
                  Gaps.vGap32,
                  RegisterButtonWidget(controller: controller),
                  Gaps.vGap32,
                  ApplyTermsView(controller: controller,),
                  Gaps.vGap50,
                  const BuildRegisterWidget(
                    isRegister: false,
                  ),
                  Gaps.vGap32,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
