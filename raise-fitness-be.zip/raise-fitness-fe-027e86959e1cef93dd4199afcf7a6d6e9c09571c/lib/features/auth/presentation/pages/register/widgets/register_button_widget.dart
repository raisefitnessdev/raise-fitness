part of'register_widgets_imports.dart';


class RegisterButtonWidget extends StatelessWidget {
  final RegisterController controller;
  const RegisterButtonWidget({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: AppTextButton.maxCustom(
        onPressed: () => controller.callCreateAccount(context),
        bgColor: context.colors.primary,
        txtColor: context.colors.black,
        textSize: 18,
        maxHeight: 55,
        borderRadius: 50,
        text: "Register",
      ),
    );
  }
}
