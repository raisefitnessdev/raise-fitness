part of 'register_imports.dart';

class RegisterController {
  ObsValue<bool> visiblePasObs = ObsValue.withInit(false);
  ObsValue<bool> visibleConfirmPasObs = ObsValue.withInit(false);

  ObsValue<bool> gendrObs = ObsValue.withInit(true);
  ObsValue<bool> termsObs = ObsValue.withInit(false);

  final TextEditingController firstname = TextEditingController();
  final TextEditingController lastname = TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController phone = TextEditingController();
  final TextEditingController birthdate = TextEditingController();
  final TextEditingController password = TextEditingController();
  final TextEditingController passwordConfirm = TextEditingController();

  final ObsValue<Country?> countryObs = ObsValue.withInit(Country(
      phoneCode: "974",
      countryCode: "QA",
      e164Sc: 0,
      geographic: true,
      level: 1,
      name: "Qatar",
      example: "412345678",
      displayName: "Qatar (QA) [+974]",
      displayNameNoCountryCode: "Qatar (QA)",
      e164Key: "974-QA-0"));

  final GlobalKey<FormState> formKey = GlobalKey();

  void showCountryDialog(BuildContext context) async {
    showCountryPicker(
      context: context,
      showPhoneCode: true,
      showWorldWide: false,
      fontFamily: AppTheme.fontFamily,
      favorite: ['+974', 'QA'],
      countryListTheme: CountryListThemeData(
        backgroundColor: context.colors.background,
        textStyle: AppTextStyle.s16_w400(color: context.colors.textColor),
      ),
      buildSearch: (onSearch) {
        return SearchFormField(
          onChange: onSearch,
          onSubmit: onSearch,
        );
      },
      onSelect: (Country country) {
        // codeCubit.onUpdateData("+${country.phoneCode}");
        countryObs.setValue(country);
      },
    );
  }

  void showDateAlert(BuildContext context) async {
    AdaptivePicker.datePicker(
      minDate: DateTime(DateTime.now().year - 120),
      context: context,
      onConfirm: (value) => handleDate(value),
      title: '',
    );
  }

  void handleDate(DateTime? value) {
    birthdate.text = DateFormat("yyyy-MM-dd", "en").format(value!);
  }

  Future<bool> callCreateAccount(BuildContext context) async {
    if (_checkFormValidation(context)) {
      if (termsObs.getValue() == false) {
        AppSnackBar.showSimpleToast(
        msg: "Agree on Terms & Conditions first",
        type: ToastType.error,
      );
        return false;
      } else {
        RegisterParams params = registerParams();
        var loginResponse = await getIt<AuthRepository>().register(params);
        return _handleRegisterResponse(loginResponse);
      }
    } else {
      return false;
    }
  }

  bool _handleRegisterResponse(MyResult<UserModel> response) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (userModel) {
      context.read<UserCubit>().onUpdateUserData(userModel!);
      GlobalState.instance.set("token", response.data?.token);
      UserHelperService.instance.saveUserData(userModel);
      AppSnackBar.showSimpleToast(
        color: context.colors.black,
        msg: "Welcome back",
        type: ToastType.success,
      );
      if (userModel.user?.emailVerifiedAt == null) {
        AutoRouter.of(context).push(ActiveAccount(
            email: userModel.user?.email ?? "", isActivate: true));
      } else {
        AutoRouter.of(context).push(Dashboard(index: 0));
      }
      return true;
    }, isError: (error) {
      return false;
    });
  }

  RegisterParams registerParams() {
    return RegisterParams(
      password: password.text,
      email: email.text,
      firstname: firstname.text,
      lastname: lastname.text,
      phone: countryObs.getValue()!.phoneCode + phone.text,
      gender: gendrObs.getValue() ? "male" : "female",
      birthday: birthdate.text,
      confirmation: passwordConfirm.text,
    );
  }

  bool _checkFormValidation(BuildContext context) {
    return formKey.currentState!.validate();
  }
}
