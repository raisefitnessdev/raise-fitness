part of "register_widgets_imports.dart";

class ApplyTermsView extends StatelessWidget {
  final RegisterController controller;
  const ApplyTermsView({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return ObsValueConsumer(
        observable: controller.termsObs,
        builder: (context, state) {
          return Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Theme(
                data: ThemeData(
                    checkboxTheme: CheckboxThemeData(
                      shape: RoundedRectangleBorder(
                          side: BorderSide(color: context.colors.primary),
                          borderRadius: BorderRadius.circular(5).r),
                    ),
                    unselectedWidgetColor: context.colors.primary),
                child: Checkbox(
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  visualDensity:
                      const VisualDensity(horizontal: -4, vertical: -4),
                  checkColor: context.colors.black,
                  activeColor: context.colors.primary,
                  value: state,
                  onChanged: (v) {
                    controller.termsObs.setValue(v!);
                  },
                ),
              ),
              Gaps.hGap8,
              InkWell(
                onTap: () => AutoRouter.of(context).push(const SettingsRoute()),
                child: Text(
                  "I agree to the terms and conditions",
                  style: AppTextStyle.s15_w500(color: context.colors.textColor),
                ),
              ),
            ],
          );
        });
  }
}
