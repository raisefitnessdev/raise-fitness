part of 'register_widgets_imports.dart';

class RegisterFormWidget extends StatelessWidget {
  final RegisterController controller;
  const RegisterFormWidget({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.formKey,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: GenericTextField(
                  radius: BorderRadius.circular(8).r,
                  controller: controller.firstname,
                  enableBorderColor: context.colors.filedColor,
                  fillColor: context.colors.filedColor,
                  contentPadding: const EdgeInsets.all(10),
                  fieldTypes: FieldTypes.normal,
                  type: TextInputType.text,
                  action: TextInputAction.next,
                  validate: (value) => value?.validateEmpty(),
                  hint: "First name",
                  hintColor: context.colors.primaryGrey,
                  textColor: context.colors.textColor,
                  margin: const EdgeInsets.only(top: 32).r,
                ),
              ),
              Gaps.hGap16,
              Expanded(
                child: GenericTextField(
                  radius: BorderRadius.circular(8).r,
                  controller: controller.lastname,
                  enableBorderColor: context.colors.filedColor,
                  fillColor: context.colors.filedColor,
                  contentPadding: const EdgeInsets.all(10),
                  fieldTypes: FieldTypes.normal,
                  type: TextInputType.text,
                  action: TextInputAction.next,
                  validate: (value) => value?.validateEmpty(),
                  hint: "Last name",
                  hintColor: context.colors.primaryGrey,
                  textColor: context.colors.textColor,
                  margin: const EdgeInsets.only(top: 32).r,
                ),
              ),
            ],
          ),
          GenericTextField(
            radius: BorderRadius.circular(8).r,
            controller: controller.email,
            enableBorderColor: context.colors.filedColor,
            fillColor: context.colors.filedColor,
            contentPadding: const EdgeInsets.all(10),
            fieldTypes: FieldTypes.normal,
            type: TextInputType.emailAddress,
            action: TextInputAction.next,
            validate: (value) => value?.validateEmail(),
            hint: "Email",
            hintColor: context.colors.primaryGrey,
            textColor: context.colors.textColor,
            margin: const EdgeInsets.only(top: 24).r,
          ),
          GenericTextField(
            onTab: () => controller.showDateAlert(context),
            radius: BorderRadius.circular(8).r,
            controller: controller.birthdate,
            enableBorderColor: context.colors.filedColor,
            fillColor: context.colors.filedColor,
            contentPadding: const EdgeInsets.all(10),
            fieldTypes: FieldTypes.clickable,
            type: TextInputType.text,
            action: TextInputAction.next,
            validate: (value) => value?.validateEmpty(),
            hint: "Date of birth",
            hintColor: context.colors.primaryGrey,
            textColor: context.colors.textColor,
            margin: const EdgeInsets.only(top: 24).r,
            suffixIcon: InkWell(
              onTap: () {},
              child: Icon(
                Icons.calendar_month,
                size: 20,
                color: context.colors.textColor,
              ),
            ),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 60.h,
                margin: const EdgeInsets.only(top: 24).r,
                decoration: BoxDecoration(
                  color: context.colors.filedColor,
                  borderRadius: BorderRadius.circular(8).r,
                ),
                child: Center(
                  child: BuildCountryCode(
                    bloc: controller.countryObs, onTap: () {},
                    // => controller.showCountryDialog(context),
                  ),
                ),
              ),
              Gaps.hGap4,
              Expanded(
                child: GenericTextField(
                  radius: BorderRadius.circular(8).r,
                  controller: controller.phone,
                  enableBorderColor: context.colors.filedColor,
                  fillColor: context.colors.filedColor,
                  contentPadding: const EdgeInsets.all(10),
                  fieldTypes: FieldTypes.normal,
                  type: TextInputType.phone,
                  action: TextInputAction.next,
                  validate: (value) => value?.validateEmpty(),
                  hint: "Phone",
                  hintColor: context.colors.primaryGrey,
                  textColor: context.colors.textColor,
                  margin: const EdgeInsets.only(top: 24).r,
                  // prefixIcon: ,
                ),
              ),
            ],
          ),
          Gaps.vGap24,
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "Your gender",
              style:
                  AppTextStyle.s14_w600(color: context.colors.white),
            ),
          ),
          Gaps.vGap10,
          ObsValueConsumer(
              observable: controller.gendrObs,
              builder: (context, state) {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Radio(
                      fillColor: WidgetStateProperty.resolveWith<Color>(
                          (Set<WidgetState> states) {
                        return context.colors.primary;
                      }),
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      visualDensity:
                          const VisualDensity(horizontal: -4, vertical: -4),
                      activeColor: context.colors.primary,
                      value: true,
                      groupValue: state,
                      onChanged: (v) {
                        controller.gendrObs.setValue(v!);
                      },
                    ),
                    Gaps.hGap8,
                    Text(
                      "Male",
                      style: AppTextStyle.s15_w500(
                          color: context.colors.textColor),
                    ),
                    Gaps.hGap22,
                    Radio(
                      fillColor: WidgetStateProperty.resolveWith<Color>(
                          (Set<WidgetState> states) {
                        return context.colors.primary;
                      }),
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      visualDensity:
                          const VisualDensity(horizontal: -4, vertical: -4),
                      activeColor: context.colors.primary,
                      value: false,
                      groupValue: state,
                      onChanged: (v) {
                        controller.gendrObs.setValue(v!);
                      },
                    ),
                    Gaps.hGap8,
                    Text(
                      "Female",
                      style: AppTextStyle.s15_w500(
                          color: context.colors.textColor),
                    ),
                  ],
                );
              }),
          ObsValueConsumer(
            observable: controller.visiblePasObs,
            builder: (context, state) {
              return GenericTextField(
                radius: BorderRadius.circular(8).r,
                controller: controller.password,
                onTab: () => state,
                enableBorderColor: context.colors.filedColor,
                fillColor: context.colors.filedColor,
                fieldTypes: state ? FieldTypes.normal : FieldTypes.password,
                type: TextInputType.text,
                action: TextInputAction.done,
                validate: (value) => value?.validateEmpty(),
                hint: "Password",
                contentPadding: const EdgeInsets.all(10),
                textColor: context.colors.textColor,
                hintColor: context.colors.primaryGrey,
                margin: const EdgeInsets.only(top: 24).r,
                suffixIcon: InkWell(
                  onTap: () => controller.visiblePasObs.setValue(!state),
                  child: Icon(
                    state == true
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    size: 20,
                    color: context.colors.textColor,
                  ),
                ),
              );
            },
          ),
          ObsValueConsumer(
            observable: controller.visibleConfirmPasObs,
            builder: (context, state) {
              return GenericTextField(
                radius: BorderRadius.circular(8).r,
                controller: controller.passwordConfirm,
                onTab: () => state,
                enableBorderColor: context.colors.filedColor,
                fillColor: context.colors.filedColor,
                fieldTypes: state ? FieldTypes.normal : FieldTypes.password,
                type: TextInputType.text,
                action: TextInputAction.done,
                validate: (value) => value?.validatePasswordConfirm(
                    pass: controller.password.text),
                hint: "Confirm Password",
                contentPadding: const EdgeInsets.all(10),
                textColor: context.colors.textColor,
                hintColor: context.colors.primaryGrey,
                margin: const EdgeInsets.only(top: 24),
                suffixIcon: InkWell(
                  onTap: () => controller.visiblePasObs.setValue(!state),
                  child: Icon(
                    state == true
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    size: 20,
                    color: context.colors.textColor,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
