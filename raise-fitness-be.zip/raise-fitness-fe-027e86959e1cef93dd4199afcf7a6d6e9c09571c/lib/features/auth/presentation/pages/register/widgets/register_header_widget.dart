part of 'register_widgets_imports.dart';

class RegisterHeaderWidget extends StatelessWidget {
  const RegisterHeaderWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Image.asset(
          Res.logo,
          height: 55,
          width: 125,
        ),
        Gaps.vGap18,
        Text(
          "Create an account",
          textAlign: TextAlign.center,
          style: AppTextStyle.s30_w600(color: context.colors.textColor)
              .copyWith(fontFamily: AppTheme.conthraxFamily),
        ),
      ],
    );
  }
}
