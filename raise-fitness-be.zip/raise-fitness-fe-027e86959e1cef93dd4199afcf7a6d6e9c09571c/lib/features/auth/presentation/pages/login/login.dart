part of 'login_imports.dart';

@RoutePage(name: "LoginRoute")
class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<StatefulWidget> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final LoginController controller = LoginController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const DefaultAppBar(
        title: "",
        showBack: true,
      ),
      body: GestureDetector(
        onTap: FocusScope.of(context).unfocus,
        child: Column(
          children: [
            Gaps.vGap32,
            Image.asset(
              Res.logo,
              height: 55,
              width: 125,
            ),
            Flexible(
              child: ListView(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                ).r,
                children: [
                  LoginFormWidget(controller: controller),
                  Gaps.vGap24,
                  const ForgetPasswordViewWidget(),
                  Gaps.vGap32,
                  LoginButtonWidget(controller: controller),
                ],
              ),
            ),
            const BuildRegisterWidget(isRegister: true,),
            Gaps.vGap32,
          ],
        ),
      ),
    );
  }
}
