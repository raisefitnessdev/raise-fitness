// ignore_for_file: use_build_context_synchronously

part of 'login_imports.dart';

class LoginController {
  ObsValue<bool> visibleObs = ObsValue.withInit(false);

  final GlobalKey<FormState> formKey = GlobalKey();

  final GlobalKey<CustomButtonState> btnKey = GlobalKey();
  final GlobalKey<ScaffoldState> drawerKey = GlobalKey<ScaffoldState>();
  final TextEditingController name = TextEditingController();
  final TextEditingController password = TextEditingController();

  /// to submit the login form
  Future<bool> onSubmitLoginBtn(BuildContext context) async {
    if (_checkFormValidation(context)) {
      LoginParams params = loginParams();
      var loginResponse = await getIt<AuthRepository>().login(params);
      return _handleLoginResponse(loginResponse, loginParams: params);
    } else {
      return false;
    }
  }

  Future<String?> _getFirebaseToken() async {
    var deviceId = await FirebaseMessaging.instance.getAPNSToken();
    try {
      deviceId = await FirebaseMessaging.instance.getAPNSToken();
    } catch (e) {
      deviceId = "";
    }
    return deviceId;
  }

  bool _handleLoginResponse(MyResult<UserModel> response,
      {LoginParams? loginParams}) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (userModel) {
      context.read<UserCubit>().onUpdateUserData(userModel!);
      GlobalState.instance.set("token", response.data?.token);
      UserHelperService.instance.saveUserData(userModel);
      AppSnackBar.showSimpleToast(
        color: context.colors.black,
        msg: "Welcome back",
        type: ToastType.success,
      );
      if (userModel.user?.status != "active") {
        AutoRouter.of(context).push(ActiveAccount(
            email: userModel.user?.email ?? "", isActivate: true));
      } else {
        AutoRouter.of(context).push(Dashboard(index: 0));
      }

      return true;
    }, isError: (error) {
      return false;
    });
  }

  /// handle login params
  LoginParams loginParams() {
    return LoginParams(
      password: password.text,
      email: name.text,
    );
  }

  bool _checkFormValidation(BuildContext context) {
    return formKey.currentState!.validate();
  }
}
