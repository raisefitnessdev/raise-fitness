part of 'login_widgets_imports.dart';

class LoginFormWidget extends StatelessWidget {
  final LoginController controller;

  const LoginFormWidget({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.formKey,
      child: Column(
        children: [
          GenericTextField(
            radius: BorderRadius.circular(8).r,
            controller: controller.name,
            enableBorderColor: context.colors.filedColor,
            fillColor: context.colors.filedColor,
            contentPadding: const EdgeInsets.all(10),
            fieldTypes: FieldTypes.normal,
            type: TextInputType.emailAddress,
            action: TextInputAction.next,
            validate: (value) => value?.validateEmail(),
            hint: "Email",
            hintColor: context.colors.primaryGrey,
            textColor: context.colors.textColor,
            margin: const EdgeInsets.only(top: 40).r,
          ),
          ObsValueConsumer(
            observable: controller.visibleObs,
            builder: (context, state) {
              return GenericTextField(
                radius: BorderRadius.circular(8).r,
                controller: controller.password,
                onTab: () => state,
                enableBorderColor: context.colors.filedColor,
                fillColor: context.colors.filedColor,
                fieldTypes: state ? FieldTypes.normal : FieldTypes.password,
                type: TextInputType.text,
                action: TextInputAction.done,
                validate: (value) => value?.validateEmpty(),
                hint: "Password",
                contentPadding: const EdgeInsets.all(10),
                textColor: context.colors.textColor,
                hintColor: context.colors.primaryGrey,
                margin: const EdgeInsets.only(top: 40).r,
                suffixIcon: InkWell(
                  onTap: () => controller.visibleObs.setValue(!state),
                  child: Icon(
                    state == true
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    size: 20,
                    color: context.colors.textColor,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
