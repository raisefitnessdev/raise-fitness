import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/bloc/value_state_manager/value_state_manager_import.dart';
import 'package:raise/core/helpers/validator.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/GenericTextField.dart';
import 'package:raise/core/widgets/app_button.dart';
import 'package:raise/env/environment_config_reader.dart';
import '../login_imports.dart';

part 'login_form_widget.dart';
part 'login_button_widget.dart';
part 'forget_password_view_widget.dart';
part 'login_header_widget.dart';
