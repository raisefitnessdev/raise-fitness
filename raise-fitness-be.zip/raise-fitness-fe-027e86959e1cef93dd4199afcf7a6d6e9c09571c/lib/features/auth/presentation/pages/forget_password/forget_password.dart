part of 'forget_password_imports.dart';

@RoutePage()
class ForgetPassword extends StatefulWidget {
  const ForgetPassword({super.key});

  @override
  State<StatefulWidget> createState() => _ForgetPasswordState();
}

class _ForgetPasswordState extends State<ForgetPassword> {
  final ForgetPasswordController controller = ForgetPasswordController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      appBar: const DefaultAppBar(
        showBack: true,
        title: "",
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32).r,
        children: [
          Image.asset(
            Res.logo,
            height: 55,
            width: 125,
          ),
          Gaps.vGap32,
          ForgetPasswordFormWidget(
            controller: controller,
          ),
          ForgetPasswordButtonWidget(
            controller: controller,
          ),
        ],
      ),
    );
  }
}
