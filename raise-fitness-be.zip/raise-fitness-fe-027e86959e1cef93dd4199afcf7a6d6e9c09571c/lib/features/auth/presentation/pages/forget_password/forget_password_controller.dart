part of 'forget_password_imports.dart';

class ForgetPasswordController {
  GlobalKey<FormState> formKey = GlobalKey();

  TextEditingController email = TextEditingController();

  Future<bool> forgetPassword(BuildContext context) async {
    if (_checkFormValidation(context)) {
      var forgetResponse = await getIt<AuthRepository>().forgetPassword(email.text);
      return _handleForgetResponse(forgetResponse, email: email.text);
    } else {
      return false;
    }
  }

  bool _handleForgetResponse(MyResult<String> response,
      {required String email}) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (data) {
        AutoRouter.of(context).push(ActiveAccount(email: email, isActivate: false));
      return true;
    }, isError: (error) {
      return false;
    });
  }

  bool _checkFormValidation(BuildContext context) {
    return formKey.currentState!.validate();
  }
}
