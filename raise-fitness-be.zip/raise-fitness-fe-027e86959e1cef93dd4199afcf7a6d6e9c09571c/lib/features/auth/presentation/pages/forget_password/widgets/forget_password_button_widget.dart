part of 'forget_password_widgets_imports.dart';

class ForgetPasswordButtonWidget extends StatelessWidget {
  final ForgetPasswordController controller;

  const ForgetPasswordButtonWidget({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: AppTextButton.maxCustom(
        onPressed: () => controller.forgetPassword(context),
        bgColor: context.colors.primary,
        txtColor: context.colors.black,
        textSize: 18,
        maxHeight: 55,
        borderRadius: 50,
        text: "Send OTP",
      ),
    );
  }
}
