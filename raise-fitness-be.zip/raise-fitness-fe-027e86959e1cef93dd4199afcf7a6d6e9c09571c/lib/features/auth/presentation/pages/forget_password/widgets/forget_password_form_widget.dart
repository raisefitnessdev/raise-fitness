part of 'forget_password_widgets_imports.dart';

class ForgetPasswordFormWidget extends StatelessWidget {
  final ForgetPasswordController controller;
  const ForgetPasswordFormWidget({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.formKey,
      child: Column(
        children: [
          GenericTextField(
            radius: BorderRadius.circular(8).r,
            controller: controller.email,
            enableBorderColor: context.colors.filedColor,
            fillColor: context.colors.filedColor,
            contentPadding: const EdgeInsets.all(10),
            fieldTypes: FieldTypes.normal,
            type: TextInputType.emailAddress,
            action: TextInputAction.next,
            validate: (value) => value?.validateEmail(),
            hint: "Email",
            hintColor: context.colors.primaryGrey,
            textColor: context.colors.textColor,
            margin: const EdgeInsets.only(top: 40).r,
          ),
        ],
      ),
    );
  }
}
