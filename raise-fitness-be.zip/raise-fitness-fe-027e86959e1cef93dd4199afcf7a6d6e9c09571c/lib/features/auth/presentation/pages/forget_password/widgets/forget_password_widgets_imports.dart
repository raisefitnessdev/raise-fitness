import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/widgets/GenericTextField.dart';
import 'package:raise/core/widgets/app_button.dart';

import 'package:raise/features/auth/presentation/pages/forget_password/forget_password_imports.dart';
import 'package:raise/res.dart';
import 'package:raise/core/helpers/validator.dart';

import '../../../../../../core/theme/text/app_text_style.dart';

part 'forget_password_form_widget.dart';
part 'forget_password_button_widget.dart';
