import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/helpers/global_context.dart';
import 'package:raise/core/helpers/global_state.dart';
import 'package:raise/core/helpers/services/language_service.dart';
import 'package:raise/core/helpers/user_helper_service.dart';
import 'package:raise/core/http/models/result.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/features/auth/domain/repositories/auth_repository.dart';
import 'package:raise/features/auth/presentation/manager/user_cubit/user_cubit.dart';
import 'package:raise/features/auth/presentation/pages/splash/widgets/splash_widgets_imports.dart';

part 'splash.dart';
part 'splash_controller.dart';
