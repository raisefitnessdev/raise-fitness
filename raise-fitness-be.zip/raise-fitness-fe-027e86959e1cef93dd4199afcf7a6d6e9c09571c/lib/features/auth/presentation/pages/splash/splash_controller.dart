// ignore_for_file: use_build_context_synchronously

part of 'splash_imports.dart';

class SplashController {
  void manipulateSaveData(BuildContext context) async {
    var user = await UserHelperService.instance.getUserData();
    await LanguageService.instance.initLanguage();
    await Future.delayed(const Duration(seconds: 2));
    if (user != null) {
      GlobalState.instance.set("token", user.token);
      context.read<UserCubit>().onUpdateUserData(user);
      if (user.user?.status != "active") {
        resendActivation(user.user?.email ?? "");
      } else {
        AutoRouter.of(context).push(Dashboard(index: 0));
      }
    } else {
      AutoRouter.of(context).push(const IntroRoute());
    }
  }

  Future<bool> resendActivation(String email) async {
    var codeResponse = await getIt<AuthRepository>().resendActivation(email);
    return _handleResendResponse(codeResponse, email);
  }

  bool _handleResendResponse(MyResult<String> response, String email) {
    return response.when(isSuccess: (userModel) {
      final context = getIt<GlobalContext>().context();
      AutoRouter.of(context).push(
            ActiveAccount(email: email, isActivate: true));
      return true;
    }, isError: (error) {
      return false;
    });
  }
}
