part of 'splash_widgets_imports.dart';

class SplashLogo extends StatelessWidget {
  const SplashLogo({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Image.asset(
        Res.logo,
        height: 150,
        width: 350,
      ),
    );
  }
}
