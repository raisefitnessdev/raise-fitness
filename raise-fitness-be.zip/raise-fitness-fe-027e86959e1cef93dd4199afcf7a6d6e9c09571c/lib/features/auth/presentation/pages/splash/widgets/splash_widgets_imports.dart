import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/helpers/services/current_version_helper.dart';
import 'package:raise/core/localization/translate.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:raise/res.dart';

part 'splash_logo.dart';

part 'splash_bottom_item_widget.dart';
