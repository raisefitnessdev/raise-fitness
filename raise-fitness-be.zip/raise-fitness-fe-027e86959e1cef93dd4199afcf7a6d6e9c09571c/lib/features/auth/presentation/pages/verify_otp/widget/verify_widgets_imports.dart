import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/helpers/validator.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/GenericTextField.dart';
import 'package:raise/features/auth/presentation/pages/verify_otp/verify_otp_imports.dart';
import 'package:raise/res.dart';

part 'verify_header_widget.dart';

part 'verify_form_widget.dart';
