import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:raise/core/bloc/base_bloc/base_bloc.dart';
import 'package:raise/core/constants/CustomButtonAnimation.dart';
import 'package:raise/features/auth/presentation/pages/verify_otp/widget/verify_widgets_imports.dart';
import 'package:raise/features/auth/presentation/widgets/auth_app_bar_widget.dart';
import 'package:raise/features/auth/presentation/widgets/auth_scaffold_widget.dart';

part 'verify_otp.dart';

part 'verify_otp_controller.dart';
