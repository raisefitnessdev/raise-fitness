import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:raise/core/bloc/device_cubit/device_cubit.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/localization/translate.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/res.dart';

part 'get_code_info_title_widget.dart';

part 'get_code_view_widget.dart';

part 'get_code_phone_screen_widget.dart';
