import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/features/auth/presentation/pages/get_code_info/widgets/get_code_info_widgets_imports.dart';

part 'get_code_info.dart';

part 'get_code_info_controller.dart';
