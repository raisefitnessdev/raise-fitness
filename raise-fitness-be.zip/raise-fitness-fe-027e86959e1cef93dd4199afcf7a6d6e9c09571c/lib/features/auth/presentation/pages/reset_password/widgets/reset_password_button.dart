part of 'reset_password_widgets_imports.dart';

class ResetPasswordButton extends StatelessWidget {
  final ResetPasswordController controller;
  final String code;
  const ResetPasswordButton({super.key, required this.controller, required this.code});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: AppTextButton.maxCustom(
        onPressed: () => controller.resetPassword(context, code),
        bgColor: context.colors.primary,
        txtColor: context.colors.black,
        textSize: 18,
        maxHeight: 55,
        borderRadius: 50,
        text: "Reset Password",
      ),
    );
  }
}
