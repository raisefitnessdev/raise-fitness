part of 'reset_password_widgets_imports.dart';

class ResetPasswordForm extends StatelessWidget {
  final ResetPasswordController controller;
  const ResetPasswordForm({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.formKey,
      child: Column(
        children: [
          ObsValueConsumer(
            observable: controller.visiblePasObs,
            builder: (context, state) {
              return GenericTextField(
                radius: BorderRadius.circular(8).r,
                controller: controller.password,
                onTab: () => state,
                enableBorderColor: context.colors.filedColor,
                fillColor: context.colors.filedColor,
                fieldTypes: state ? FieldTypes.normal : FieldTypes.password,
                type: TextInputType.text,
                action: TextInputAction.done,
                validate: (value) => value?.validateEmpty(),
                hint: "New Password",
                contentPadding: const EdgeInsets.all(10),
                textColor: context.colors.textColor,
                hintColor: context.colors.primaryGrey,
                margin: const EdgeInsets.only(top: 24).r,
                suffixIcon: InkWell(
                  onTap: () => controller.visiblePasObs.setValue(!state),
                  child: Icon(
                    state == true
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    size: 20,
                    color: context.colors.textColor,
                  ),
                ),
              );
            },
          ),
          ObsValueConsumer(
            observable: controller.visibleConfirmPasObs,
            builder: (context, state) {
              return GenericTextField(
                radius: BorderRadius.circular(8).r,
                controller: controller.confirmPassword,
                onTab: () => state,
                enableBorderColor: context.colors.filedColor,
                fillColor: context.colors.filedColor,
                fieldTypes: state ? FieldTypes.normal : FieldTypes.password,
                type: TextInputType.text,
                action: TextInputAction.done,
                validate: (value) => value?.validatePasswordConfirm(
                    pass: controller.password.text),
                hint: "Confirm Password",
                contentPadding: const EdgeInsets.all(10),
                textColor: context.colors.textColor,
                hintColor: context.colors.primaryGrey,
                margin: const EdgeInsets.only(top: 24),
                suffixIcon: InkWell(
                  onTap: () => controller.visiblePasObs.setValue(!state),
                  child: Icon(
                    state == true
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    size: 20,
                    color: context.colors.textColor,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
