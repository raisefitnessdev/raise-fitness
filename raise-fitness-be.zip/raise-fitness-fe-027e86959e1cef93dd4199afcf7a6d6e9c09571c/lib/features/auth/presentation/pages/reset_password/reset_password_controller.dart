part of 'reset_password_imports.dart';

class ResetPasswordController {
  final GlobalKey<FormState> formKey = GlobalKey();

  ObsValue<bool> visiblePasObs = ObsValue.withInit(false);
  ObsValue<bool> visibleConfirmPasObs = ObsValue.withInit(false);

  TextEditingController password = TextEditingController();
  TextEditingController confirmPassword = TextEditingController();

  Future<bool> resetPassword(BuildContext context, String code) async {
    if (_checkFormValidation(context)) {
      ResetPasswordParams params = resetPasswordParams(code);
      var resetResponse = await getIt<AuthRepository>().resetPassword(params);
      return _handleResetResponse(resetResponse);
    } else {
      return false;
    }
  }

  bool _handleResetResponse(MyResult<String> response) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (userModel) {
      AppSnackBar.showSimpleToast(
        color: context.colors.black,
        msg: "Reset Password Success",
        type: ToastType.success,
      );
        AutoRouter.of(context).push(const IntroRoute());
      return true;
    }, isError: (error) {
      return false;
    });
  }

  ResetPasswordParams resetPasswordParams(String code) {
    return ResetPasswordParams(
      password: password.text,
      code: code,
      confirm: confirmPassword.text,
    );
  }

  bool _checkFormValidation(BuildContext context) {
    return formKey.currentState!.validate();
  }
}
