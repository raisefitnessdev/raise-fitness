part of 'reset_password_imports.dart';

@RoutePage()
class ResetPassword extends StatefulWidget {
  final String code;
  const ResetPassword({super.key, required this.code});

  @override
  State<StatefulWidget> createState() => _ResetPasswordState();
}

class _ResetPasswordState extends State<ResetPassword> {
  final ResetPasswordController controller = ResetPasswordController();
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      appBar: const DefaultAppBar(
        showBack: true,
        title: "",
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32).r,
        children: [
          Image.asset(
            Res.logo,
            height: 55,
            width: 125,
          ),
          Gaps.vGap32,
          ResetPasswordForm(controller: controller),
          ResetPasswordButton(
            code: widget.code,
            controller: controller,
          ),
        ],
      ),
    );
  }
}
