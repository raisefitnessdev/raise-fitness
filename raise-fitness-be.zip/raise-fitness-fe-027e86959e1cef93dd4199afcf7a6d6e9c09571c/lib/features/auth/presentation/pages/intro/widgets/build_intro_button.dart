part of "intro_widgets_imports.dart";

class BuildIntroButton extends StatelessWidget {
  const BuildIntroButton({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24).r,
      child: AppTextButton.maxCustom(
        onPressed: () => AutoRouter.of(context).push(const LoginRoute()),
        bgColor: context.colors.primary,
        txtColor: context.colors.black,
        textSize: 18,
        maxHeight: 55,
        borderRadius: 50,
        text: "Login  Now",
      ),
    );
  }
}
