import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/theme/themes/app_theme.dart';
import 'package:raise/core/widgets/app_button.dart';
import 'package:raise/features/auth/presentation/pages/intro/widgets/intro_widgets_imports.dart';
import 'package:raise/features/auth/presentation/widgets/build_register_widget.dart';
import 'package:raise/res.dart';

part "intro.dart";
part "intro_controller.dart";
