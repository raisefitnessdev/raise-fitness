part of "intro_imports.dart";

@RoutePage(name: "IntroRoute")
class Intro extends StatefulWidget {
  const Intro({super.key});

  @override
  IntroState createState() => IntroState();
}

class IntroState extends State<Intro> {
  final IntroController controller = IntroController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: context.colors.background,
        body: ListView(
          padding: EdgeInsets.symmetric(vertical: MediaQuery.of(context).size.height*0.35).r,
          children: [
            Image.asset(
              Res.logo,
              height: 100,
              width: 235,
            ),
            Gaps.vGap64,
            const BuildIntroButton(),
            Gaps.vGap20,
            const BuildRegisterWidget(
              isRegister: true,
            ),
          ],
        ),
      ),
    );
  }
}
