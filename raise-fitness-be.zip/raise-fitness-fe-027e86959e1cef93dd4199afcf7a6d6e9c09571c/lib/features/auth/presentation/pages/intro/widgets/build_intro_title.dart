part of "intro_widgets_imports.dart";

class BuildIntroTitle extends StatelessWidget {
  const BuildIntroTitle({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
      Gaps.vGap50,
      Text(
        "Workout program made for you",
        textAlign: TextAlign.center,
        style: AppTextStyle.s25_w600(color: context.colors.textColor)
            .copyWith(fontFamily: AppTheme.conthraxFamily),
      ),
      Gaps.vGap14,
      Text(
        "Get your perfect workout with the perfect trainers. Many healthy benefits for you Strength training benefits for you",
        textAlign: TextAlign.center,
        style: AppTextStyle.s18_w400(color: context.colors.secondaryText),
      ),
      Gaps.vGap32,
    ]);
  }
}
