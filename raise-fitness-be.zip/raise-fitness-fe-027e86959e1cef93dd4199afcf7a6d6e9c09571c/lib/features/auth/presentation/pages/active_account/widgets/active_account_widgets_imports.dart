import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:raise/core/bloc/base_bloc/base_bloc.dart';
import 'package:raise/core/bloc/base_bloc/base_bloc_builder.dart';
import 'package:raise/core/bloc/base_bloc/base_state.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/theme/themes/app_theme.dart';
import 'package:raise/core/widgets/LoadingButton.dart';
import 'package:raise/core/widgets/app_button.dart';
import 'package:raise/features/auth/presentation/pages/active_account/active_account_imports.dart';
import 'package:raise/res.dart';

part 'build_active_button.dart';
part "active_account_header.dart";
part "verify_otp_timer.dart";
