part of 'active_account_imports.dart';

@RoutePage()
class ActiveAccount extends StatefulWidget {
  final String email;
  final bool isActivate;
  const ActiveAccount(
      {super.key, required this.email, required this.isActivate});

  @override
  State<StatefulWidget> createState() => _ActiveAccountState();
}

class _ActiveAccountState extends State<ActiveAccount> {
  final ActiveAccountController controller = ActiveAccountController();

  @override
  void initState() {
    controller.initTimer();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      appBar: const DefaultAppBar(
        showBack: true,
        title: "",
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 20),
        children: [
          ActiveAccountHeader(
            email: widget.email,
          ),
          Gaps.vGap50,
          PinFieldWidget(
            onComplete: controller.onComplete,
          ),
          VerifyOTPTimer(
            controller: controller,
            email: widget.email,
            isActivate: widget.isActivate,
          ),
          BuildActiveButton(
            controller: controller,
            isActivate: widget.isActivate,
          ),
        ],
      ),
    );
  }
}
