import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:raise/core/bloc/base_bloc/base_bloc.dart';
import 'package:raise/core/constants/CustomButtonAnimation.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/helpers/global_context.dart';
import 'package:raise/core/helpers/global_state.dart';
import 'package:raise/core/helpers/user_helper_service.dart';
import 'package:raise/core/http/models/result.dart';
import 'package:raise/core/routes/router_imports.gr.dart';

import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/widgets/default_app_bar.dart';
import 'package:raise/features/auth/data/models/user_model/user_model.dart';
import 'package:raise/features/auth/domain/repositories/auth_repository.dart';
import 'package:raise/features/auth/presentation/manager/user_cubit/user_cubit.dart';
import 'package:raise/features/auth/presentation/widgets/auth_app_bar_widget.dart';
import 'package:raise/features/auth/presentation/widgets/auth_header_title_widget.dart';
import 'package:raise/features/auth/presentation/widgets/pin_field_widget.dart';
import 'package:stop_watch_timer/stop_watch_timer.dart';

import 'widgets/active_account_widgets_imports.dart';

part 'active_account.dart';
part 'active_account_controller.dart';
