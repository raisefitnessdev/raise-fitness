part of 'active_account_widgets_imports.dart';

class VerifyOTPTimer extends StatelessWidget {
  final ActiveAccountController controller;
  final String email;
  final bool isActivate;
  const VerifyOTPTimer(
      {super.key, required this.controller, required this.email, required this.isActivate});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<BaseBloc<String>, BaseState<String>>(
      bloc: controller.timeCubit,
      builder: (context, state) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24).r,
          child: Visibility(
            visible: state.data != "00:00",
            replacement: InkWell(
              onTap: () => isActivate? controller.resendActivation(email) : controller.resendConfirmation(email),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "Didn't recieve code?",
                    style: AppTextStyle.s14_w400(
                        color: context.colors.secondaryText),
                  ),
                  Gaps.vGap5,
                  Text(
                    "Resend Code",
                    style: AppTextStyle.s14_w600(color: context.colors.primary)
                        .copyWith(
                            decoration: TextDecoration.underline,
                            decorationColor: context.colors.primary),
                  ),
                ],
              ),
            ),
            child: Text(
              " ${state.data ?? ""}",
              textAlign: TextAlign.center,
              style: AppTextStyle.s18_w700(color: context.colors.primary),
            ),
          ),
        );
      },
    );
  }
}
