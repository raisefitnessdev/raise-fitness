part of 'active_account_widgets_imports.dart';

class BuildActiveButton extends StatelessWidget {
  final ActiveAccountController controller;
  final bool isActivate;
  const BuildActiveButton(
      {super.key, required this.controller, required this.isActivate});

  @override
  Widget build(BuildContext context) {
    return BaseBlocBuilder(
      bloc: controller.codeCubit,
      onSuccessWidget: (data) {
        return AbsorbPointer(
          absorbing: !data,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: AppTextButton.maxCustom(
              text: "Confirm",
              onPressed: !data
                  ? () {}
                  : () => isActivate
                      ? controller.activeAccount()
                      : controller.checkForget(),
              bgColor:
                  !data ? context.colors.greyWhite : context.colors.primary,
              txtColor: !data ? context.colors.textColor : context.colors.black,
              textSize: 18,
              maxHeight: 55,
              borderRadius: 50,
            ),
          ),
        );
      },
    );
  }
}
