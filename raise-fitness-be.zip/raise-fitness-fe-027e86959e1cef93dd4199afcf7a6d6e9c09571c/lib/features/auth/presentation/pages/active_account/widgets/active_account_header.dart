part of "active_account_widgets_imports.dart";

class ActiveAccountHeader extends StatelessWidget {
  final String email;
  const ActiveAccountHeader({super.key, required this.email});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Image.asset(
          Res.logo,
          height: 55,
          width: 125,
        ),
        Gaps.vGap18,
        Text(
          "Confirm Your Email to Get Started",
          textAlign: TextAlign.center,
          style: AppTextStyle.s25_w600(color: context.colors.textColor)
              .copyWith(fontFamily: AppTheme.conthraxFamily),
        ),
        Gaps.vGap18,
        Text(
          email,
          textAlign: TextAlign.center,
          style: AppTextStyle.s16_w500(color: context.colors.primaryText),
        ),
      ],
    );
  }
}
