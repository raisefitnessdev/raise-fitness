part of 'active_account_imports.dart';

class ActiveAccountController {
  String? code;
  final BaseBloc<bool> codeCubit = BaseBloc(false);

  BaseBloc<String> timeCubit = BaseBloc("00:00");

  StopWatchTimer? stopWatchTimer;

  final int maxTimeValue = 59;

  void initTimer() {
    stopWatchTimer = StopWatchTimer(
      mode: StopWatchMode.countDown,
      onChange: (value) {
        final displayTime = StopWatchTimer.getDisplayTime(value,
            milliSecond: false, hours: false);
        timeCubit.successState(displayTime);
      },
    );
    stopWatchTimer?.setPresetSecondTime(maxTimeValue);
    stopWatchTimer!.onStartTimer();
  }

  void onComplete(String value) {
    codeCubit.successState(value.length == 6);
    code = value;
  }

  Future<bool> activeAccount() async {
    var codeResponse = await getIt<AuthRepository>().activeAccount(code!);
    return _handleActivateResponse(codeResponse, true);
  }

  Future<bool> checkForget() async {
    var codeResponse = await getIt<AuthRepository>().checkForget(code!);
    return _handleResetResponse(codeResponse, false);
  }

  Future<bool> resendActivation(String email) async {
    var codeResponse = await getIt<AuthRepository>().resendActivation(email);
    return _handleResendResponse(codeResponse);
  }

  Future<bool> resendConfirmation(String email) async {
    var codeResponse = await getIt<AuthRepository>().resendConfirmation(email);
    return _handleResendResponse(codeResponse);
  }

  bool _handleResendResponse(MyResult<String> response) {
    return response.when(isSuccess: (userModel) {
      initTimer();
      return true;
    }, isError: (error) {
      return false;
    });
  }

  bool _handleActivateResponse(MyResult<UserModel> response, bool isActivate) {
    return response.when(isSuccess: (userModel) {
      final context = getIt<GlobalContext>().context();
        context.read<UserCubit>().onUpdateUserData(userModel!);
      GlobalState.instance.set("token", response.data?.token);
      UserHelperService.instance.saveUserData(userModel);
        AutoRouter.of(context).push(Dashboard(index: 0));
      return true;
    }, isError: (error) {
      return false;
    });
  }

  bool _handleResetResponse(MyResult<bool> response, bool isActivate) {
    return response.when(isSuccess: (data) {
      final context = getIt<GlobalContext>().context();
        AutoRouter.of(context).push(ResetPassword(code: code??""));
      return true;
    }, isError: (error) {
      return false;
    });
  }
}
