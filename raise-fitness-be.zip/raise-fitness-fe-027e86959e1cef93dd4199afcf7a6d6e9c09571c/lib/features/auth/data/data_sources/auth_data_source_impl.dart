// ignore_for_file: avoid_dynamic_calls

import 'package:raise/core/http/generic_http/api_names.dart';
import 'package:raise/core/http/generic_http/generic_http.dart';
import 'package:raise/core/http/models/http_request_model.dart';
import 'package:raise/core/http/models/result.dart';
import 'package:raise/features/auth/data/data_sources/auth_data_source.dart';
import 'package:raise/features/auth/data/models/user_model/user_model.dart';
import 'package:raise/features/auth/domain/entity/login_params.dart';
import 'package:injectable/injectable.dart';
import 'package:raise/features/auth/domain/entity/register_params.dart';
import 'package:raise/features/auth/domain/entity/reset_password_params.dart';

@Injectable(as: AuthDataSource)
class AuthDataSourceImpl extends AuthDataSource {
  @override
  Future<MyResult<UserModel>> login(LoginParams param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.login,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      isFormData: true,
      requestBody: param.toJson(),
      responseKey: (data) => data['data'],
      showLoader: true,
      toJsonFunc: (json) => UserModel.fromJson(json),
      errorFunc: (json)=> json['msg']
    );
    return await GenericHttpImpl<UserModel>()(model);
  }

  @override
  Future<MyResult<UserModel>> register(RegisterParams param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.register,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      isFormData: true,
      requestBody: param.toJson(),
      responseKey: (data) => data['data'],
      showLoader: true,
      toJsonFunc: (json) => UserModel.fromJson(json),
      errorFunc: (json)=> json['msg']
    );
    return await GenericHttpImpl<UserModel>()(model);
  }

  @override
  Future<MyResult<UserModel>> activeAccount(String param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.activeAccount,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: {"activation_code": param},
      responseKey: (data) => data['data'],
      showLoader: true,
      toJsonFunc: (json) => UserModel.fromJson(json),
      errorFunc: (json)=> json['msg']
    );
    return await GenericHttpImpl<UserModel>()(model);
  }

  @override
  Future<MyResult<String>> resendActivation(String param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.resendActivation,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: {"email": param},
      responseKey: (data) => data['data'],
      showLoader: true,
      errorFunc: (json)=> json['msg']
    );
    return await GenericHttpImpl<String>()(model);
  }

  @override
  Future<MyResult<String>> resendConfirmation(String param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.resendConfirmation,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: {"email": param},
      responseKey: (data) => data['data'],
      showLoader: true,
      errorFunc: (json)=> json['msg']
    );
    return await GenericHttpImpl<String>()(model);
  }

  @override
  Future<MyResult<String>> forgetPassword(String param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.forgetPassword,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: {"email": param},
      responseKey: (data) => data['data'],
      showLoader: true,
      errorFunc: (json)=> json['msg']
    );
    return await GenericHttpImpl<String>()(model);
  }

  @override
  Future<MyResult<bool>> checkForget(String param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.checkForget,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: {"confirmation_code": param},
      responseKey: (data) => data['value'],
      showLoader: true,
      errorFunc: (json)=> json['msg']
    );
    return await GenericHttpImpl<bool>()(model);
  }

  @override
  Future<MyResult<String>> resetPassword(ResetPasswordParams param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.resetPassword,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: param.toJson(),
      responseKey: (data) => data['data'],
      showLoader: true,
      errorFunc: (json)=> json['msg']
    );
    return await GenericHttpImpl<String>()(model);
  }
}
