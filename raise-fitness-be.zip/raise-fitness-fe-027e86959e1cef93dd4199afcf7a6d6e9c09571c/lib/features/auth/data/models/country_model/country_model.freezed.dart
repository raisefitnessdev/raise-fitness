// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'country_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

CountryModel _$CountryModelFromJson(Map<String, dynamic> json) {
  return _CountryModel.fromJson(json);
}

/// @nodoc
mixin _$CountryModel {
  @JsonKey(name: "id")
  int? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "id")
  set id(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "name")
  String? get name => throw _privateConstructorUsedError;
  @JsonKey(name: "name")
  set name(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "iso3")
  String? get iso3 => throw _privateConstructorUsedError;
  @JsonKey(name: "iso3")
  set iso3(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "iso")
  String? get iso => throw _privateConstructorUsedError;
  @JsonKey(name: "iso")
  set iso(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "nicename")
  String? get nicename => throw _privateConstructorUsedError;
  @JsonKey(name: "nicename")
  set nicename(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "numcode")
  String? get numcode => throw _privateConstructorUsedError;
  @JsonKey(name: "numcode")
  set numcode(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "phonecode")
  String? get phonecode => throw _privateConstructorUsedError;
  @JsonKey(name: "phonecode")
  set phonecode(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "flag")
  String? get flag => throw _privateConstructorUsedError;
  @JsonKey(name: "flag")
  set flag(String? value) => throw _privateConstructorUsedError;

  /// Serializes this CountryModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of CountryModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $CountryModelCopyWith<CountryModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CountryModelCopyWith<$Res> {
  factory $CountryModelCopyWith(
          CountryModel value, $Res Function(CountryModel) then) =
      _$CountryModelCopyWithImpl<$Res, CountryModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "name") String? name,
      @JsonKey(name: "iso3") String? iso3,
      @JsonKey(name: "iso") String? iso,
      @JsonKey(name: "nicename") String? nicename,
      @JsonKey(name: "numcode") String? numcode,
      @JsonKey(name: "phonecode") String? phonecode,
      @JsonKey(name: "flag") String? flag});
}

/// @nodoc
class _$CountryModelCopyWithImpl<$Res, $Val extends CountryModel>
    implements $CountryModelCopyWith<$Res> {
  _$CountryModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of CountryModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? iso3 = freezed,
    Object? iso = freezed,
    Object? nicename = freezed,
    Object? numcode = freezed,
    Object? phonecode = freezed,
    Object? flag = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      iso3: freezed == iso3
          ? _value.iso3
          : iso3 // ignore: cast_nullable_to_non_nullable
              as String?,
      iso: freezed == iso
          ? _value.iso
          : iso // ignore: cast_nullable_to_non_nullable
              as String?,
      nicename: freezed == nicename
          ? _value.nicename
          : nicename // ignore: cast_nullable_to_non_nullable
              as String?,
      numcode: freezed == numcode
          ? _value.numcode
          : numcode // ignore: cast_nullable_to_non_nullable
              as String?,
      phonecode: freezed == phonecode
          ? _value.phonecode
          : phonecode // ignore: cast_nullable_to_non_nullable
              as String?,
      flag: freezed == flag
          ? _value.flag
          : flag // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CountryModelImplCopyWith<$Res>
    implements $CountryModelCopyWith<$Res> {
  factory _$$CountryModelImplCopyWith(
          _$CountryModelImpl value, $Res Function(_$CountryModelImpl) then) =
      __$$CountryModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "name") String? name,
      @JsonKey(name: "iso3") String? iso3,
      @JsonKey(name: "iso") String? iso,
      @JsonKey(name: "nicename") String? nicename,
      @JsonKey(name: "numcode") String? numcode,
      @JsonKey(name: "phonecode") String? phonecode,
      @JsonKey(name: "flag") String? flag});
}

/// @nodoc
class __$$CountryModelImplCopyWithImpl<$Res>
    extends _$CountryModelCopyWithImpl<$Res, _$CountryModelImpl>
    implements _$$CountryModelImplCopyWith<$Res> {
  __$$CountryModelImplCopyWithImpl(
      _$CountryModelImpl _value, $Res Function(_$CountryModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of CountryModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? iso3 = freezed,
    Object? iso = freezed,
    Object? nicename = freezed,
    Object? numcode = freezed,
    Object? phonecode = freezed,
    Object? flag = freezed,
  }) {
    return _then(_$CountryModelImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      iso3: freezed == iso3
          ? _value.iso3
          : iso3 // ignore: cast_nullable_to_non_nullable
              as String?,
      iso: freezed == iso
          ? _value.iso
          : iso // ignore: cast_nullable_to_non_nullable
              as String?,
      nicename: freezed == nicename
          ? _value.nicename
          : nicename // ignore: cast_nullable_to_non_nullable
              as String?,
      numcode: freezed == numcode
          ? _value.numcode
          : numcode // ignore: cast_nullable_to_non_nullable
              as String?,
      phonecode: freezed == phonecode
          ? _value.phonecode
          : phonecode // ignore: cast_nullable_to_non_nullable
              as String?,
      flag: freezed == flag
          ? _value.flag
          : flag // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true)
class _$CountryModelImpl extends _CountryModel {
  _$CountryModelImpl(
      {@JsonKey(name: "id") required this.id,
      @JsonKey(name: "name") required this.name,
      @JsonKey(name: "iso3") required this.iso3,
      @JsonKey(name: "iso") required this.iso,
      @JsonKey(name: "nicename") required this.nicename,
      @JsonKey(name: "numcode") required this.numcode,
      @JsonKey(name: "phonecode") required this.phonecode,
      @JsonKey(name: "flag") required this.flag})
      : super._();

  factory _$CountryModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$CountryModelImplFromJson(json);

  @override
  @JsonKey(name: "id")
  int? id;
  @override
  @JsonKey(name: "name")
  String? name;
  @override
  @JsonKey(name: "iso3")
  String? iso3;
  @override
  @JsonKey(name: "iso")
  String? iso;
  @override
  @JsonKey(name: "nicename")
  String? nicename;
  @override
  @JsonKey(name: "numcode")
  String? numcode;
  @override
  @JsonKey(name: "phonecode")
  String? phonecode;
  @override
  @JsonKey(name: "flag")
  String? flag;

  @override
  String toString() {
    return 'CountryModel(id: $id, name: $name, iso3: $iso3, iso: $iso, nicename: $nicename, numcode: $numcode, phonecode: $phonecode, flag: $flag)';
  }

  /// Create a copy of CountryModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$CountryModelImplCopyWith<_$CountryModelImpl> get copyWith =>
      __$$CountryModelImplCopyWithImpl<_$CountryModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CountryModelImplToJson(
      this,
    );
  }
}

abstract class _CountryModel extends CountryModel {
  factory _CountryModel(
      {@JsonKey(name: "id") required int? id,
      @JsonKey(name: "name") required String? name,
      @JsonKey(name: "iso3") required String? iso3,
      @JsonKey(name: "iso") required String? iso,
      @JsonKey(name: "nicename") required String? nicename,
      @JsonKey(name: "numcode") required String? numcode,
      @JsonKey(name: "phonecode") required String? phonecode,
      @JsonKey(name: "flag") required String? flag}) = _$CountryModelImpl;
  _CountryModel._() : super._();

  factory _CountryModel.fromJson(Map<String, dynamic> json) =
      _$CountryModelImpl.fromJson;

  @override
  @JsonKey(name: "id")
  int? get id;
  @JsonKey(name: "id")
  set id(int? value);
  @override
  @JsonKey(name: "name")
  String? get name;
  @JsonKey(name: "name")
  set name(String? value);
  @override
  @JsonKey(name: "iso3")
  String? get iso3;
  @JsonKey(name: "iso3")
  set iso3(String? value);
  @override
  @JsonKey(name: "iso")
  String? get iso;
  @JsonKey(name: "iso")
  set iso(String? value);
  @override
  @JsonKey(name: "nicename")
  String? get nicename;
  @JsonKey(name: "nicename")
  set nicename(String? value);
  @override
  @JsonKey(name: "numcode")
  String? get numcode;
  @JsonKey(name: "numcode")
  set numcode(String? value);
  @override
  @JsonKey(name: "phonecode")
  String? get phonecode;
  @JsonKey(name: "phonecode")
  set phonecode(String? value);
  @override
  @JsonKey(name: "flag")
  String? get flag;
  @JsonKey(name: "flag")
  set flag(String? value);

  /// Create a copy of CountryModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$CountryModelImplCopyWith<_$CountryModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
