// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'country_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CountryModelImpl _$$CountryModelImplFromJson(Map<String, dynamic> json) =>
    _$CountryModelImpl(
      id: (json['id'] as num?)?.toInt(),
      name: json['name'] as String?,
      iso3: json['iso3'] as String?,
      iso: json['iso'] as String?,
      nicename: json['nicename'] as String?,
      numcode: json['numcode'] as String?,
      phonecode: json['phonecode'] as String?,
      flag: json['flag'] as String?,
    );

Map<String, dynamic> _$$CountryModelImplToJson(_$CountryModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'iso3': instance.iso3,
      'iso': instance.iso,
      'nicename': instance.nicename,
      'numcode': instance.numcode,
      'phonecode': instance.phonecode,
      'flag': instance.flag,
    };
