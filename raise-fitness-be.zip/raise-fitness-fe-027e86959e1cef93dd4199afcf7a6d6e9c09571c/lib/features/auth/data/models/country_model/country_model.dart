import 'package:freezed_annotation/freezed_annotation.dart';

part 'country_model.freezed.dart';
part 'country_model.g.dart';

@unfreezed
@immutable
class CountryModel with _$CountryModel {
  const CountryModel._();

  @JsonSerializable(explicitToJson: true)
  factory CountryModel({
    @JsonKey(name: "id") required int? id,
    @JsonKey(name: "name") required String? name,
    @JsonKey(name: "iso3") required String? iso3,
    @JsonKey(name: "iso") required String? iso,
    @JsonKey(name: "nicename") required String? nicename,
    @JsonKey(name: "numcode") required String? numcode,
    @JsonKey(name: "phonecode") required String? phonecode,
    @JsonKey(name: "flag") required String? flag,
  }) = _CountryModel;

  factory CountryModel.fromJson(Map<String, dynamic> json) =>
      _$CountryModelFromJson(json);
}
