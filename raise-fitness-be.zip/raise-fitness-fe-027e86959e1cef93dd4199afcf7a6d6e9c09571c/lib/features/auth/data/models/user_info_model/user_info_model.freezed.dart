// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_info_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

UserInfoModel _$UserInfoModelFromJson(Map<String, dynamic> json) {
  return _UserInfoModel.fromJson(json);
}

/// @nodoc
mixin _$UserInfoModel {
  @JsonKey(name: 'id')
  int? get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'id')
  set id(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'first_name')
  String? get firstname => throw _privateConstructorUsedError;
  @JsonKey(name: 'first_name')
  set firstname(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'last_name')
  String? get lastname => throw _privateConstructorUsedError;
  @JsonKey(name: 'last_name')
  set lastname(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'phone')
  String? get phone => throw _privateConstructorUsedError;
  @JsonKey(name: 'phone')
  set phone(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'email')
  String? get email => throw _privateConstructorUsedError;
  @JsonKey(name: 'email')
  set email(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'birthday')
  String? get birthday => throw _privateConstructorUsedError;
  @JsonKey(name: 'birthday')
  set birthday(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'gender')
  String? get gender => throw _privateConstructorUsedError;
  @JsonKey(name: 'gender')
  set gender(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'activation_code')
  String? get activationCode => throw _privateConstructorUsedError;
  @JsonKey(name: 'activation_code')
  set activationCode(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'confirmation_code')
  String? get confirmationCode => throw _privateConstructorUsedError;
  @JsonKey(name: 'confirmation_code')
  set confirmationCode(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'status')
  String? get status => throw _privateConstructorUsedError;
  @JsonKey(name: 'status')
  set status(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'email_verified_at')
  String? get emailVerifiedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'email_verified_at')
  set emailVerifiedAt(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'avatar')
  String? get avatar => throw _privateConstructorUsedError;
  @JsonKey(name: 'avatar')
  set avatar(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: 'is_bought_free_package')
  String? get isBoughtFreePackage => throw _privateConstructorUsedError;
  @JsonKey(name: 'is_bought_free_package')
  set isBoughtFreePackage(String? value) => throw _privateConstructorUsedError;

  /// Serializes this UserInfoModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of UserInfoModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $UserInfoModelCopyWith<UserInfoModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserInfoModelCopyWith<$Res> {
  factory $UserInfoModelCopyWith(
          UserInfoModel value, $Res Function(UserInfoModel) then) =
      _$UserInfoModelCopyWithImpl<$Res, UserInfoModel>;
  @useResult
  $Res call(
      {@JsonKey(name: 'id') int? id,
      @JsonKey(name: 'first_name') String? firstname,
      @JsonKey(name: 'last_name') String? lastname,
      @JsonKey(name: 'phone') String? phone,
      @JsonKey(name: 'email') String? email,
      @JsonKey(name: 'birthday') String? birthday,
      @JsonKey(name: 'gender') String? gender,
      @JsonKey(name: 'activation_code') String? activationCode,
      @JsonKey(name: 'confirmation_code') String? confirmationCode,
      @JsonKey(name: 'status') String? status,
      @JsonKey(name: 'email_verified_at') String? emailVerifiedAt,
      @JsonKey(name: 'avatar') String? avatar,
      @JsonKey(name: 'is_bought_free_package') String? isBoughtFreePackage});
}

/// @nodoc
class _$UserInfoModelCopyWithImpl<$Res, $Val extends UserInfoModel>
    implements $UserInfoModelCopyWith<$Res> {
  _$UserInfoModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of UserInfoModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? firstname = freezed,
    Object? lastname = freezed,
    Object? phone = freezed,
    Object? email = freezed,
    Object? birthday = freezed,
    Object? gender = freezed,
    Object? activationCode = freezed,
    Object? confirmationCode = freezed,
    Object? status = freezed,
    Object? emailVerifiedAt = freezed,
    Object? avatar = freezed,
    Object? isBoughtFreePackage = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      firstname: freezed == firstname
          ? _value.firstname
          : firstname // ignore: cast_nullable_to_non_nullable
              as String?,
      lastname: freezed == lastname
          ? _value.lastname
          : lastname // ignore: cast_nullable_to_non_nullable
              as String?,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      birthday: freezed == birthday
          ? _value.birthday
          : birthday // ignore: cast_nullable_to_non_nullable
              as String?,
      gender: freezed == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String?,
      activationCode: freezed == activationCode
          ? _value.activationCode
          : activationCode // ignore: cast_nullable_to_non_nullable
              as String?,
      confirmationCode: freezed == confirmationCode
          ? _value.confirmationCode
          : confirmationCode // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      emailVerifiedAt: freezed == emailVerifiedAt
          ? _value.emailVerifiedAt
          : emailVerifiedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      avatar: freezed == avatar
          ? _value.avatar
          : avatar // ignore: cast_nullable_to_non_nullable
              as String?,
      isBoughtFreePackage: freezed == isBoughtFreePackage
          ? _value.isBoughtFreePackage
          : isBoughtFreePackage // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$UserInfoModelImplCopyWith<$Res>
    implements $UserInfoModelCopyWith<$Res> {
  factory _$$UserInfoModelImplCopyWith(
          _$UserInfoModelImpl value, $Res Function(_$UserInfoModelImpl) then) =
      __$$UserInfoModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: 'id') int? id,
      @JsonKey(name: 'first_name') String? firstname,
      @JsonKey(name: 'last_name') String? lastname,
      @JsonKey(name: 'phone') String? phone,
      @JsonKey(name: 'email') String? email,
      @JsonKey(name: 'birthday') String? birthday,
      @JsonKey(name: 'gender') String? gender,
      @JsonKey(name: 'activation_code') String? activationCode,
      @JsonKey(name: 'confirmation_code') String? confirmationCode,
      @JsonKey(name: 'status') String? status,
      @JsonKey(name: 'email_verified_at') String? emailVerifiedAt,
      @JsonKey(name: 'avatar') String? avatar,
      @JsonKey(name: 'is_bought_free_package') String? isBoughtFreePackage});
}

/// @nodoc
class __$$UserInfoModelImplCopyWithImpl<$Res>
    extends _$UserInfoModelCopyWithImpl<$Res, _$UserInfoModelImpl>
    implements _$$UserInfoModelImplCopyWith<$Res> {
  __$$UserInfoModelImplCopyWithImpl(
      _$UserInfoModelImpl _value, $Res Function(_$UserInfoModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of UserInfoModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? firstname = freezed,
    Object? lastname = freezed,
    Object? phone = freezed,
    Object? email = freezed,
    Object? birthday = freezed,
    Object? gender = freezed,
    Object? activationCode = freezed,
    Object? confirmationCode = freezed,
    Object? status = freezed,
    Object? emailVerifiedAt = freezed,
    Object? avatar = freezed,
    Object? isBoughtFreePackage = freezed,
  }) {
    return _then(_$UserInfoModelImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      firstname: freezed == firstname
          ? _value.firstname
          : firstname // ignore: cast_nullable_to_non_nullable
              as String?,
      lastname: freezed == lastname
          ? _value.lastname
          : lastname // ignore: cast_nullable_to_non_nullable
              as String?,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      birthday: freezed == birthday
          ? _value.birthday
          : birthday // ignore: cast_nullable_to_non_nullable
              as String?,
      gender: freezed == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String?,
      activationCode: freezed == activationCode
          ? _value.activationCode
          : activationCode // ignore: cast_nullable_to_non_nullable
              as String?,
      confirmationCode: freezed == confirmationCode
          ? _value.confirmationCode
          : confirmationCode // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      emailVerifiedAt: freezed == emailVerifiedAt
          ? _value.emailVerifiedAt
          : emailVerifiedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      avatar: freezed == avatar
          ? _value.avatar
          : avatar // ignore: cast_nullable_to_non_nullable
              as String?,
      isBoughtFreePackage: freezed == isBoughtFreePackage
          ? _value.isBoughtFreePackage
          : isBoughtFreePackage // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true)
class _$UserInfoModelImpl extends _UserInfoModel {
  _$UserInfoModelImpl(
      {@JsonKey(name: 'id') required this.id,
      @JsonKey(name: 'first_name') required this.firstname,
      @JsonKey(name: 'last_name') required this.lastname,
      @JsonKey(name: 'phone') required this.phone,
      @JsonKey(name: 'email') required this.email,
      @JsonKey(name: 'birthday') required this.birthday,
      @JsonKey(name: 'gender') required this.gender,
      @JsonKey(name: 'activation_code') required this.activationCode,
      @JsonKey(name: 'confirmation_code') required this.confirmationCode,
      @JsonKey(name: 'status') required this.status,
      @JsonKey(name: 'email_verified_at') required this.emailVerifiedAt,
      @JsonKey(name: 'avatar') required this.avatar,
      @JsonKey(name: 'is_bought_free_package')
      required this.isBoughtFreePackage})
      : super._();

  factory _$UserInfoModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$UserInfoModelImplFromJson(json);

  @override
  @JsonKey(name: 'id')
  int? id;
  @override
  @JsonKey(name: 'first_name')
  String? firstname;
  @override
  @JsonKey(name: 'last_name')
  String? lastname;
  @override
  @JsonKey(name: 'phone')
  String? phone;
  @override
  @JsonKey(name: 'email')
  String? email;
  @override
  @JsonKey(name: 'birthday')
  String? birthday;
  @override
  @JsonKey(name: 'gender')
  String? gender;
  @override
  @JsonKey(name: 'activation_code')
  String? activationCode;
  @override
  @JsonKey(name: 'confirmation_code')
  String? confirmationCode;
  @override
  @JsonKey(name: 'status')
  String? status;
  @override
  @JsonKey(name: 'email_verified_at')
  String? emailVerifiedAt;
  @override
  @JsonKey(name: 'avatar')
  String? avatar;
  @override
  @JsonKey(name: 'is_bought_free_package')
  String? isBoughtFreePackage;

  @override
  String toString() {
    return 'UserInfoModel(id: $id, firstname: $firstname, lastname: $lastname, phone: $phone, email: $email, birthday: $birthday, gender: $gender, activationCode: $activationCode, confirmationCode: $confirmationCode, status: $status, emailVerifiedAt: $emailVerifiedAt, avatar: $avatar, isBoughtFreePackage: $isBoughtFreePackage)';
  }

  /// Create a copy of UserInfoModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$UserInfoModelImplCopyWith<_$UserInfoModelImpl> get copyWith =>
      __$$UserInfoModelImplCopyWithImpl<_$UserInfoModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$UserInfoModelImplToJson(
      this,
    );
  }
}

abstract class _UserInfoModel extends UserInfoModel {
  factory _UserInfoModel(
      {@JsonKey(name: 'id') required int? id,
      @JsonKey(name: 'first_name') required String? firstname,
      @JsonKey(name: 'last_name') required String? lastname,
      @JsonKey(name: 'phone') required String? phone,
      @JsonKey(name: 'email') required String? email,
      @JsonKey(name: 'birthday') required String? birthday,
      @JsonKey(name: 'gender') required String? gender,
      @JsonKey(name: 'activation_code') required String? activationCode,
      @JsonKey(name: 'confirmation_code') required String? confirmationCode,
      @JsonKey(name: 'status') required String? status,
      @JsonKey(name: 'email_verified_at') required String? emailVerifiedAt,
      @JsonKey(name: 'avatar') required String? avatar,
      @JsonKey(name: 'is_bought_free_package')
      required String? isBoughtFreePackage}) = _$UserInfoModelImpl;
  _UserInfoModel._() : super._();

  factory _UserInfoModel.fromJson(Map<String, dynamic> json) =
      _$UserInfoModelImpl.fromJson;

  @override
  @JsonKey(name: 'id')
  int? get id;
  @JsonKey(name: 'id')
  set id(int? value);
  @override
  @JsonKey(name: 'first_name')
  String? get firstname;
  @JsonKey(name: 'first_name')
  set firstname(String? value);
  @override
  @JsonKey(name: 'last_name')
  String? get lastname;
  @JsonKey(name: 'last_name')
  set lastname(String? value);
  @override
  @JsonKey(name: 'phone')
  String? get phone;
  @JsonKey(name: 'phone')
  set phone(String? value);
  @override
  @JsonKey(name: 'email')
  String? get email;
  @JsonKey(name: 'email')
  set email(String? value);
  @override
  @JsonKey(name: 'birthday')
  String? get birthday;
  @JsonKey(name: 'birthday')
  set birthday(String? value);
  @override
  @JsonKey(name: 'gender')
  String? get gender;
  @JsonKey(name: 'gender')
  set gender(String? value);
  @override
  @JsonKey(name: 'activation_code')
  String? get activationCode;
  @JsonKey(name: 'activation_code')
  set activationCode(String? value);
  @override
  @JsonKey(name: 'confirmation_code')
  String? get confirmationCode;
  @JsonKey(name: 'confirmation_code')
  set confirmationCode(String? value);
  @override
  @JsonKey(name: 'status')
  String? get status;
  @JsonKey(name: 'status')
  set status(String? value);
  @override
  @JsonKey(name: 'email_verified_at')
  String? get emailVerifiedAt;
  @JsonKey(name: 'email_verified_at')
  set emailVerifiedAt(String? value);
  @override
  @JsonKey(name: 'avatar')
  String? get avatar;
  @JsonKey(name: 'avatar')
  set avatar(String? value);
  @override
  @JsonKey(name: 'is_bought_free_package')
  String? get isBoughtFreePackage;
  @JsonKey(name: 'is_bought_free_package')
  set isBoughtFreePackage(String? value);

  /// Create a copy of UserInfoModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$UserInfoModelImplCopyWith<_$UserInfoModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
