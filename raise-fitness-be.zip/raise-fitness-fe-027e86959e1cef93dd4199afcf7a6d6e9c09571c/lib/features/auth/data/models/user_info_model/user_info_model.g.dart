// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_info_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$UserInfoModelImpl _$$UserInfoModelImplFromJson(Map<String, dynamic> json) =>
    _$UserInfoModelImpl(
      id: (json['id'] as num?)?.toInt(),
      firstname: json['first_name'] as String?,
      lastname: json['last_name'] as String?,
      phone: json['phone'] as String?,
      email: json['email'] as String?,
      birthday: json['birthday'] as String?,
      gender: json['gender'] as String?,
      activationCode: json['activation_code'] as String?,
      confirmationCode: json['confirmation_code'] as String?,
      status: json['status'] as String?,
      emailVerifiedAt: json['email_verified_at'] as String?,
      avatar: json['avatar'] as String?,
      isBoughtFreePackage: json['is_bought_free_package'] as String?,
    );

Map<String, dynamic> _$$UserInfoModelImplToJson(_$UserInfoModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'first_name': instance.firstname,
      'last_name': instance.lastname,
      'phone': instance.phone,
      'email': instance.email,
      'birthday': instance.birthday,
      'gender': instance.gender,
      'activation_code': instance.activationCode,
      'confirmation_code': instance.confirmationCode,
      'status': instance.status,
      'email_verified_at': instance.emailVerifiedAt,
      'avatar': instance.avatar,
      'is_bought_free_package': instance.isBoughtFreePackage,
    };
