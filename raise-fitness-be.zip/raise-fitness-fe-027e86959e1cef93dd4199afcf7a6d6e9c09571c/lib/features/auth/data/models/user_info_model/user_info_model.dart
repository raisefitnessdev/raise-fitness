import 'package:freezed_annotation/freezed_annotation.dart';

part 'user_info_model.freezed.dart';
part 'user_info_model.g.dart';

@unfreezed
class UserInfoModel with _$UserInfoModel {
  const UserInfoModel._();
  @JsonSerializable(explicitToJson: true)
  factory UserInfoModel({
    @JsonKey(name: 'id') required int? id,
    @JsonKey(name: 'first_name') required String? firstname,
    @JsonKey(name: 'last_name') required String? lastname,    
    @JsonKey(name: 'phone') required String? phone,
    @JsonKey(name: 'email') required String? email,
    @JsonKey(name: 'birthday') required String? birthday,
    @JsonKey(name: 'gender') required String? gender,
    @JsonKey(name: 'activation_code') required String? activationCode,
    @JsonKey(name: 'confirmation_code') required String? confirmationCode,
    @JsonKey(name: 'status') required String? status,
    @JsonKey(name: 'email_verified_at') required String? emailVerifiedAt,
    @JsonKey(name: 'avatar') required String? avatar,
    @JsonKey(name: 'is_bought_free_package') required String? isBoughtFreePackage,
  }) = _UserInfoModel;

  factory UserInfoModel.fromJson(Map<String, dynamic> json) =>
      _$UserInfoModelFromJson(json);
}
