import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/http/models/result.dart';
import 'package:raise/core/models/model_to_domain/model_to_domain.dart';
import 'package:raise/features/auth/data/data_sources/auth_data_source.dart';
import 'package:raise/features/auth/data/models/user_model/user_model.dart';
import 'package:raise/features/auth/domain/entity/login_params.dart';
import 'package:raise/features/auth/domain/entity/register_params.dart';
import 'package:raise/features/auth/domain/entity/reset_password_params.dart';
import 'package:raise/features/auth/domain/repositories/auth_repository.dart';
import 'package:injectable/injectable.dart';

@Injectable(as: AuthRepository)
class AuthRepositoryImpl extends AuthRepository with ModelToDomainResult {
  @override
  Future<MyResult<UserModel>> login(LoginParams param) async {
    return await getIt.get<AuthDataSource>().login(param);
  }

  @override
  Future<MyResult<UserModel>> register(RegisterParams param) async {
    return await getIt.get<AuthDataSource>().register(param);
  }

  @override
  Future<MyResult<UserModel>> activeAccount(String param) async {
    return await getIt.get<AuthDataSource>().activeAccount(param);
  }

  @override
  Future<MyResult<String>> resendActivation(String param) async {
    return await getIt.get<AuthDataSource>().resendActivation(param);
  }

  @override
  Future<MyResult<String>> resendConfirmation(String param) async {
    return await getIt.get<AuthDataSource>().resendConfirmation(param);
  }

  @override
  Future<MyResult<String>> forgetPassword(String param) async {
    return await getIt.get<AuthDataSource>().forgetPassword(param);
  }

  @override
  Future<MyResult<String>> resetPassword(ResetPasswordParams param) async {
    return await getIt.get<AuthDataSource>().resetPassword(param);
  }

  @override
  Future<MyResult<bool>> checkForget(String param) async {
    return await getIt.get<AuthDataSource>().checkForget(param);
  }
}
