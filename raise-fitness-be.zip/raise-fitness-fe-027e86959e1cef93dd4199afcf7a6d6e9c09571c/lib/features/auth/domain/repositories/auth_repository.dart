import 'package:raise/core/http/models/result.dart';
import 'package:raise/features/auth/data/models/user_model/user_model.dart';
import 'package:raise/features/auth/domain/entity/login_params.dart';
import 'package:raise/features/auth/domain/entity/register_params.dart';
import 'package:raise/features/auth/domain/entity/reset_password_params.dart';

abstract class AuthRepository {
  Future<MyResult<UserModel>> login(LoginParams param);
  Future<MyResult<UserModel>> register(RegisterParams param);
  Future<MyResult<UserModel>> activeAccount(String param);
  Future<MyResult<String>> resendActivation(String param);
  Future<MyResult<String>> resendConfirmation(String param);
  Future<MyResult<String>> forgetPassword(String param);
  Future<MyResult<String>> resetPassword(ResetPasswordParams param);
  Future<MyResult<bool>> checkForget(String param);
}
