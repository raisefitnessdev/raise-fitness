class ResetPasswordParams {
  String code;
  String password;
  String confirm;

  ResetPasswordParams({
    required this.password,
    required this.code,
    required this.confirm,
  });


  factory ResetPasswordParams.copyWith({
    required String password,
    required String code,
    required String confirm,
  }) {
    return ResetPasswordParams(
      password: password,
      code: code,
      confirm: confirm,
    );
  }

  Map<String, dynamic> toJson() => {
        'confirmation_code': code,
        'password': password,
        'password_confirmation': confirm,
      };

  factory ResetPasswordParams.fromJson(Map<String, dynamic> json) => ResetPasswordParams(
        code: json['confirmation_code'],
        password: json['password'],
        confirm: json['password_confirmation'],
      );
}
