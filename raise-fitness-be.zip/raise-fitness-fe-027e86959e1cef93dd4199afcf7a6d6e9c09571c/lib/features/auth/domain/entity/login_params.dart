class LoginParams {
  String email;
  String password;

  LoginParams({
    required this.password,
    required this.email,
  });


  factory LoginParams.copyWith({
    required String password,
    required String email,
  }) {
    return LoginParams(
      password: password,
      email: email,
    );
  }

  Map<String, dynamic> toJson() => {
        'email': email,
        'password': password,
      };

  factory LoginParams.fromJson(Map<String, dynamic> json) => LoginParams(
        email: json['email'],
        password: json['password'],
      );
}
