class RegisterParams {
  String firstname;
  String lastname;
  String email;
  String phone;
  String gender;
  String birthday;
  String password;
  String confirmation;

  RegisterParams({
    required this.firstname,
    required this.lastname,
    required this.phone,
    required this.gender,
    required this.birthday,
    required this.confirmation,
    required this.password,
    required this.email,
  });

  factory RegisterParams.copyWith({
    required String password,
    required String firstname,
    required String lastname,
    required String email,
    required String phone,
    required String gender,
    required String birthday,
    required String confirmation,
  }) {
    return RegisterParams(
      password: password,
      email: email,
      firstname: firstname,
      lastname: lastname,
      phone: phone,
      confirmation: confirmation,
      gender: gender,
      birthday: birthday,
    );
  }

  Map<String, dynamic> toJson() => {
        'first_name': firstname,
        'last_name': lastname,
        'email': email,
        'phone': phone,
        'gender': gender,
        'birthday': birthday,
        'password': password,
        'password_confirmation': confirmation,
      };

  factory RegisterParams.fromJson(Map<String, dynamic> json) => RegisterParams(
        firstname: json['first_name'],
        lastname: json['last_name'],
        phone: json['phone'],
        email: json['email'],
        gender: json['gender'],
        birthday: json['birthday'],
        password: json['password'],
        confirmation: json['password_confirmation'],
      );
}
