import 'package:raise/core/http/models/result.dart';
import 'package:raise/features/auth/data/models/user_info_model/user_info_model.dart';
import 'package:raise/features/base/data/models/booking_model/booking_model.dart';
import 'package:raise/features/base/data/models/class_model/class_model.dart';
import 'package:raise/features/base/data/models/general_model/general_model.dart';
import 'package:raise/features/base/data/models/notification_model/notification_model.dart';
import 'package:raise/features/base/data/models/package_model/package_model.dart';
import 'package:raise/features/base/data/models/user_package_model/user_package_model.dart';
import 'package:raise/features/base/domain/entity/buy_class_params.dart';
import 'package:raise/features/base/domain/entity/class_status_params.dart';
import 'package:raise/features/base/domain/entity/contact_us_params.dart';
import 'package:raise/features/base/domain/entity/profile_params.dart';
import 'package:raise/features/base/domain/entity/purchase_package_params.dart';
import 'package:raise/features/base/domain/entity/update_password_params.dart';

abstract class BaseRepository {
  Future<MyResult<List<ClassModel>>> getClasses(String param);
  Future<MyResult<List<PackageModel>>> getPackages(bool param);
  Future<MyResult<List<UserPackageModel>>> myPackages(bool param);
  Future<MyResult<UserInfoModel>> getProfile(bool param);
  Future<MyResult<UserInfoModel>> editProfile(ProfileParams param);
  Future<MyResult<String>> updatePassword(UpdatePasswordParams param);
  Future<MyResult<UserPackageModel>> purchasePackage(PurchasePackageParams param);
  Future<MyResult<String>> activatePackage(int param);
  Future<MyResult<String>> buyClass(BuyClassParams param);
  Future<MyResult<List<BookingModel>>> myClasses(bool param);
  Future<MyResult<bool>> contactUs(ContactUsParams param);
  Future<MyResult<List<GeneralModel>>> getSettings(bool param);
  Future<MyResult<List<GeneralModel>>> getFAQ(bool param);
  Future<MyResult<List<NotificationModel>>> getNotifications(bool param);
  Future<MyResult<int>> getNotificationCount(bool param);
  Future<MyResult<bool>> removeAccount(bool param);
  Future<MyResult<bool>> changeStatus(ClassStatusParams param);
}
