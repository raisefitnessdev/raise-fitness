import 'dart:io';

class ProfileParams {
  String firstname;
  String lastname;
  String email;
  String phone;
  String gender;
  String birthday;
  File? avatar;

  ProfileParams({
    required this.firstname,
    required this.lastname,
    required this.phone,
    required this.gender,
    required this.birthday,
    required this.avatar,
    required this.email,
  });

  factory ProfileParams.copyWith({
    required String firstname,
    required String lastname,
    required String email,
    required String phone,
    required String gender,
    required String birthday,
    required File? avatar,
  }) {
    return ProfileParams(
      email: email,
      firstname: firstname,
      lastname: lastname,
      phone: phone,
      avatar: avatar,
      gender: gender,
      birthday: birthday,
    );
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> json = {
      'first_name': firstname,
      'last_name': lastname,
      'email': email,
      'phone': phone,
      'gender': gender,
      'birthday': birthday,
    };
    if (avatar != null) {
      json.addAll({"avatar": avatar});
    }
    return json;
  }

  factory ProfileParams.fromJson(Map<String, dynamic> json) => ProfileParams(
        firstname: json['first_name'],
        lastname: json['last_name'],
        phone: json['phone'],
        email: json['email'],
        gender: json['gender'],
        birthday: json['birthday'],
        avatar: json['avatar'],
      );
}
