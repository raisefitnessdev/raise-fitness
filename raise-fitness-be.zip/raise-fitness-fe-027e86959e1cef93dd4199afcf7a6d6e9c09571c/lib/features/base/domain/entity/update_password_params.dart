class UpdatePasswordParams {
  String password;
  String newPassword;
  String confirm;

  UpdatePasswordParams({
    required this.password,
    required this.newPassword,
    required this.confirm,
  });

  factory UpdatePasswordParams.copyWith({
    required String password,
    required String newPassword,
    required String confirm,
  }) {
    return UpdatePasswordParams(
      password: password,
      newPassword: newPassword,
      confirm: confirm,
    );
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> json = {
      'current_password': password,
      'new_password': newPassword,
      'new_password_confirmation': confirm,
    };
    return json;
  }

  factory UpdatePasswordParams.fromJson(Map<String, dynamic> json) => UpdatePasswordParams(
        password: json['current_password'],
        newPassword: json['new_password'],
        confirm: json['new_password_confirmation'],
      );
}
