class ContactUsParams {
  String name;
  String email;
  String phone;
  String message;

  ContactUsParams({
    required this.name,
    required this.phone,
    required this.message,
    required this.email,
  });

  factory ContactUsParams.copyWith({
    required String name,
    required String email,
    required String phone,
    required String message,
  }) {
    return ContactUsParams(
      email: email,
      name: name,
      phone: phone,
      message: message,
    );
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> json = {
      'name': name,
      'email': email,
      'phone': phone,
      'message': message,
    };
    return json;
  }

  factory ContactUsParams.fromJson(Map<String, dynamic> json) => ContactUsParams(
        name: json['name'],
        phone: json['phone'],
        email: json['email'],
        message: json['message'],
      );
}
