class BuyClassParams {
  int classId;
  int packageId;

  BuyClassParams({
    required this.classId,
    required this.packageId,
  });

  factory BuyClassParams.copyWith({
    required int classId,
    required int packageId,
  }) {
    return BuyClassParams(
      classId: classId,
      packageId: packageId,
    );
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> json = {
      'class_id': classId,
      'user_package_id': packageId,
    };
    return json;
  }

  factory BuyClassParams.fromJson(Map<String, dynamic> json) => BuyClassParams(
        classId: json['class_id'],
        packageId: json['user_package_id'],
      );
}
