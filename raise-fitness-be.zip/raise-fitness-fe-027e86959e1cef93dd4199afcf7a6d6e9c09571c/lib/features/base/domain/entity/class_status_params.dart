class ClassStatusParams {
  int id;
  String status;

  ClassStatusParams({
    required this.id,
    required this.status,
  });

  factory ClassStatusParams.copyWith({
    required int id,
    required String status,
  }) {
    return ClassStatusParams(
      status: status,
      id: id,
    );
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> json = {
      'user_session_id': id,
      'status': status,
    };
    return json;
  }

  factory ClassStatusParams.fromJson(Map<String, dynamic> json) => ClassStatusParams(
        id: json['user_session_id'],
        status: json['status'],
      );
}
