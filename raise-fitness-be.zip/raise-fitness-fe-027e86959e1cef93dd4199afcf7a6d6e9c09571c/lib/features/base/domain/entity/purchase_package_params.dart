class PurchasePackageParams {
  int userId;
  int packageId;

  PurchasePackageParams({
    required this.userId,
    required this.packageId,
  });

  factory PurchasePackageParams.copyWith({
    required int userId,
    required int packageId,
  }) {
    return PurchasePackageParams(
      userId: userId,
      packageId: packageId,
    );
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> json = {
      'user_id': userId,
      'package_id': packageId,
    };
    return json;
  }

  factory PurchasePackageParams.fromJson(Map<String, dynamic> json) => PurchasePackageParams(
        userId: json['user_id'],
        packageId: json['package_id'],
      );
}
