import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/requester/requester.dart';
import 'package:raise/features/base/data/models/package_model/package_model.dart';
import 'package:raise/features/base/domain/repositories/base_repository.dart';

class PackagesRequester extends Requester<List<PackageModel>> {
  PackagesRequester() {
    request(fromRemote: true);
    request();
  }

  @override
  Future<void> request({bool fromRemote = true}) async {
    if (hasNoData) {
      loadingState();
    }
    var result = await getIt.get<BaseRepository>().getPackages(fromRemote);
    result.when(
      isSuccess: (data) {
        successState(data ?? []);
      },
      isError: (error) {
        failedState(error, () => request(fromRemote: fromRemote));
      },
    );
  }
}
