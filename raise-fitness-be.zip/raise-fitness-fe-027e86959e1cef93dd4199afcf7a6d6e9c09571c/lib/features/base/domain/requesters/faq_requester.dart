import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/requester/requester.dart';
import 'package:raise/features/base/data/models/general_model/general_model.dart';
import 'package:raise/features/base/domain/repositories/base_repository.dart';

class FAQRequester extends Requester<List<GeneralModel>> {
  FAQRequester() {
    request(fromRemote: true);
    request();
  }

  @override
  Future<void> request({bool fromRemote = true}) async {
    if (hasNoData) {
      loadingState();
    }
    var result = await getIt.get<BaseRepository>().getFAQ(fromRemote);
    result.when(
      isSuccess: (data) {
        successState(data ?? []);
      },
      isError: (error) {
        failedState(error, () => request(fromRemote: fromRemote));
      },
    );
  }
}
