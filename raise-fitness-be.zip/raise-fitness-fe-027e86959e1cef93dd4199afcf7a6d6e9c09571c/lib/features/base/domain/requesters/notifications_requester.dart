import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/requester/requester.dart';
import 'package:raise/features/base/data/models/notification_model/notification_model.dart';
import 'package:raise/features/base/domain/repositories/base_repository.dart';

class NotificationsRequester extends Requester<List<NotificationModel>> {
  NotificationsRequester() {
    request(fromRemote: true);
    request();
  }

  @override
  Future<void> request({bool fromRemote = true}) async {
    if (hasNoData) {
      loadingState();
    }
    var result = await getIt.get<BaseRepository>().getNotifications(fromRemote);
    result.when(
      isSuccess: (data) {
        successState(data??[]);
      },
      isError: (error) {
        failedState(error, () => request(fromRemote: fromRemote));
      },
    );
  }
}
