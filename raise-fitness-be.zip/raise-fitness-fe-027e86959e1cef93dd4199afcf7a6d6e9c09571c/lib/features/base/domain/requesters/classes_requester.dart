import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/requester/requester.dart';
import 'package:raise/features/base/data/models/class_model/class_model.dart';
import 'package:raise/features/base/domain/repositories/base_repository.dart';

class ClassesRequester extends Requester<List<ClassModel>> {
  late String date;
  ClassesRequester({required this.date});
  @override
  Future<void> request({bool fromRemote = true}) async {
    if (hasNoData) {
      loadingState();
    }
    var result = await getIt.get<BaseRepository>().getClasses(date);
    result.when(
      isSuccess: (data) {
        successState(data!);
      },
      isError: (error) {
        failedState(error, () => request(fromRemote: fromRemote));
      },
    );
  }

  void onChangeLocation(String param) {
    date = param;
    request();
  }
}
