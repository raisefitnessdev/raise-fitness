import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/requester/requester.dart';
import 'package:raise/features/base/domain/repositories/base_repository.dart';

class NotificationsCountRequester extends Requester<int> {
  NotificationsCountRequester() {
    request(fromRemote: true);
    request();
  }

  @override
  Future<void> request({bool fromRemote = true}) async {
    if (hasNoData) {
      loadingState();
    }
    var result = await getIt.get<BaseRepository>().getNotificationCount(fromRemote);
    result.when(
      isSuccess: (data) {
        successState(data??0);
      },
      isError: (error) {
        failedState(error, () => request(fromRemote: fromRemote));
      },
    );
  }
}
