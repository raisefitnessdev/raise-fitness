import 'package:freezed_annotation/freezed_annotation.dart';

part 'general_model.freezed.dart';
part 'general_model.g.dart';

@unfreezed
@immutable
class GeneralModel with _$GeneralModel {
  const GeneralModel._();

  @JsonSerializable(explicitToJson: true)
  factory GeneralModel({
    @JsonKey(name: "id") required int? id,
    @JsonKey(name: "key") required String? key,
    @JsonKey(name: "title") required String? title,
    @JsonKey(name: "value") required String? value,
    @JsonKey(name: "details") required String? details,
  }) = _GeneralModel;

  factory GeneralModel.fromJson(Map<String, dynamic> json) =>
      _$GeneralModelFromJson(json);
}
