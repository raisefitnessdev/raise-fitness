// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'general_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GeneralModelImpl _$$GeneralModelImplFromJson(Map<String, dynamic> json) =>
    _$GeneralModelImpl(
      id: (json['id'] as num?)?.toInt(),
      key: json['key'] as String?,
      title: json['title'] as String?,
      value: json['value'] as String?,
      details: json['details'] as String?,
    );

Map<String, dynamic> _$$GeneralModelImplToJson(_$GeneralModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'key': instance.key,
      'title': instance.title,
      'value': instance.value,
      'details': instance.details,
    };
