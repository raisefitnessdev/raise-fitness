// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'general_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GeneralModel _$GeneralModelFromJson(Map<String, dynamic> json) {
  return _GeneralModel.fromJson(json);
}

/// @nodoc
mixin _$GeneralModel {
  @JsonKey(name: "id")
  int? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "id")
  set id(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "key")
  String? get key => throw _privateConstructorUsedError;
  @JsonKey(name: "key")
  set key(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "title")
  String? get title => throw _privateConstructorUsedError;
  @JsonKey(name: "title")
  set title(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "value")
  String? get value => throw _privateConstructorUsedError;
  @JsonKey(name: "value")
  set value(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "details")
  String? get details => throw _privateConstructorUsedError;
  @JsonKey(name: "details")
  set details(String? value) => throw _privateConstructorUsedError;

  /// Serializes this GeneralModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of GeneralModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $GeneralModelCopyWith<GeneralModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GeneralModelCopyWith<$Res> {
  factory $GeneralModelCopyWith(
          GeneralModel value, $Res Function(GeneralModel) then) =
      _$GeneralModelCopyWithImpl<$Res, GeneralModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "key") String? key,
      @JsonKey(name: "title") String? title,
      @JsonKey(name: "value") String? value,
      @JsonKey(name: "details") String? details});
}

/// @nodoc
class _$GeneralModelCopyWithImpl<$Res, $Val extends GeneralModel>
    implements $GeneralModelCopyWith<$Res> {
  _$GeneralModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of GeneralModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? key = freezed,
    Object? title = freezed,
    Object? value = freezed,
    Object? details = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      key: freezed == key
          ? _value.key
          : key // ignore: cast_nullable_to_non_nullable
              as String?,
      title: freezed == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String?,
      value: freezed == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as String?,
      details: freezed == details
          ? _value.details
          : details // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GeneralModelImplCopyWith<$Res>
    implements $GeneralModelCopyWith<$Res> {
  factory _$$GeneralModelImplCopyWith(
          _$GeneralModelImpl value, $Res Function(_$GeneralModelImpl) then) =
      __$$GeneralModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "key") String? key,
      @JsonKey(name: "title") String? title,
      @JsonKey(name: "value") String? value,
      @JsonKey(name: "details") String? details});
}

/// @nodoc
class __$$GeneralModelImplCopyWithImpl<$Res>
    extends _$GeneralModelCopyWithImpl<$Res, _$GeneralModelImpl>
    implements _$$GeneralModelImplCopyWith<$Res> {
  __$$GeneralModelImplCopyWithImpl(
      _$GeneralModelImpl _value, $Res Function(_$GeneralModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of GeneralModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? key = freezed,
    Object? title = freezed,
    Object? value = freezed,
    Object? details = freezed,
  }) {
    return _then(_$GeneralModelImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      key: freezed == key
          ? _value.key
          : key // ignore: cast_nullable_to_non_nullable
              as String?,
      title: freezed == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String?,
      value: freezed == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as String?,
      details: freezed == details
          ? _value.details
          : details // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true)
class _$GeneralModelImpl extends _GeneralModel {
  _$GeneralModelImpl(
      {@JsonKey(name: "id") required this.id,
      @JsonKey(name: "key") required this.key,
      @JsonKey(name: "title") required this.title,
      @JsonKey(name: "value") required this.value,
      @JsonKey(name: "details") required this.details})
      : super._();

  factory _$GeneralModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GeneralModelImplFromJson(json);

  @override
  @JsonKey(name: "id")
  int? id;
  @override
  @JsonKey(name: "key")
  String? key;
  @override
  @JsonKey(name: "title")
  String? title;
  @override
  @JsonKey(name: "value")
  String? value;
  @override
  @JsonKey(name: "details")
  String? details;

  @override
  String toString() {
    return 'GeneralModel(id: $id, key: $key, title: $title, value: $value, details: $details)';
  }

  /// Create a copy of GeneralModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$GeneralModelImplCopyWith<_$GeneralModelImpl> get copyWith =>
      __$$GeneralModelImplCopyWithImpl<_$GeneralModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GeneralModelImplToJson(
      this,
    );
  }
}

abstract class _GeneralModel extends GeneralModel {
  factory _GeneralModel(
      {@JsonKey(name: "id") required int? id,
      @JsonKey(name: "key") required String? key,
      @JsonKey(name: "title") required String? title,
      @JsonKey(name: "value") required String? value,
      @JsonKey(name: "details") required String? details}) = _$GeneralModelImpl;
  _GeneralModel._() : super._();

  factory _GeneralModel.fromJson(Map<String, dynamic> json) =
      _$GeneralModelImpl.fromJson;

  @override
  @JsonKey(name: "id")
  int? get id;
  @JsonKey(name: "id")
  set id(int? value);
  @override
  @JsonKey(name: "key")
  String? get key;
  @JsonKey(name: "key")
  set key(String? value);
  @override
  @JsonKey(name: "title")
  String? get title;
  @JsonKey(name: "title")
  set title(String? value);
  @override
  @JsonKey(name: "value")
  String? get value;
  @JsonKey(name: "value")
  set value(String? value);
  @override
  @JsonKey(name: "details")
  String? get details;
  @JsonKey(name: "details")
  set details(String? value);

  /// Create a copy of GeneralModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$GeneralModelImplCopyWith<_$GeneralModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
