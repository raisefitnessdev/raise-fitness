import 'package:freezed_annotation/freezed_annotation.dart';

part 'notification_model.freezed.dart';
part 'notification_model.g.dart';

@unfreezed
@immutable
class NotificationModel with _$NotificationModel {
  const NotificationModel._();

  @JsonSerializable(explicitToJson: true)
  factory NotificationModel({
    @JsonKey(name: "id") required String? id,
    @JsonKey(name: "title") required String? title,
    @JsonKey(name: "details") required String? details,
    @JsonKey(name: "read_at") required String? readAt,
  }) = _NotificationModel;

  factory NotificationModel.fromJson(Map<String, dynamic> json) =>
      _$NotificationModelFromJson(json);
}
