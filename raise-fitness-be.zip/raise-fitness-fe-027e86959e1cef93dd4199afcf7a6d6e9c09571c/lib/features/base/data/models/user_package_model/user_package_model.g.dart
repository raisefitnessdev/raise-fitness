// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_package_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$UserPackageModelImpl _$$UserPackageModelImplFromJson(
        Map<String, dynamic> json) =>
    _$UserPackageModelImpl(
      id: (json['id'] as num?)?.toInt(),
      expireDate: json['expire_date'] as String?,
      price: json['price'] as String?,
      numberOfSessions: (json['number_of_sessions'] as num?)?.toInt(),
      isFree: (json['is_free'] as num?)?.toInt(),
      validityDays: (json['validity_days'] as num?)?.toInt(),
      sessionUsed: (json['sessionUsed'] as num?)?.toInt(),
      status: json['status'] as String?,
      package: json['package'] == null
          ? null
          : PackageModel.fromJson(json['package'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$UserPackageModelImplToJson(
        _$UserPackageModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'expire_date': instance.expireDate,
      'price': instance.price,
      'number_of_sessions': instance.numberOfSessions,
      'is_free': instance.isFree,
      'validity_days': instance.validityDays,
      'sessionUsed': instance.sessionUsed,
      'status': instance.status,
      'package': instance.package?.toJson(),
    };
