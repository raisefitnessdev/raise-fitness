import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:raise/features/base/data/models/package_model/package_model.dart';

part 'user_package_model.freezed.dart';
part 'user_package_model.g.dart';

@unfreezed
@immutable
class UserPackageModel with _$UserPackageModel {
  const UserPackageModel._();

  @JsonSerializable(explicitToJson: true)
  factory UserPackageModel({
    @JsonKey(name: "id") required int? id,
    @JsonKey(name: "expire_date") required String? expireDate,
    @JsonKey(name: "price") required String? price,
    @JsonKey(name: "number_of_sessions") required int? numberOfSessions,
    @JsonKey(name: "is_free") required int? isFree,
    @JsonKey(name: "validity_days") required int? validityDays,
    @JsonKey(name: "session_used") required int? sessionUsed,
    @JsonKey(name: "status") required String? status,
    @JsonKey(name: "package") required PackageModel? package,
  }) = _UserPackageModel;

  factory UserPackageModel.fromJson(Map<String, dynamic> json) =>
      _$UserPackageModelFromJson(json);
}