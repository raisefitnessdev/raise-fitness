// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_package_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

UserPackageModel _$UserPackageModelFromJson(Map<String, dynamic> json) {
  return _UserPackageModel.fromJson(json);
}

/// @nodoc
mixin _$UserPackageModel {
  @JsonKey(name: "id")
  int? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "id")
  set id(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "expire_date")
  String? get expireDate => throw _privateConstructorUsedError;
  @JsonKey(name: "expire_date")
  set expireDate(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "price")
  String? get price => throw _privateConstructorUsedError;
  @JsonKey(name: "price")
  set price(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "number_of_sessions")
  int? get numberOfSessions => throw _privateConstructorUsedError;
  @JsonKey(name: "number_of_sessions")
  set numberOfSessions(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "is_free")
  int? get isFree => throw _privateConstructorUsedError;
  @JsonKey(name: "is_free")
  set isFree(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "validity_days")
  int? get validityDays => throw _privateConstructorUsedError;
  @JsonKey(name: "validity_days")
  set validityDays(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "sessionUsed")
  int? get sessionUsed => throw _privateConstructorUsedError;
  @JsonKey(name: "sessionUsed")
  set sessionUsed(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  String? get status => throw _privateConstructorUsedError;
  @JsonKey(name: "status")
  set status(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "package")
  PackageModel? get package => throw _privateConstructorUsedError;
  @JsonKey(name: "package")
  set package(PackageModel? value) => throw _privateConstructorUsedError;

  /// Serializes this UserPackageModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of UserPackageModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $UserPackageModelCopyWith<UserPackageModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserPackageModelCopyWith<$Res> {
  factory $UserPackageModelCopyWith(
          UserPackageModel value, $Res Function(UserPackageModel) then) =
      _$UserPackageModelCopyWithImpl<$Res, UserPackageModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "expire_date") String? expireDate,
      @JsonKey(name: "price") String? price,
      @JsonKey(name: "number_of_sessions") int? numberOfSessions,
      @JsonKey(name: "is_free") int? isFree,
      @JsonKey(name: "validity_days") int? validityDays,
      @JsonKey(name: "sessionUsed") int? sessionUsed,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "package") PackageModel? package});

  $PackageModelCopyWith<$Res>? get package;
}

/// @nodoc
class _$UserPackageModelCopyWithImpl<$Res, $Val extends UserPackageModel>
    implements $UserPackageModelCopyWith<$Res> {
  _$UserPackageModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of UserPackageModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? expireDate = freezed,
    Object? price = freezed,
    Object? numberOfSessions = freezed,
    Object? isFree = freezed,
    Object? validityDays = freezed,
    Object? sessionUsed = freezed,
    Object? status = freezed,
    Object? package = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      expireDate: freezed == expireDate
          ? _value.expireDate
          : expireDate // ignore: cast_nullable_to_non_nullable
              as String?,
      price: freezed == price
          ? _value.price
          : price // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfSessions: freezed == numberOfSessions
          ? _value.numberOfSessions
          : numberOfSessions // ignore: cast_nullable_to_non_nullable
              as int?,
      isFree: freezed == isFree
          ? _value.isFree
          : isFree // ignore: cast_nullable_to_non_nullable
              as int?,
      validityDays: freezed == validityDays
          ? _value.validityDays
          : validityDays // ignore: cast_nullable_to_non_nullable
              as int?,
      sessionUsed: freezed == sessionUsed
          ? _value.sessionUsed
          : sessionUsed // ignore: cast_nullable_to_non_nullable
              as int?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      package: freezed == package
          ? _value.package
          : package // ignore: cast_nullable_to_non_nullable
              as PackageModel?,
    ) as $Val);
  }

  /// Create a copy of UserPackageModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @pragma('vm:prefer-inline')
  $PackageModelCopyWith<$Res>? get package {
    if (_value.package == null) {
      return null;
    }

    return $PackageModelCopyWith<$Res>(_value.package!, (value) {
      return _then(_value.copyWith(package: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$UserPackageModelImplCopyWith<$Res>
    implements $UserPackageModelCopyWith<$Res> {
  factory _$$UserPackageModelImplCopyWith(_$UserPackageModelImpl value,
          $Res Function(_$UserPackageModelImpl) then) =
      __$$UserPackageModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "expire_date") String? expireDate,
      @JsonKey(name: "price") String? price,
      @JsonKey(name: "number_of_sessions") int? numberOfSessions,
      @JsonKey(name: "is_free") int? isFree,
      @JsonKey(name: "validity_days") int? validityDays,
      @JsonKey(name: "sessionUsed") int? sessionUsed,
      @JsonKey(name: "status") String? status,
      @JsonKey(name: "package") PackageModel? package});

  @override
  $PackageModelCopyWith<$Res>? get package;
}

/// @nodoc
class __$$UserPackageModelImplCopyWithImpl<$Res>
    extends _$UserPackageModelCopyWithImpl<$Res, _$UserPackageModelImpl>
    implements _$$UserPackageModelImplCopyWith<$Res> {
  __$$UserPackageModelImplCopyWithImpl(_$UserPackageModelImpl _value,
      $Res Function(_$UserPackageModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of UserPackageModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? expireDate = freezed,
    Object? price = freezed,
    Object? numberOfSessions = freezed,
    Object? isFree = freezed,
    Object? validityDays = freezed,
    Object? sessionUsed = freezed,
    Object? status = freezed,
    Object? package = freezed,
  }) {
    return _then(_$UserPackageModelImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      expireDate: freezed == expireDate
          ? _value.expireDate
          : expireDate // ignore: cast_nullable_to_non_nullable
              as String?,
      price: freezed == price
          ? _value.price
          : price // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfSessions: freezed == numberOfSessions
          ? _value.numberOfSessions
          : numberOfSessions // ignore: cast_nullable_to_non_nullable
              as int?,
      isFree: freezed == isFree
          ? _value.isFree
          : isFree // ignore: cast_nullable_to_non_nullable
              as int?,
      validityDays: freezed == validityDays
          ? _value.validityDays
          : validityDays // ignore: cast_nullable_to_non_nullable
              as int?,
      sessionUsed: freezed == sessionUsed
          ? _value.sessionUsed
          : sessionUsed // ignore: cast_nullable_to_non_nullable
              as int?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      package: freezed == package
          ? _value.package
          : package // ignore: cast_nullable_to_non_nullable
              as PackageModel?,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true)
class _$UserPackageModelImpl extends _UserPackageModel {
  _$UserPackageModelImpl(
      {@JsonKey(name: "id") required this.id,
      @JsonKey(name: "expire_date") required this.expireDate,
      @JsonKey(name: "price") required this.price,
      @JsonKey(name: "number_of_sessions") required this.numberOfSessions,
      @JsonKey(name: "is_free") required this.isFree,
      @JsonKey(name: "validity_days") required this.validityDays,
      @JsonKey(name: "sessionUsed") required this.sessionUsed,
      @JsonKey(name: "status") required this.status,
      @JsonKey(name: "package") required this.package})
      : super._();

  factory _$UserPackageModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$UserPackageModelImplFromJson(json);

  @override
  @JsonKey(name: "id")
  int? id;
  @override
  @JsonKey(name: "expire_date")
  String? expireDate;
  @override
  @JsonKey(name: "price")
  String? price;
  @override
  @JsonKey(name: "number_of_sessions")
  int? numberOfSessions;
  @override
  @JsonKey(name: "is_free")
  int? isFree;
  @override
  @JsonKey(name: "validity_days")
  int? validityDays;
  @override
  @JsonKey(name: "sessionUsed")
  int? sessionUsed;
  @override
  @JsonKey(name: "status")
  String? status;
  @override
  @JsonKey(name: "package")
  PackageModel? package;

  @override
  String toString() {
    return 'UserPackageModel(id: $id, expireDate: $expireDate, price: $price, numberOfSessions: $numberOfSessions, isFree: $isFree, validityDays: $validityDays, sessionUsed: $sessionUsed, status: $status, package: $package)';
  }

  /// Create a copy of UserPackageModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$UserPackageModelImplCopyWith<_$UserPackageModelImpl> get copyWith =>
      __$$UserPackageModelImplCopyWithImpl<_$UserPackageModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$UserPackageModelImplToJson(
      this,
    );
  }
}

abstract class _UserPackageModel extends UserPackageModel {
  factory _UserPackageModel(
          {@JsonKey(name: "id") required int? id,
          @JsonKey(name: "expire_date") required String? expireDate,
          @JsonKey(name: "price") required String? price,
          @JsonKey(name: "number_of_sessions") required int? numberOfSessions,
          @JsonKey(name: "is_free") required int? isFree,
          @JsonKey(name: "validity_days") required int? validityDays,
          @JsonKey(name: "sessionUsed") required int? sessionUsed,
          @JsonKey(name: "status") required String? status,
          @JsonKey(name: "package") required PackageModel? package}) =
      _$UserPackageModelImpl;
  _UserPackageModel._() : super._();

  factory _UserPackageModel.fromJson(Map<String, dynamic> json) =
      _$UserPackageModelImpl.fromJson;

  @override
  @JsonKey(name: "id")
  int? get id;
  @JsonKey(name: "id")
  set id(int? value);
  @override
  @JsonKey(name: "expire_date")
  String? get expireDate;
  @JsonKey(name: "expire_date")
  set expireDate(String? value);
  @override
  @JsonKey(name: "price")
  String? get price;
  @JsonKey(name: "price")
  set price(String? value);
  @override
  @JsonKey(name: "number_of_sessions")
  int? get numberOfSessions;
  @JsonKey(name: "number_of_sessions")
  set numberOfSessions(int? value);
  @override
  @JsonKey(name: "is_free")
  int? get isFree;
  @JsonKey(name: "is_free")
  set isFree(int? value);
  @override
  @JsonKey(name: "validity_days")
  int? get validityDays;
  @JsonKey(name: "validity_days")
  set validityDays(int? value);
  @override
  @JsonKey(name: "sessionUsed")
  int? get sessionUsed;
  @JsonKey(name: "sessionUsed")
  set sessionUsed(int? value);
  @override
  @JsonKey(name: "status")
  String? get status;
  @JsonKey(name: "status")
  set status(String? value);
  @override
  @JsonKey(name: "package")
  PackageModel? get package;
  @JsonKey(name: "package")
  set package(PackageModel? value);

  /// Create a copy of UserPackageModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$UserPackageModelImplCopyWith<_$UserPackageModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
