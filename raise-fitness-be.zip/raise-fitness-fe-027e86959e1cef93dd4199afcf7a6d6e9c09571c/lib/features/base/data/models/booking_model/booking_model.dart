import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:raise/features/base/data/models/class_model/class_model.dart';
import 'package:raise/features/base/data/models/package_model/package_model.dart';

part 'booking_model.freezed.dart';
part 'booking_model.g.dart';

@unfreezed
@immutable
class BookingModel with _$BookingModel {
  const BookingModel._();

  @JsonSerializable(explicitToJson: true)
  factory BookingModel({
    @JsonKey(name: "id") required int? id,
    @JsonKey(name: "status") required String? status,
    @JsonKey(name: "session") required ClassModel? session,
    @JsonKey(name: "package") required PackageModel? package,
    @JsonKey(name: "created_at") required String? createdAt,
    @JsonKey(name: "updated_at") required String? updatedAt,
  }) = _BookingModel;

  factory BookingModel.fromJson(Map<String, dynamic> json) =>
      _$BookingModelFromJson(json);
}
