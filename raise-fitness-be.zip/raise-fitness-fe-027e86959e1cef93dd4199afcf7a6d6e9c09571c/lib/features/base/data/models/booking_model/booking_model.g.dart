// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'booking_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$BookingModelImpl _$$BookingModelImplFromJson(Map<String, dynamic> json) =>
    _$BookingModelImpl(
      id: (json['id'] as num?)?.toInt(),
      status: json['status'] as String?,
      session: json['session'] == null
          ? null
          : ClassModel.fromJson(json['session'] as Map<String, dynamic>),
      package: json['package'] == null
          ? null
          : PackageModel.fromJson(json['package'] as Map<String, dynamic>),
      createdAt: json['created_at'] as String?,
      updatedAt: json['updated_at'] as String?,
    );

Map<String, dynamic> _$$BookingModelImplToJson(_$BookingModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'status': instance.status,
      'session': instance.session?.toJson(),
      'package': instance.package?.toJson(),
      'created_at': instance.createdAt,
      'updated_at': instance.updatedAt,
    };
