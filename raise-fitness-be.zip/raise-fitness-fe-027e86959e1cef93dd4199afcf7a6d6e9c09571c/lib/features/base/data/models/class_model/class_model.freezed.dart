// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'class_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ClassModel _$ClassModelFromJson(Map<String, dynamic> json) {
  return _ClassModel.fromJson(json);
}

/// @nodoc
mixin _$ClassModel {
  @JsonKey(name: "id")
  int? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "id")
  set id(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "category_id")
  int? get categoryId => throw _privateConstructorUsedError;
  @JsonKey(name: "category_id")
  set categoryId(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "coach_id")
  int? get coachId => throw _privateConstructorUsedError;
  @JsonKey(name: "coach_id")
  set coachId(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "category")
  CategoryModel? get category => throw _privateConstructorUsedError;
  @JsonKey(name: "category")
  set category(CategoryModel? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "coach")
  CoachModel? get coach => throw _privateConstructorUsedError;
  @JsonKey(name: "coach")
  set coach(CoachModel? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "selected_date")
  String? get selectedDate => throw _privateConstructorUsedError;
  @JsonKey(name: "selected_date")
  set selectedDate(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "selected_time")
  String? get selectedTime => throw _privateConstructorUsedError;
  @JsonKey(name: "selected_time")
  set selectedTime(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "number_of_minutes")
  int? get numberOfMinutes => throw _privateConstructorUsedError;
  @JsonKey(name: "number_of_minutes")
  set numberOfMinutes(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "fully_booked")
  bool? get fullyBooked => throw _privateConstructorUsedError;
  @JsonKey(name: "fully_booked")
  set fullyBooked(bool? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "number_of_users")
  int? get numberOfUsers => throw _privateConstructorUsedError;
  @JsonKey(name: "number_of_users")
  set numberOfUsers(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "counted_users")
  int? get countedUsers => throw _privateConstructorUsedError;
  @JsonKey(name: "counted_users")
  set countedUsers(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "ladies_only")
  int? get ladiesOnly => throw _privateConstructorUsedError;
  @JsonKey(name: "ladies_only")
  set ladiesOnly(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "description")
  String? get description => throw _privateConstructorUsedError;
  @JsonKey(name: "description")
  set description(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "note")
  String? get note => throw _privateConstructorUsedError;
  @JsonKey(name: "note")
  set note(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "is_bought")
  bool? get isBought => throw _privateConstructorUsedError;
  @JsonKey(name: "is_bought")
  set isBought(bool? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "created_at")
  String? get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: "created_at")
  set createdAt(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "updated_at")
  String? get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: "updated_at")
  set updatedAt(String? value) => throw _privateConstructorUsedError;

  /// Serializes this ClassModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ClassModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ClassModelCopyWith<ClassModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ClassModelCopyWith<$Res> {
  factory $ClassModelCopyWith(
          ClassModel value, $Res Function(ClassModel) then) =
      _$ClassModelCopyWithImpl<$Res, ClassModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "category_id") int? categoryId,
      @JsonKey(name: "coach_id") int? coachId,
      @JsonKey(name: "category") CategoryModel? category,
      @JsonKey(name: "coach") CoachModel? coach,
      @JsonKey(name: "selected_date") String? selectedDate,
      @JsonKey(name: "selected_time") String? selectedTime,
      @JsonKey(name: "number_of_minutes") int? numberOfMinutes,
      @JsonKey(name: "fully_booked") bool? fullyBooked,
      @JsonKey(name: "number_of_users") int? numberOfUsers,
      @JsonKey(name: "counted_users") int? countedUsers,
      @JsonKey(name: "ladies_only") int? ladiesOnly,
      @JsonKey(name: "description") String? description,
      @JsonKey(name: "note") String? note,
      @JsonKey(name: "is_bought") bool? isBought,
      @JsonKey(name: "created_at") String? createdAt,
      @JsonKey(name: "updated_at") String? updatedAt});

  $CategoryModelCopyWith<$Res>? get category;
  $CoachModelCopyWith<$Res>? get coach;
}

/// @nodoc
class _$ClassModelCopyWithImpl<$Res, $Val extends ClassModel>
    implements $ClassModelCopyWith<$Res> {
  _$ClassModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ClassModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? categoryId = freezed,
    Object? coachId = freezed,
    Object? category = freezed,
    Object? coach = freezed,
    Object? selectedDate = freezed,
    Object? selectedTime = freezed,
    Object? numberOfMinutes = freezed,
    Object? fullyBooked = freezed,
    Object? numberOfUsers = freezed,
    Object? countedUsers = freezed,
    Object? ladiesOnly = freezed,
    Object? description = freezed,
    Object? note = freezed,
    Object? isBought = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryId: freezed == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as int?,
      coachId: freezed == coachId
          ? _value.coachId
          : coachId // ignore: cast_nullable_to_non_nullable
              as int?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as CategoryModel?,
      coach: freezed == coach
          ? _value.coach
          : coach // ignore: cast_nullable_to_non_nullable
              as CoachModel?,
      selectedDate: freezed == selectedDate
          ? _value.selectedDate
          : selectedDate // ignore: cast_nullable_to_non_nullable
              as String?,
      selectedTime: freezed == selectedTime
          ? _value.selectedTime
          : selectedTime // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfMinutes: freezed == numberOfMinutes
          ? _value.numberOfMinutes
          : numberOfMinutes // ignore: cast_nullable_to_non_nullable
              as int?,
      fullyBooked: freezed == fullyBooked
          ? _value.fullyBooked
          : fullyBooked // ignore: cast_nullable_to_non_nullable
              as bool?,
      numberOfUsers: freezed == numberOfUsers
          ? _value.numberOfUsers
          : numberOfUsers // ignore: cast_nullable_to_non_nullable
              as int?,
      countedUsers: freezed == countedUsers
          ? _value.countedUsers
          : countedUsers // ignore: cast_nullable_to_non_nullable
              as int?,
      ladiesOnly: freezed == ladiesOnly
          ? _value.ladiesOnly
          : ladiesOnly // ignore: cast_nullable_to_non_nullable
              as int?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      note: freezed == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String?,
      isBought: freezed == isBought
          ? _value.isBought
          : isBought // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  /// Create a copy of ClassModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @pragma('vm:prefer-inline')
  $CategoryModelCopyWith<$Res>? get category {
    if (_value.category == null) {
      return null;
    }

    return $CategoryModelCopyWith<$Res>(_value.category!, (value) {
      return _then(_value.copyWith(category: value) as $Val);
    });
  }

  /// Create a copy of ClassModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @pragma('vm:prefer-inline')
  $CoachModelCopyWith<$Res>? get coach {
    if (_value.coach == null) {
      return null;
    }

    return $CoachModelCopyWith<$Res>(_value.coach!, (value) {
      return _then(_value.copyWith(coach: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ClassModelImplCopyWith<$Res>
    implements $ClassModelCopyWith<$Res> {
  factory _$$ClassModelImplCopyWith(
          _$ClassModelImpl value, $Res Function(_$ClassModelImpl) then) =
      __$$ClassModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "category_id") int? categoryId,
      @JsonKey(name: "coach_id") int? coachId,
      @JsonKey(name: "category") CategoryModel? category,
      @JsonKey(name: "coach") CoachModel? coach,
      @JsonKey(name: "selected_date") String? selectedDate,
      @JsonKey(name: "selected_time") String? selectedTime,
      @JsonKey(name: "number_of_minutes") int? numberOfMinutes,
      @JsonKey(name: "fully_booked") bool? fullyBooked,
      @JsonKey(name: "number_of_users") int? numberOfUsers,
      @JsonKey(name: "counted_users") int? countedUsers,
      @JsonKey(name: "ladies_only") int? ladiesOnly,
      @JsonKey(name: "description") String? description,
      @JsonKey(name: "note") String? note,
      @JsonKey(name: "is_bought") bool? isBought,
      @JsonKey(name: "created_at") String? createdAt,
      @JsonKey(name: "updated_at") String? updatedAt});

  @override
  $CategoryModelCopyWith<$Res>? get category;
  @override
  $CoachModelCopyWith<$Res>? get coach;
}

/// @nodoc
class __$$ClassModelImplCopyWithImpl<$Res>
    extends _$ClassModelCopyWithImpl<$Res, _$ClassModelImpl>
    implements _$$ClassModelImplCopyWith<$Res> {
  __$$ClassModelImplCopyWithImpl(
      _$ClassModelImpl _value, $Res Function(_$ClassModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of ClassModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? categoryId = freezed,
    Object? coachId = freezed,
    Object? category = freezed,
    Object? coach = freezed,
    Object? selectedDate = freezed,
    Object? selectedTime = freezed,
    Object? numberOfMinutes = freezed,
    Object? fullyBooked = freezed,
    Object? numberOfUsers = freezed,
    Object? countedUsers = freezed,
    Object? ladiesOnly = freezed,
    Object? description = freezed,
    Object? note = freezed,
    Object? isBought = freezed,
    Object? createdAt = freezed,
    Object? updatedAt = freezed,
  }) {
    return _then(_$ClassModelImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      categoryId: freezed == categoryId
          ? _value.categoryId
          : categoryId // ignore: cast_nullable_to_non_nullable
              as int?,
      coachId: freezed == coachId
          ? _value.coachId
          : coachId // ignore: cast_nullable_to_non_nullable
              as int?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as CategoryModel?,
      coach: freezed == coach
          ? _value.coach
          : coach // ignore: cast_nullable_to_non_nullable
              as CoachModel?,
      selectedDate: freezed == selectedDate
          ? _value.selectedDate
          : selectedDate // ignore: cast_nullable_to_non_nullable
              as String?,
      selectedTime: freezed == selectedTime
          ? _value.selectedTime
          : selectedTime // ignore: cast_nullable_to_non_nullable
              as String?,
      numberOfMinutes: freezed == numberOfMinutes
          ? _value.numberOfMinutes
          : numberOfMinutes // ignore: cast_nullable_to_non_nullable
              as int?,
      fullyBooked: freezed == fullyBooked
          ? _value.fullyBooked
          : fullyBooked // ignore: cast_nullable_to_non_nullable
              as bool?,
      numberOfUsers: freezed == numberOfUsers
          ? _value.numberOfUsers
          : numberOfUsers // ignore: cast_nullable_to_non_nullable
              as int?,
      countedUsers: freezed == countedUsers
          ? _value.countedUsers
          : countedUsers // ignore: cast_nullable_to_non_nullable
              as int?,
      ladiesOnly: freezed == ladiesOnly
          ? _value.ladiesOnly
          : ladiesOnly // ignore: cast_nullable_to_non_nullable
              as int?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      note: freezed == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as String?,
      isBought: freezed == isBought
          ? _value.isBought
          : isBought // ignore: cast_nullable_to_non_nullable
              as bool?,
      createdAt: freezed == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String?,
      updatedAt: freezed == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true)
class _$ClassModelImpl extends _ClassModel {
  _$ClassModelImpl(
      {@JsonKey(name: "id") required this.id,
      @JsonKey(name: "category_id") required this.categoryId,
      @JsonKey(name: "coach_id") required this.coachId,
      @JsonKey(name: "category") required this.category,
      @JsonKey(name: "coach") required this.coach,
      @JsonKey(name: "selected_date") required this.selectedDate,
      @JsonKey(name: "selected_time") required this.selectedTime,
      @JsonKey(name: "number_of_minutes") required this.numberOfMinutes,
      @JsonKey(name: "fully_booked") required this.fullyBooked,
      @JsonKey(name: "number_of_users") required this.numberOfUsers,
      @JsonKey(name: "counted_users") required this.countedUsers,
      @JsonKey(name: "ladies_only") required this.ladiesOnly,
      @JsonKey(name: "description") required this.description,
      @JsonKey(name: "note") required this.note,
      @JsonKey(name: "is_bought") required this.isBought,
      @JsonKey(name: "created_at") required this.createdAt,
      @JsonKey(name: "updated_at") required this.updatedAt})
      : super._();

  factory _$ClassModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ClassModelImplFromJson(json);

  @override
  @JsonKey(name: "id")
  int? id;
  @override
  @JsonKey(name: "category_id")
  int? categoryId;
  @override
  @JsonKey(name: "coach_id")
  int? coachId;
  @override
  @JsonKey(name: "category")
  CategoryModel? category;
  @override
  @JsonKey(name: "coach")
  CoachModel? coach;
  @override
  @JsonKey(name: "selected_date")
  String? selectedDate;
  @override
  @JsonKey(name: "selected_time")
  String? selectedTime;
  @override
  @JsonKey(name: "number_of_minutes")
  int? numberOfMinutes;
  @override
  @JsonKey(name: "fully_booked")
  bool? fullyBooked;
  @override
  @JsonKey(name: "number_of_users")
  int? numberOfUsers;
  @override
  @JsonKey(name: "counted_users")
  int? countedUsers;
  @override
  @JsonKey(name: "ladies_only")
  int? ladiesOnly;
  @override
  @JsonKey(name: "description")
  String? description;
  @override
  @JsonKey(name: "note")
  String? note;
  @override
  @JsonKey(name: "is_bought")
  bool? isBought;
  @override
  @JsonKey(name: "created_at")
  String? createdAt;
  @override
  @JsonKey(name: "updated_at")
  String? updatedAt;

  @override
  String toString() {
    return 'ClassModel(id: $id, categoryId: $categoryId, coachId: $coachId, category: $category, coach: $coach, selectedDate: $selectedDate, selectedTime: $selectedTime, numberOfMinutes: $numberOfMinutes, fullyBooked: $fullyBooked, numberOfUsers: $numberOfUsers, countedUsers: $countedUsers, ladiesOnly: $ladiesOnly, description: $description, note: $note, isBought: $isBought, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  /// Create a copy of ClassModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ClassModelImplCopyWith<_$ClassModelImpl> get copyWith =>
      __$$ClassModelImplCopyWithImpl<_$ClassModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ClassModelImplToJson(
      this,
    );
  }
}

abstract class _ClassModel extends ClassModel {
  factory _ClassModel(
          {@JsonKey(name: "id") required int? id,
          @JsonKey(name: "category_id") required int? categoryId,
          @JsonKey(name: "coach_id") required int? coachId,
          @JsonKey(name: "category") required CategoryModel? category,
          @JsonKey(name: "coach") required CoachModel? coach,
          @JsonKey(name: "selected_date") required String? selectedDate,
          @JsonKey(name: "selected_time") required String? selectedTime,
          @JsonKey(name: "number_of_minutes") required int? numberOfMinutes,
          @JsonKey(name: "fully_booked") required bool? fullyBooked,
          @JsonKey(name: "number_of_users") required int? numberOfUsers,
          @JsonKey(name: "counted_users") required int? countedUsers,
          @JsonKey(name: "ladies_only") required int? ladiesOnly,
          @JsonKey(name: "description") required String? description,
          @JsonKey(name: "note") required String? note,
          @JsonKey(name: "is_bought") required bool? isBought,
          @JsonKey(name: "created_at") required String? createdAt,
          @JsonKey(name: "updated_at") required String? updatedAt}) =
      _$ClassModelImpl;
  _ClassModel._() : super._();

  factory _ClassModel.fromJson(Map<String, dynamic> json) =
      _$ClassModelImpl.fromJson;

  @override
  @JsonKey(name: "id")
  int? get id;
  @JsonKey(name: "id")
  set id(int? value);
  @override
  @JsonKey(name: "category_id")
  int? get categoryId;
  @JsonKey(name: "category_id")
  set categoryId(int? value);
  @override
  @JsonKey(name: "coach_id")
  int? get coachId;
  @JsonKey(name: "coach_id")
  set coachId(int? value);
  @override
  @JsonKey(name: "category")
  CategoryModel? get category;
  @JsonKey(name: "category")
  set category(CategoryModel? value);
  @override
  @JsonKey(name: "coach")
  CoachModel? get coach;
  @JsonKey(name: "coach")
  set coach(CoachModel? value);
  @override
  @JsonKey(name: "selected_date")
  String? get selectedDate;
  @JsonKey(name: "selected_date")
  set selectedDate(String? value);
  @override
  @JsonKey(name: "selected_time")
  String? get selectedTime;
  @JsonKey(name: "selected_time")
  set selectedTime(String? value);
  @override
  @JsonKey(name: "number_of_minutes")
  int? get numberOfMinutes;
  @JsonKey(name: "number_of_minutes")
  set numberOfMinutes(int? value);
  @override
  @JsonKey(name: "fully_booked")
  bool? get fullyBooked;
  @JsonKey(name: "fully_booked")
  set fullyBooked(bool? value);
  @override
  @JsonKey(name: "number_of_users")
  int? get numberOfUsers;
  @JsonKey(name: "number_of_users")
  set numberOfUsers(int? value);
  @override
  @JsonKey(name: "counted_users")
  int? get countedUsers;
  @JsonKey(name: "counted_users")
  set countedUsers(int? value);
  @override
  @JsonKey(name: "ladies_only")
  int? get ladiesOnly;
  @JsonKey(name: "ladies_only")
  set ladiesOnly(int? value);
  @override
  @JsonKey(name: "description")
  String? get description;
  @JsonKey(name: "description")
  set description(String? value);
  @override
  @JsonKey(name: "note")
  String? get note;
  @JsonKey(name: "note")
  set note(String? value);
  @override
  @JsonKey(name: "is_bought")
  bool? get isBought;
  @JsonKey(name: "is_bought")
  set isBought(bool? value);
  @override
  @JsonKey(name: "created_at")
  String? get createdAt;
  @JsonKey(name: "created_at")
  set createdAt(String? value);
  @override
  @JsonKey(name: "updated_at")
  String? get updatedAt;
  @JsonKey(name: "updated_at")
  set updatedAt(String? value);

  /// Create a copy of ClassModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ClassModelImplCopyWith<_$ClassModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
