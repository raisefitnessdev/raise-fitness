// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'class_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ClassModelImpl _$$ClassModelImplFromJson(Map<String, dynamic> json) =>
    _$ClassModelImpl(
      id: (json['id'] as num?)?.toInt(),
      categoryId: (json['category_id'] as num?)?.toInt(),
      coachId: (json['coach_id'] as num?)?.toInt(),
      category: json['category'] == null
          ? null
          : CategoryModel.fromJson(json['category'] as Map<String, dynamic>),
      coach: json['coach'] == null
          ? null
          : CoachModel.fromJson(json['coach'] as Map<String, dynamic>),
      selectedDate: json['selected_date'] as String?,
      selectedTime: json['selected_time'] as String?,
      numberOfMinutes: (json['number_of_minutes'] as num?)?.toInt(),
      fullyBooked: json['fully_booked'] as bool?,
      numberOfUsers: (json['number_of_users'] as num?)?.toInt(),
      countedUsers: (json['counted_users'] as num?)?.toInt(),
      ladiesOnly: (json['ladies_only'] as num?)?.toInt(),
      description: json['description'] as String?,
      note: json['note'] as String?,
      isBought: json['is_bought'] as bool?,
      createdAt: json['created_at'] as String?,
      updatedAt: json['updated_at'] as String?,
    );

Map<String, dynamic> _$$ClassModelImplToJson(_$ClassModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'category_id': instance.categoryId,
      'coach_id': instance.coachId,
      'category': instance.category?.toJson(),
      'coach': instance.coach?.toJson(),
      'selected_date': instance.selectedDate,
      'selected_time': instance.selectedTime,
      'number_of_minutes': instance.numberOfMinutes,
      'fully_booked': instance.fullyBooked,
      'number_of_users': instance.numberOfUsers,
      'counted_users': instance.countedUsers,
      'ladies_only': instance.ladiesOnly,
      'description': instance.description,
      'note': instance.note,
      'is_bought': instance.isBought,
      'created_at': instance.createdAt,
      'updated_at': instance.updatedAt,
    };
