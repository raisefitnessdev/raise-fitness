import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:raise/features/base/data/models/category_model/category_model.dart';
import 'package:raise/features/base/data/models/coach_model/coach_model.dart';

part 'class_model.freezed.dart';
part 'class_model.g.dart';

@unfreezed
@immutable
class ClassModel with _$ClassModel {
  const ClassModel._();

  @JsonSerializable(explicitToJson: true)
  factory ClassModel({
    @JsonKey(name: "id") required int? id,
    @JsonKey(name: "category_id") required int? categoryId,
    @JsonKey(name: "coach_id") required int? coachId,
    @JsonKey(name: "category") required CategoryModel? category,
    @JsonKey(name: "coach") required CoachModel? coach,
    @JsonKey(name: "selected_date") required String? selectedDate,
    @JsonKey(name: "selected_time") required String? selectedTime,
    @JsonKey(name: "number_of_minutes") required int? numberOfMinutes,
    @JsonKey(name: "fully_booked") required bool? fullyBooked,
    @JsonKey(name: "number_of_users") required int? numberOfUsers,
    @JsonKey(name: "counted_users") required int? countedUsers,
    @JsonKey(name: "ladies_only") required int? ladiesOnly,
    @JsonKey(name: "description") required String? description,
    @JsonKey(name: "note") required String? note,
    @JsonKey(name: "is_bought") required bool? isBought,
    @JsonKey(name: "created_at") required String? createdAt,
    @JsonKey(name: "updated_at") required String? updatedAt,
  }) = _ClassModel;

  factory ClassModel.fromJson(Map<String, dynamic> json) =>
      _$ClassModelFromJson(json);
}
