import 'package:freezed_annotation/freezed_annotation.dart';

part 'coach_model.freezed.dart';
part 'coach_model.g.dart';

@unfreezed
@immutable
class CoachModel with _$CoachModel {
  const CoachModel._();

  @JsonSerializable(explicitToJson: true)
  factory CoachModel({
    @JsonKey(name: "id") required int? id,
    @JsonKey(name: "name") required String? name,
    @JsonKey(name: "image") required String? image,
  }) = _CoachModel;

  factory CoachModel.fromJson(Map<String, dynamic> json) =>
      _$CoachModelFromJson(json);
}
