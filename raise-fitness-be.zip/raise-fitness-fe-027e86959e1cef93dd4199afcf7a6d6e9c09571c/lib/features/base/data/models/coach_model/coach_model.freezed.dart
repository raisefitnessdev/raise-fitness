// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'coach_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

CoachModel _$CoachModelFromJson(Map<String, dynamic> json) {
  return _CoachModel.fromJson(json);
}

/// @nodoc
mixin _$CoachModel {
  @JsonKey(name: "id")
  int? get id => throw _privateConstructorUsedError;
  @JsonKey(name: "id")
  set id(int? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "name")
  String? get name => throw _privateConstructorUsedError;
  @JsonKey(name: "name")
  set name(String? value) => throw _privateConstructorUsedError;
  @JsonKey(name: "image")
  String? get image => throw _privateConstructorUsedError;
  @JsonKey(name: "image")
  set image(String? value) => throw _privateConstructorUsedError;

  /// Serializes this CoachModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of CoachModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $CoachModelCopyWith<CoachModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CoachModelCopyWith<$Res> {
  factory $CoachModelCopyWith(
          CoachModel value, $Res Function(CoachModel) then) =
      _$CoachModelCopyWithImpl<$Res, CoachModel>;
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "name") String? name,
      @JsonKey(name: "image") String? image});
}

/// @nodoc
class _$CoachModelCopyWithImpl<$Res, $Val extends CoachModel>
    implements $CoachModelCopyWith<$Res> {
  _$CoachModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of CoachModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? image = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      image: freezed == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CoachModelImplCopyWith<$Res>
    implements $CoachModelCopyWith<$Res> {
  factory _$$CoachModelImplCopyWith(
          _$CoachModelImpl value, $Res Function(_$CoachModelImpl) then) =
      __$$CoachModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: "id") int? id,
      @JsonKey(name: "name") String? name,
      @JsonKey(name: "image") String? image});
}

/// @nodoc
class __$$CoachModelImplCopyWithImpl<$Res>
    extends _$CoachModelCopyWithImpl<$Res, _$CoachModelImpl>
    implements _$$CoachModelImplCopyWith<$Res> {
  __$$CoachModelImplCopyWithImpl(
      _$CoachModelImpl _value, $Res Function(_$CoachModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of CoachModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? name = freezed,
    Object? image = freezed,
  }) {
    return _then(_$CoachModelImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      image: freezed == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

@JsonSerializable(explicitToJson: true)
class _$CoachModelImpl extends _CoachModel {
  _$CoachModelImpl(
      {@JsonKey(name: "id") required this.id,
      @JsonKey(name: "name") required this.name,
      @JsonKey(name: "image") required this.image})
      : super._();

  factory _$CoachModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$CoachModelImplFromJson(json);

  @override
  @JsonKey(name: "id")
  int? id;
  @override
  @JsonKey(name: "name")
  String? name;
  @override
  @JsonKey(name: "image")
  String? image;

  @override
  String toString() {
    return 'CoachModel(id: $id, name: $name, image: $image)';
  }

  /// Create a copy of CoachModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$CoachModelImplCopyWith<_$CoachModelImpl> get copyWith =>
      __$$CoachModelImplCopyWithImpl<_$CoachModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CoachModelImplToJson(
      this,
    );
  }
}

abstract class _CoachModel extends CoachModel {
  factory _CoachModel(
      {@JsonKey(name: "id") required int? id,
      @JsonKey(name: "name") required String? name,
      @JsonKey(name: "image") required String? image}) = _$CoachModelImpl;
  _CoachModel._() : super._();

  factory _CoachModel.fromJson(Map<String, dynamic> json) =
      _$CoachModelImpl.fromJson;

  @override
  @JsonKey(name: "id")
  int? get id;
  @JsonKey(name: "id")
  set id(int? value);
  @override
  @JsonKey(name: "name")
  String? get name;
  @JsonKey(name: "name")
  set name(String? value);
  @override
  @JsonKey(name: "image")
  String? get image;
  @JsonKey(name: "image")
  set image(String? value);

  /// Create a copy of CoachModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$CoachModelImplCopyWith<_$CoachModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
