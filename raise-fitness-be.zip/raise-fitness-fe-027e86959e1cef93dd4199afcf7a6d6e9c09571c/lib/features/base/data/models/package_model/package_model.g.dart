// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'package_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PackageModelImpl _$$PackageModelImplFromJson(Map<String, dynamic> json) =>
    _$PackageModelImpl(
      id: (json['id'] as num?)?.toInt(),
      title: json['title'] as String?,
      price: json['price'] as String?,
      numberOfSessions: (json['number_of_sessions'] as num?)?.toInt(),
      isFree: (json['is_free'] as num?)?.toInt(),
      validityDays: (json['validity_days'] as num?)?.toInt(),
    );

Map<String, dynamic> _$$PackageModelImplToJson(_$PackageModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'title': instance.title,
      'price': instance.price,
      'number_of_sessions': instance.numberOfSessions,
      'is_free': instance.isFree,
      'validity_days': instance.validityDays,
    };
