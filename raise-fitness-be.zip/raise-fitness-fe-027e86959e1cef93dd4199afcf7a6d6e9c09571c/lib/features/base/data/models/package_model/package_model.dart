import 'package:freezed_annotation/freezed_annotation.dart';

part 'package_model.freezed.dart';
part 'package_model.g.dart';

@unfreezed
@immutable
class PackageModel with _$PackageModel {
  const PackageModel._();

  @JsonSerializable(explicitToJson: true)
  factory PackageModel({
    @JsonKey(name: "id") required int? id,
    @JsonKey(name: "title") required String? title,
    @JsonKey(name: "price") required String? price,
    @JsonKey(name: "number_of_sessions") required int? numberOfSessions,
    @JsonKey(name: "is_free") required int? isFree,
    @JsonKey(name: "validity_days") required int? validityDays,
  }) = _PackageModel;

  factory PackageModel.fromJson(Map<String, dynamic> json) =>
      _$PackageModelFromJson(json);
}
