import 'package:freezed_annotation/freezed_annotation.dart';

part 'category_model.freezed.dart';
part 'category_model.g.dart';

@unfreezed
@immutable
class CategoryModel with _$CategoryModel {
  const CategoryModel._();

  @JsonSerializable(explicitToJson: true)
  factory CategoryModel({
    @JsonKey(name: "id") required int? id,
    @JsonKey(name: "title") required String? title,
  }) = _CategoryModel;

  factory CategoryModel.fromJson(Map<String, dynamic> json) =>
      _$CategoryModelFromJson(json);
}
