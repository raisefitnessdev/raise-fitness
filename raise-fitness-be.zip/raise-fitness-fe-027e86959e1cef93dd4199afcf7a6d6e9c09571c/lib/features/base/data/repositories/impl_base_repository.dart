import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/http/models/result.dart';
import 'package:raise/core/models/model_to_domain/model_to_domain.dart';
import 'package:raise/features/auth/data/models/user_info_model/user_info_model.dart';
import 'package:raise/features/base/data/data_sources/home_remote_data_source.dart';
import 'package:raise/features/base/data/models/booking_model/booking_model.dart';
import 'package:raise/features/base/data/models/class_model/class_model.dart';
import 'package:raise/features/base/data/models/general_model/general_model.dart';
import 'package:raise/features/base/data/models/notification_model/notification_model.dart';
import 'package:raise/features/base/data/models/package_model/package_model.dart';
import 'package:raise/features/base/data/models/user_package_model/user_package_model.dart';
import 'package:raise/features/base/domain/entity/buy_class_params.dart';
import 'package:raise/features/base/domain/entity/class_status_params.dart';
import 'package:raise/features/base/domain/entity/contact_us_params.dart';
import 'package:raise/features/base/domain/entity/profile_params.dart';
import 'package:raise/features/base/domain/entity/purchase_package_params.dart';
import 'package:raise/features/base/domain/entity/update_password_params.dart';
import 'package:raise/features/base/domain/repositories/base_repository.dart';
import 'package:injectable/injectable.dart';

@Injectable(as: BaseRepository)
class ImplBaseRepository extends BaseRepository with ModelToDomainResult {
  @override
  Future<MyResult<List<ClassModel>>> getClasses(String param) async {
    return await getIt.get<HomeRemoteDataSource>().getClasses(param);
  }

  @override
  Future<MyResult<List<PackageModel>>> getPackages(bool param) async {
    return await getIt.get<HomeRemoteDataSource>().getPackages(param);
  }

  @override
  Future<MyResult<List<UserPackageModel>>> myPackages(bool param) async {
    return await getIt.get<HomeRemoteDataSource>().myPackages(param);
  }

  @override
  Future<MyResult<UserInfoModel>> getProfile(bool param) async {
    return await getIt.get<HomeRemoteDataSource>().getProfile(param);
  }

  @override
  Future<MyResult<UserInfoModel>> editProfile(ProfileParams param) async {
    return await getIt.get<HomeRemoteDataSource>().editProfile(param);
  }

  @override
  Future<MyResult<String>> updatePassword(UpdatePasswordParams param) async {
    return await getIt.get<HomeRemoteDataSource>().updatePassword(param);
  }

  @override
  Future<MyResult<UserPackageModel>> purchasePackage(PurchasePackageParams param) async {
    return await getIt.get<HomeRemoteDataSource>().purchasePackage(param);
  }

  @override
  Future<MyResult<String>> activatePackage(int param) async {
    return await getIt.get<HomeRemoteDataSource>().activatePackage(param);
  }

  @override
  Future<MyResult<String>> buyClass(BuyClassParams param) async {
    return await getIt.get<HomeRemoteDataSource>().buyClass(param);
  }

  @override
  Future<MyResult<List<BookingModel>>> myClasses(bool param) async {
    return await getIt.get<HomeRemoteDataSource>().myClasses(param);
  }

  @override
  Future<MyResult<bool>> contactUs(ContactUsParams param) async {
    return await getIt.get<HomeRemoteDataSource>().contactUs(param);
  }

  @override
  Future<MyResult<List<GeneralModel>>> getSettings(bool param) async {
    return await getIt.get<HomeRemoteDataSource>().getSettings(param);
  }

  @override
  Future<MyResult<List<GeneralModel>>> getFAQ(bool param) async {
    return await getIt.get<HomeRemoteDataSource>().getFAQ(param);
  }

  @override
  Future<MyResult<List<NotificationModel>>> getNotifications(bool param) async {
    return await getIt.get<HomeRemoteDataSource>().getNotifications(param);
  }

  @override
  Future<MyResult<int>> getNotificationCount(bool param) async {
    return await getIt.get<HomeRemoteDataSource>().getNotificationCount(param);
  }

  @override
  Future<MyResult<bool>> removeAccount(bool param) async {
    return await getIt.get<HomeRemoteDataSource>().removeAccount(param);
  }

  @override
  Future<MyResult<bool>> changeStatus(ClassStatusParams param) async {
    return await getIt.get<HomeRemoteDataSource>().changeStatus(param);
  }
}
