import 'package:raise/core/http/generic_http/api_names.dart';
import 'package:raise/core/http/generic_http/generic_http.dart';
import 'package:raise/core/http/models/http_request_model.dart';
import 'package:raise/core/http/models/result.dart';
import 'package:injectable/injectable.dart';
import 'package:raise/features/auth/data/models/user_info_model/user_info_model.dart';
import 'package:raise/features/base/data/models/booking_model/booking_model.dart';
import 'package:raise/features/base/data/models/class_model/class_model.dart';
import 'package:raise/features/base/data/models/general_model/general_model.dart';
import 'package:raise/features/base/data/models/notification_model/notification_model.dart';
import 'package:raise/features/base/data/models/package_model/package_model.dart';
import 'package:raise/features/base/data/models/user_package_model/user_package_model.dart';
import 'package:raise/features/base/domain/entity/buy_class_params.dart';
import 'package:raise/features/base/domain/entity/class_status_params.dart';
import 'package:raise/features/base/domain/entity/contact_us_params.dart';
import 'package:raise/features/base/domain/entity/profile_params.dart';
import 'package:raise/features/base/domain/entity/purchase_package_params.dart';
import 'package:raise/features/base/domain/entity/update_password_params.dart';

import 'home_remote_data_source.dart';

@Injectable(as: HomeRemoteDataSource)
class ImplHomeRemoteDataSource extends HomeRemoteDataSource {
  @override
  Future<MyResult<List<ClassModel>>> getClasses(String param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.classes,
      requestMethod: RequestMethod.post,
      responseType: ResType.list,
      requestBody: {"selected_date": param},
      refresh: true,
      responseKey: (data) => data["data"],
      toJsonFunc: (json) => List<ClassModel>.from(json.map((e) => ClassModel.fromJson(e))),
    );
    return await GenericHttpImpl<List<ClassModel>>()(model);
  }

  @override
  Future<MyResult<List<PackageModel>>> getPackages(bool param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.packages,
      requestMethod: RequestMethod.get,
      responseType: ResType.list,
      refresh: true,
      responseKey: (data) => data["data"],
      toJsonFunc: (json) => List<PackageModel>.from(json.map((e) => PackageModel.fromJson(e))),
    );
    return await GenericHttpImpl<List<PackageModel>>()(model);
  }

  @override
  Future<MyResult<List<UserPackageModel>>> myPackages(bool param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.myPackages,
      requestMethod: RequestMethod.get,
      responseType: ResType.list,
      refresh: true,
      responseKey: (data) => data["data"],
      toJsonFunc: (json) => List<UserPackageModel>.from(json.map((e) => UserPackageModel.fromJson(e))),
    );
    return await GenericHttpImpl<List<UserPackageModel>>()(model);
  }

  @override
  Future<MyResult<UserInfoModel>> getProfile(bool param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.profile,
      requestMethod: RequestMethod.get,
      responseType: ResType.model,
      refresh: true,
      responseKey: (data) => data["data"],
      toJsonFunc: (json) => UserInfoModel.fromJson(json),
    );
    return await GenericHttpImpl<UserInfoModel>()(model);
  }

  @override
  Future<MyResult<UserInfoModel>> editProfile(ProfileParams param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.updateProfile,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: param.toJson(),
      responseKey: (data) => data["data"],
      toJsonFunc: (json) => UserInfoModel.fromJson(json),
      showLoader: true,
      errorFunc: (json)=> json['msg']
    );
    return await GenericHttpImpl<UserInfoModel>()(model);
  }

  @override
  Future<MyResult<String>> updatePassword(UpdatePasswordParams param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.updatePassword,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: param.toJson(),
      responseKey: (data) => data["data"],
      showLoader: true,
      errorFunc: (json)=> json['msg']
      // toJsonFunc: (json) => UserInfoModel.fromJson(json),
    );
    return await GenericHttpImpl<String>()(model);
  }

  @override
  Future<MyResult<UserPackageModel>> purchasePackage(PurchasePackageParams param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.purchasePackage,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: param.toJson(),
      responseKey: (data) => data["data"],
      toJsonFunc: (json) => UserPackageModel.fromJson(json),
      showLoader: true,
      errorFunc: (json)=> json['msg']
    );
    return await GenericHttpImpl<UserPackageModel>()(model);
  }

  @override
  Future<MyResult<String>> activatePackage(int param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.activatePackage,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: {"user_package_id": param},
      responseKey: (data) => data["data"],
      showLoader: true,
      errorFunc: (json)=> json['msg']
      // toJsonFunc: (json) => UserInfoModel.fromJson(json),
    );
    return await GenericHttpImpl<String>()(model);
  }

  @override
  Future<MyResult<String>> buyClass(BuyClassParams param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.buyClass,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: param.toJson(),
      responseKey: (data) => data["data"],
      showLoader: true,
      errorFunc: (json)=> json['msg']
      // toJsonFunc: (json) => UserInfoModel.fromJson(json),
    );
    return await GenericHttpImpl<String>()(model);
  }

  @override
  Future<MyResult<List<BookingModel>>> myClasses(bool param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.myClasses,
      requestMethod: RequestMethod.get,
      responseType: ResType.list,
      refresh: true,
      responseKey: (data) => data["data"],
      toJsonFunc: (json) => List<BookingModel>.from(json.map((e) => BookingModel.fromJson(e))),
    );
    return await GenericHttpImpl<List<BookingModel>>()(model);
  }

  @override
  Future<MyResult<bool>> contactUs(ContactUsParams param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.contactUs,
      requestMethod: RequestMethod.post,
      responseType: ResType.model,
      requestBody: param.toJson(),
      responseKey: (data) => data["value"],
      showLoader: true,
      errorFunc: (json)=> json['msg']
      // toJsonFunc: (json) => UserInfoModel.fromJson(json),
    );
    return await GenericHttpImpl<bool>()(model);
  }

  @override
  Future<MyResult<List<GeneralModel>>> getSettings(bool param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.settings,
      requestMethod: RequestMethod.get,
      responseType: ResType.list,
      refresh: true,
      responseKey: (data) => data["data"],
      toJsonFunc: (json) => List<GeneralModel>.from(json.map((e) => GeneralModel.fromJson(e))),
    );
    return await GenericHttpImpl<List<GeneralModel>>()(model);
  }

  @override
  Future<MyResult<List<GeneralModel>>> getFAQ(bool param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.faqs,
      requestMethod: RequestMethod.get,
      responseType: ResType.list,
      refresh: true,
      responseKey: (data) => data["data"],
      toJsonFunc: (json) => List<GeneralModel>.from(json.map((e) => GeneralModel.fromJson(e))),
    );
    return await GenericHttpImpl<List<GeneralModel>>()(model);
  }

  @override
  Future<MyResult<List<NotificationModel>>> getNotifications(bool param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.notifications,
      requestMethod: RequestMethod.get,
      responseType: ResType.list,
      refresh: true,
      responseKey: (data) => data["data"],
      toJsonFunc: (json) => List<NotificationModel>.from(json.map((e) => NotificationModel.fromJson(e))),
    );
    return await GenericHttpImpl<List<NotificationModel>>()(model);
  }

  @override
  Future<MyResult<int>> getNotificationCount(bool param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.notificationCount,
      requestMethod: RequestMethod.get,
      responseType: ResType.type,
      refresh: true,
      responseKey: (data) => data["data"]["unread_count"],
    );
    return await GenericHttpImpl<int>()(model);
  }

  @override
  Future<MyResult<bool>> removeAccount(bool param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.removeAccount,
      requestMethod: RequestMethod.get,
      responseType: ResType.type,
      refresh: true,
      showLoader: true,
      responseKey: (data) => data["value"],
      errorFunc: (json)=> json['msg'],
    );
    return await GenericHttpImpl<bool>()(model);
  }

  @override
  Future<MyResult<bool>> changeStatus(ClassStatusParams param) async {
    HttpRequestModel model = HttpRequestModel(
      url: ApiNames.changeStatus,
      requestMethod: RequestMethod.post,
      responseType: ResType.type,
      requestBody: param.toJson(),
      refresh: true,
      showLoader: true,
      responseKey: (data) => data["value"],
      errorFunc: (json)=> json['msg'],
    );
    return await GenericHttpImpl<bool>()(model);
  }
}
