part of "class_details_widgets_imports.dart";

class BuildClassDescription extends StatelessWidget {
  final ClassModel details;
  const BuildClassDescription({super.key, required this.details});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Description",
          style: AppTextStyle.s16_w600(
            color: context.colors.noticesTextColor,
          ).copyWith(fontFamily: AppTheme.conthraxFamily),
        ),
        Gaps.vGap16,
        Text(
          details.description??"",
          style: AppTextStyle.s14_w500(
            color: context.colors.vacantBgColor,
          ).copyWith(height: 1.5),
        ),
      ],
    );
  }
}
