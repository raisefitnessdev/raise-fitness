part of "class_details_widgets_imports.dart";

class BuildClassButton extends StatelessWidget {
  final ClassModel details;
  final ClassDetailsController controller;
  const BuildClassButton(
      {super.key, required this.details, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Visibility(
          visible: details.fullyBooked == false,
          replacement: Center(
            child: Text(
              "Class is fully booked",
              style: AppTextStyle.s16_w700(color: context.colors.red),
            ),
          ),
          child: AppTextButton.maxCustom(
            onPressed: () => controller.onChoosePackage(context, details),
            bgColor: context.colors.black,
            txtColor: context.colors.primary,
            textSize: 18,
            maxHeight: 50,
            borderRadius: 50,
            text: "Book Now",
          ),
        ),
        Gaps.vGap24,
        Text(
          "THOSE WHO ARRIVE 5 MINS AFTER THE START OF THE CLASS WILL NOT BE PERMITTED TO ENTER",
          textAlign: TextAlign.center,
          style: AppTextStyle.s12_w500(
            color: context.colors.black,
          ).copyWith(height: 1.5),
        ),
      ],
    );
  }
}
