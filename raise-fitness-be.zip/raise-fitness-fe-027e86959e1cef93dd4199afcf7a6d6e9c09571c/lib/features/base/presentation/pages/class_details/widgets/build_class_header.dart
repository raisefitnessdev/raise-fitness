part of "class_details_widgets_imports.dart";

class BuildClassHeader extends StatelessWidget {
  final ClassModel details;
  const BuildClassHeader({super.key, required this.details});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        CachedImage(
          url: details.coach?.image ?? "",
          height: 130.h,
          width: 125.w,
          borderRadius: BorderRadius.circular(12).r,
        ),
        Gaps.vGap14,
        Text(
          details.category?.title ?? "",
          style: AppTextStyle.s16_w700(
            color: context.colors.noticesTextColor,
          ),
        ),
        Gaps.vGap8,
        Text(
          details.coach?.name ?? "",
          style: AppTextStyle.s14_w600(
            color: context.colors.black,
          ),
        ),
        Gaps.vGap16,
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              padding:
                  const EdgeInsets.symmetric(vertical: 4, horizontal: 10).r,
              decoration: BoxDecoration(
                color: context.colors.backgroundWhite,
                borderRadius: BorderRadius.circular(30).r,
                border: Border.all(color: context.colors.secondaryText),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Icon(
                    Icons.watch_later_outlined,
                    size: 15.r,
                    color: context.colors.noticesTextColor,
                  ),
                  Gaps.hGap4,
                  Text(
                    DateFormat("hh:mm a").format(DateTime.parse(
                        "${details.selectedDate} ${details.selectedTime}")),
                    style: AppTextStyle.s12_w700(
                      color: context.colors.noticesTextColor,
                    ),
                  ),
                ],
              ),
            ),
            Gaps.hGap8,
            // Container(
            //   padding:
            //       const EdgeInsets.symmetric(vertical: 4, horizontal: 10).r,
            //   decoration: BoxDecoration(
            //     color: context.colors.backgroundWhite,
            //     borderRadius: BorderRadius.circular(30).r,
            //     border: Border.all(color: context.colors.secondaryText),
            //   ),
            //   child: Row(
            //     crossAxisAlignment: CrossAxisAlignment.center,
            //     children: [
            //       SvgPicture.asset(
            //         Res.spots,
            //         height: 15.r,
            //         width: 15.r,
            //         fit: BoxFit.contain,
            //         color: context.colors.noticesTextColor,
            //       ),
            //       Gaps.hGap4,
            //       Text(
            //         "${(details.numberOfUsers ?? 0 - details.countedUsers!)} spots left",
            //         style: AppTextStyle.s12_w700(
            //           color: context.colors.noticesTextColor,
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            Visibility(
                  visible: details.ladiesOnly == 1,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6).r,
                    decoration: BoxDecoration(
                      color: context.colors.primary,
                      borderRadius: BorderRadius.circular(30).r,
                    ),
                    child: Text(
                      "Ladies only",
                      style: AppTextStyle.s12_w700(
                        color: context.colors.noticesTextColor,
                      ),
                    ),
                  ),
                ),
            Gaps.hGap8,
            Container(
              padding:
                  const EdgeInsets.symmetric(vertical: 4, horizontal: 10).r,
              decoration: BoxDecoration(
                color: context.colors.backgroundWhite,
                borderRadius: BorderRadius.circular(30).r,
                border: Border.all(color: context.colors.secondaryText),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Icon(
                    Icons.alarm,
                    size: 15.r,
                    color: context.colors.noticesTextColor,
                  ),
                  Gaps.hGap4,
                  Text(
                    "${details.numberOfMinutes}Min.",
                    style: AppTextStyle.s12_w700(
                      color: context.colors.noticesTextColor,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}
