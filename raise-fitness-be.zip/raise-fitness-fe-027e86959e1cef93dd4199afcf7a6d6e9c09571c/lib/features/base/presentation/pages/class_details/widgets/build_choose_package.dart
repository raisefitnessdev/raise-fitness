part of "class_details_widgets_imports.dart";

class BuildChoosePackage extends StatelessWidget {
  final ClassDetailsController controller;
  final ClassModel details;
  const BuildChoosePackage(
      {super.key, required this.controller, required this.details});

  @override
  Widget build(BuildContext context) {
    return RequesterConsumer(
      requester: controller.requester,
      successBuilder: (context, data) {
        return Container(
            decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius: BorderRadius.only(
                topRight: const Radius.circular(20).r,
                topLeft: const Radius.circular(20).r,
              ),
            ),
            child: LimitedBox(
                maxHeight: MediaQuery.of(context).size.height * .9,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 15)
                          .r,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                            margin: const EdgeInsets.symmetric(vertical: 10),
                            alignment: Alignment.centerLeft,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Proceed to checkout",
                                  style: AppTextStyle.s20_w500(
                                      color: context.colors.black),
                                ),
                                InkWell(
                                  onTap: () =>
                                      AutoRouter.of(context).popForced(),
                                  child: Icon(
                                    Icons.close,
                                    color: context.colors.black,
                                  ),
                                )
                              ],
                            )),
                        ObsValueConsumer(
                            observable: controller.packageObs,
                            builder: (context, packageObs) {
                              return Column(
                                mainAxisSize: MainAxisSize.min,
                                children: List.generate(
                                    data.length,
                                    (index) => BuildCustomSheetItem(
                                          onTap: () {
                                            controller.packageObs
                                                .setValue(data[index]);
                                          },
                                          title:
                                              data[index].package?.title ?? "",
                                          isSelected:
                                              data[index].id == packageObs?.id,
                                        )),
                              );
                            }),
                        Gaps.vGap10,
                        Center(
                          child: Text(
                            "Book from packages",
                            style: AppTextStyle.s12_w400(
                                color: context.colors.black),
                          ),
                        ),
                        Gaps.vGap10,
                        InkWell(
                          onTap: () => data.isEmpty
                              ? AutoRouter.of(context).push(Dashboard(index: 1))
                              : controller.showConfirmClass(context, details),
                          child: Container(
                            height: 50,
                            width: MediaQuery.of(context).size.width,
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16).r,
                            decoration: BoxDecoration(
                              color: context.colors.black,
                              borderRadius: BorderRadius.circular(12).r,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  data.isEmpty ? "Buy Package" : "Book Class",
                                  style: AppTextStyle.s14_w400(
                                      color: context.colors.white),
                                ),
                                // Text(
                                //   "1 class",
                                //   style: AppTextStyle.s14_w400(
                                //       color: context.colors.white),
                                // ),
                              ],
                            ),
                          ),
                        ),
                      ]),
                )));
      },
      loadingBuilder: (context) {
        return const CustomIndicator();
      },
      failureBuilder: (context, error, callback) {
        return FailureViewWidget(onTap: callback);
      },
    );
  }
}
