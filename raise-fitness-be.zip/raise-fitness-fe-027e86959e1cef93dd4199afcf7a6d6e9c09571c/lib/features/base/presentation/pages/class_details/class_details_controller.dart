part of "class_details_imports.dart";

class ClassDetailsController {
  ClassDetailsController() {
    requestMyPackages();
  }

  ObsValue<UserPackageModel?> packageObs = ObsValue.withInit(null);

  MyPackagesRequester requester = MyPackagesRequester();

  Future<void> requestMyPackages() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }

  Future<bool> buyclass({required int classId}) async {
    BuyClassParams params = buyClassParams(classId);
    var codeResponse = await getIt<BaseRepository>().buyClass(params);
    return _handlePayResponse(codeResponse);
  }

  bool _handlePayResponse(MyResult<String> response) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (data) {
      showSuccessClass(context);
      return true;
    }, isError: (error) {
      return false;
    });
  }

  BuyClassParams buyClassParams(int classId) {
    return BuyClassParams(
      classId: classId,
      packageId: packageObs.getValue()!.id!,
    );
  }

  void onChoosePackage(BuildContext context, ClassModel details) {
    details.isBought ?? false
        ? AppSnackBar.showSimpleToast(
            // color: context.colors.black,
            msg: "You already book this class",
            type: ToastType.error,
          )
        : showModalBottomSheet(
            isScrollControlled: true,
            isDismissible: true,
            enableDrag: true,
            context: context,
            builder: (context) {
              return BuildChoosePackage(controller: this, details: details);
            },
          );
  }

  void showSuccessClass(BuildContext context) {
    showDialog(
      context: context,
      builder: (cxt) {
        return BuildSuccessAlert(
          onTap: () => AutoRouter.of(context).push(const JourneyRoute()),
          isClass: true,
        );
      },
    );
  }

  void showConfirmClass(BuildContext context, ClassModel details) {
    packageObs.getValue() == null
        ? AppSnackBar.showSimpleToast(
            // color: context.colors.black,
            msg: "Select a package to proceed",
            type: ToastType.error,
          )
        : showDialog(
            context: context,
            builder: (cxt) {
              return BuildConfirmAlert(
                onTap: () => buyclass(classId: details.id!),
              );
            },
          );
  }
}
