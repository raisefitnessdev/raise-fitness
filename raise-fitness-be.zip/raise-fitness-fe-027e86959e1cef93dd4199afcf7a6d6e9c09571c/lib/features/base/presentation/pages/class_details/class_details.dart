part of "class_details_imports.dart";

@RoutePage(name: "ClassDetailsRoute")
class ClassDetails extends StatefulWidget {
  final ClassModel details;
  const ClassDetails({super.key, required this.details});

  @override
  State<ClassDetails> createState() => _ClassDetailsState();
}

class _ClassDetailsState extends State<ClassDetails> {
  final ClassDetailsController controller = ClassDetailsController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: DefaultAppBar(
        title: widget.details.category?.title ?? "",
        showBack: true,
        actions: const [
          NotificationWidget(),
        ],
      ),
      bottomNavigationBar: const PresistBottomBar(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.85,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(24).r,
            decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(50)).r,
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Gaps.vGap8,
                  BuildClassHeader(details: widget.details),
                  Gaps.vGap32,
                  BuildClassDescription(details: widget.details),
                  Gaps.vGap32,
                  BuildClassButton(details: widget.details, controller: controller,),
                  Gaps.vGap64,
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
