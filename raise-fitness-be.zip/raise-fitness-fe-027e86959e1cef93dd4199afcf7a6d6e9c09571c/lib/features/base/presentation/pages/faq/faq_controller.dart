part of "faq_imports.dart";

class FAQController {
  FAQController() {
    requestFAQ();
  }

  FAQRequester requester = FAQRequester();

  Future<void> requestFAQ() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }
}
