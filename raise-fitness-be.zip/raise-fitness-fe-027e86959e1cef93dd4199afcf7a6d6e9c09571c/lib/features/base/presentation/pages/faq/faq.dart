part of "faq_imports.dart";

@RoutePage(name: "FAQRoute")
class FAQ extends StatefulWidget {
  const FAQ({super.key});

  @override
  State<FAQ> createState() => _FAQState();
}

class _FAQState extends State<FAQ> {
  final FAQController controller = FAQController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: const DefaultAppBar(
        title: "FAQ",
        showBack: true,
        actions: [
          NotificationWidget(),
        ],
      ),
      bottomNavigationBar: const PresistBottomBar(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.85,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(24).r,
            decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(50)).r,
            ),
            child: RequesterConsumer(
              requester: controller.requester,
              successBuilder: (context, data) {
                return data.isEmpty
                    ? Center(
                        child: Text(
                        "No FAQs available!",
                        style: AppTextStyle.s18_w400(
                            color: context.colors.darkTextColor),
                      ))
                    : ListView.separated(
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        padding: EdgeInsets.zero,
                        physics: const BouncingScrollPhysics(),
                        itemBuilder: (context, index) => GFAccordion(
                          titlePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16).r,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16).r,
                              contentBackgroundColor: context.colors.bgLight,
                              titleBorderRadius: const BorderRadius.vertical(
                                      top: Radius.circular(12))
                                  .r,
                              expandedTitleBackgroundColor:
                                  context.colors.bgLight,
                              collapsedTitleBackgroundColor:
                                  context.colors.bgLight,
                              contentBorderRadius: const BorderRadius.vertical(
                                      bottom: Radius.circular(12))
                                  .r,
                              expandedIcon: Icon(
                                Icons.keyboard_arrow_up,
                                size: 20.r,
                                color: context.colors.black,
                              ),
                              collapsedIcon: Icon(
                                Icons.keyboard_arrow_down,
                                size: 20.r,
                                color: context.colors.black,
                              ),
                              contentChild: Text(
                                data[index].details ?? "",
                                style: AppTextStyle.s14_w500(
                                    color: context.colors.vacantBgColor),
                              ),
                              titleChild: Text(
                                data[index].title ?? "",
                                style: AppTextStyle.s14_w500(
                                    color: context.colors.black),
                              ),
                            ),
                        separatorBuilder: (context, index) => Gaps.vGap24,
                        itemCount: data.length);
              },
              loadingBuilder: (context) {
                return BaseShimmerWidget(
                  child: ListView.separated(
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      padding: EdgeInsets.zero,
                      physics: const BouncingScrollPhysics(),
                      itemBuilder: (context, index) => Container(
                            width: MediaQuery.of(context).size.width,
                            height: 60.h,
                            decoration: BoxDecoration(
                              color: context.colors.bgLight,
                              borderRadius: BorderRadius.circular(10).r,
                            ),
                          ),
                      separatorBuilder: (context, index) => Gaps.vGap16,
                      itemCount: 14),
                );
              },
              failureBuilder: (context, error, callback) {
                return FailureViewWidget(onTap: callback);
              },
            ),
          ),
        ],
      ),
    );
  }
}
