part of "profile_imports.dart";

class ProfileController {
  ProfileController() {
    requestProfile();
  }

  final GlobalKey<FormState> formKey = GlobalKey();

  ObsValue<bool> visibleObs = ObsValue.withInit(false);
  ObsValue<bool> visibleNewObs = ObsValue.withInit(false);
  ObsValue<bool> visibleConfirmPasObs = ObsValue.withInit(false);

  final TextEditingController password = TextEditingController();
  final TextEditingController newPassword = TextEditingController();
  final TextEditingController confirmPassword = TextEditingController();

  ProfileRequester requester = ProfileRequester();

  Future<void> requestProfile() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }

  void passwordSheet(BuildContext context) {
    AppBottomSheets.showScrollableBody(
      context: context,
      builder: (context) {
        return ChangePasswordSheet(
          controller: this,
        );
      },
    );
  }

  Future<bool> onSubmitUpdatePassword(BuildContext context) async {
    if (_checkFormValidation()) {
      UpdatePasswordParams params = updatePasswordParams();
      var passwordResponse =
          await getIt<BaseRepository>().updatePassword(params);
      return _handlePasswordResponse(passwordResponse);
    } else {
      return false;
    }
  }

  bool _handlePasswordResponse(MyResult<String> response) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (value) {
      AppSnackBar.showSimpleToast(
        color: context.colors.black,
        msg: "Your profile updated successfully",
        type: ToastType.success,
      );
      AutoRouter.of(context).popForced();
      return true;
    }, isError: (error) {
      return false;
    });
  }

  void showConfirmRemove(BuildContext context) {
    showDialog(
      context: context,
      builder: (cxt) {
        return BuildConfirmAlert(
          onTap: () => removeAccount(context),
        );
      },
    );
  }

  Future<bool> removeAccount(BuildContext context) async {
    var removeResponse = await getIt<BaseRepository>().removeAccount(true);
    return _handleRemoveResponse(removeResponse);
  }

  bool _handleRemoveResponse(MyResult<bool> response) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (value) {
      UserHelperService.instance.removeUserData();
      GlobalState.instance.set("token", null);
      AppSnackBar.showSimpleToast(
        color: context.colors.black,
        msg: "See you later",
        type: ToastType.success,
      );
      AutoRouter.of(context)
          .pushAndPopUntil(const SplashRoute(), predicate: (route) => true);
      return true;
    }, isError: (error) {
      return false;
    });
  }

  UpdatePasswordParams updatePasswordParams() {
    return UpdatePasswordParams(
      password: password.text,
      newPassword: newPassword.text,
      confirm: confirmPassword.text,
    );
  }

  bool _checkFormValidation() {
    return formKey.currentState!.validate();
  }
}
