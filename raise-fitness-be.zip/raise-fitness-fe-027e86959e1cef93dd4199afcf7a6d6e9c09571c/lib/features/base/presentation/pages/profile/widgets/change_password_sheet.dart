part of "profile_widgets_imports.dart";

class ChangePasswordSheet extends StatelessWidget {
  final ProfileController controller;
  const ChangePasswordSheet({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.6,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            color: context.colors.white,
            borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(30), topRight: Radius.circular(30))
                .r),
        child: Form(
          key: controller.formKey,
          child: Stack(
            alignment: FractionalOffset.topLeft,
            children: [
              ListView(
                padding: const EdgeInsets.all(24).r,
                children: [
                  Image.asset(
                    Res.logo,
                    height: 55,
                    width: 125,
                    color: context.colors.black,
                  ),
                  Gaps.vGap18,
                  Center(
                    child: Text(
                      "Change Password",
                      style: AppTextStyle.s18_w700(
                          color: context.colors.secondary),
                    ),
                  ),
                  Gaps.vGap24,
                  ObsValueConsumer(
                    observable: controller.visibleObs,
                    builder: (context, state) {
                      return GenericTextField(
                        radius: BorderRadius.circular(10.r),
                        controller: controller.password,
                        onTab: () => state,
                        enableBorderColor: context.colors.bgLight,
                        fillColor: context.colors.bgLight,
                        fieldTypes:
                            state ? FieldTypes.normal : FieldTypes.password,
                        type: TextInputType.text,
                        action: TextInputAction.done,
                        validate: (value) => value?.validateEmpty(),
                        hint: "Current Password",
                        contentPadding: const EdgeInsets.all(10),
                        textColor: context.colors.secondary,
                        hintColor: context.colors.primaryGrey,
                        margin: EdgeInsets.zero,
                        suffixIcon: InkWell(
                          onTap: () => controller.visibleObs.setValue(!state),
                          child: Icon(
                            state == true
                                ? Icons.visibility
                                : Icons.visibility_off_rounded,
                            size: 24.r,
                            color: context.colors.secondary,
                          ),
                        ),
                      );
                    },
                  ),
                  Gaps.vGap24,
                  ObsValueConsumer(
                    observable: controller.visibleNewObs,
                    builder: (context, state) {
                      return GenericTextField(
                        radius: BorderRadius.circular(10.r),
                        onTab: () => state,
                        enableBorderColor: context.colors.bgLight,
                        fillColor: context.colors.bgLight,
                        fieldTypes:
                            state ? FieldTypes.normal : FieldTypes.password,
                        type: TextInputType.text,
                        action: TextInputAction.done,
                        contentPadding: const EdgeInsets.all(10),
                        margin: EdgeInsets.zero,
                        suffixIcon: InkWell(
                          onTap: () =>
                              controller.visibleNewObs.setValue(!state),
                          child: Icon(
                            state == true
                                ? Icons.visibility
                                : Icons.visibility_off_rounded,
                            size: 24.r,
                            color: context.colors.secondary,
                          ),
                        ),
                        controller: controller.newPassword,
                        validate: (value) => value?.validateEmpty(),
                        hint: "New password",
                        hintColor: context.colors.primaryGrey,
                      );
                    },
                  ),
                  Gaps.vGap24,
                  ObsValueConsumer(
                    observable: controller.visibleConfirmPasObs,
                    builder: (context, state) {
                      return GenericTextField(
                        radius: BorderRadius.circular(10.r),
                        onTab: () => state,
                        enableBorderColor: context.colors.bgLight,
                        fillColor: context.colors.bgLight,
                        fieldTypes:
                            state ? FieldTypes.normal : FieldTypes.password,
                        type: TextInputType.text,
                        action: TextInputAction.done,
                        contentPadding: const EdgeInsets.all(10),
                        margin: EdgeInsets.zero,
                        suffixIcon: InkWell(
                          onTap: () =>
                              controller.visibleConfirmPasObs.setValue(!state),
                          child: Icon(
                            state == true
                                ? Icons.visibility
                                : Icons.visibility_off_rounded,
                            size: 24.r,
                            color: context.colors.secondary,
                          ),
                        ),
                        controller: controller.confirmPassword,
                        validate: (value) => value?.validatePasswordConfirm(
                            pass: controller.newPassword.text),
                        hint: "Confirm password",
                        hintColor: context.colors.primaryGrey,
                      );
                    },
                  ),
                  Gaps.vGap32,
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20).r,
                    child: AppTextButton.maxCustom(
                      bgColor: context.colors.secondary,
                      onPressed: () =>
                          controller.onSubmitUpdatePassword(context),
                      txtColor: context.colors.primary,
                      textSize: 18,
                      maxHeight: 50,
                      borderRadius: 50,
                      text: "Change Password",
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
