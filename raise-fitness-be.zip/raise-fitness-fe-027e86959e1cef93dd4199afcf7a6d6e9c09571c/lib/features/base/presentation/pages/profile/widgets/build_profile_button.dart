part of "profile_widgets_imports.dart";

class BuildProfileButton extends StatelessWidget {
  final String icon, title;
  final VoidCallback onTap;
  const BuildProfileButton({super.key, required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 75.h,
        padding: const EdgeInsets.symmetric(horizontal: 20).r,
        decoration: BoxDecoration(
          color: context.colors.bgLight,
          borderRadius: BorderRadius.circular(10).r,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SvgPicture.asset(
              icon,
              height: 25.h,
              width: 25.w,
            ),
            Gaps.hGap14,
            Text(
              title,
              style: AppTextStyle.s16_w500(
                color: context.colors.black,
              ),
            ),
            const Spacer(),
            SvgPicture.asset(
              Res.forward,
              height: 20.h,
              width: 20.w,
            ),
          ],
        ),
      ),
    );
  }
}
