part of "profile_widgets_imports.dart";

class BuildProfileData extends StatelessWidget {
  final UserInfoModel user;
  const BuildProfileData({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        user.avatar == null
            ? Image.asset(
                Res.avatarSolidLogo,
                width: 100.h,
                height: 100.w,
                fit: BoxFit.fill,
              )
            : Container(
                width: 100.h,
                height: 100.w,
                clipBehavior: Clip.antiAliasWithSaveLayer,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: CachedImage(
                    url: user.avatar ?? "",
                    width: 100.h,
                    height: 100.w,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
        Gaps.vGap24,
        Text(
          "${user.firstname ?? ""} ${user.lastname??""}",
          style: AppTextStyle.s16_w500(
            color: context.colors.noticesTextColor,
          ),
        ),
        Gaps.vGap8,
        Text(
          user.email ?? "",
          style: AppTextStyle.s14_w400(
            color: context.colors.blackOpacity,
          ),
        ),
      ],
    );
  }
}
