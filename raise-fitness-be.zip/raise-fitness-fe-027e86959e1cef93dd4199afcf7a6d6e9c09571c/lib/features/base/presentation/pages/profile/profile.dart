part of "profile_imports.dart";

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final ProfileController controller = ProfileController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: const BaseAppBar(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.85,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(24).r,
            decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(50)).r,
            ),
            child: SingleChildScrollView(
              child: RequesterConsumer(
                requester: controller.requester,
                successBuilder: (context, data) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      BuildProfileData(user: data),
                      Gaps.vGap32,
                      BuildProfileButton(
                        icon: Res.myPackages,
                        title: "My Packages",
                        onTap: () => AutoRouter.of(context)
                            .push(const MyPackagesRoute()),
                      ),
                      Gaps.vGap20,
                      BuildProfileButton(
                          icon: Res.password,
                          title: "Change Password",
                          onTap: () => controller.passwordSheet(context)),
                      Gaps.vGap20,
                      BuildProfileButton(
                          icon: Res.alarm,
                          title: "Bookings",
                          onTap: () => AutoRouter.of(context)
                              .push(const JourneyRoute())),
                      Gaps.vGap50,
                      BuildLogoutButton(
                        controller: controller,
                      ),
                    ],
                  );
                },
                loadingBuilder: (context) {
                  return BaseShimmerWidget(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        CircleShimmer(radius: 100.r),
                        Gaps.vGap24,
                        Gaps.vGap32,
                        BuildProfileButton(
                          icon: Res.myPackages,
                          title: "My Packages",
                          onTap: () => AutoRouter.of(context)
                              .push(const MyPackagesRoute()),
                        ),
                        Gaps.vGap20,
                        BuildProfileButton(
                            icon: Res.password,
                            title: "Change Passowrd",
                            onTap: () => controller.passwordSheet(context)),
                        Gaps.vGap20,
                        BuildProfileButton(
                            icon: Res.alarm,
                            title: "Bookings",
                            onTap: () => AutoRouter.of(context)
                                .push(const JourneyRoute())),
                        Gaps.vGap50,
                        BuildLogoutButton(
                          controller: controller,
                        ),
                      ],
                    ),
                  );
                },
                failureBuilder: (context, error, callback) {
                  return FailureViewWidget(onTap: callback);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
