part of "profile_widgets_imports.dart";

class BuildLogoutButton extends StatelessWidget {
  final ProfileController controller;
  const BuildLogoutButton({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // AppTextButton.maxCustom(
        //   onPressed: () => controller.logout(context),
        //   bgColor: context.colors.black,
        //   txtColor: context.colors.primary,
        //   textSize: 18,
        //   maxHeight: 55,
        //   borderRadius: 50,
        //   text: "Logout",
        // ),
        Gaps.vGap32,
        InkWell(
          onTap: () => controller.showConfirmRemove(context),
          child: Text(
            "Delete My Account",
            style: AppTextStyle.s16_w500(color: context.colors.red),
          ),
        ),
        Gaps.vGap64,
      ],
    );
  }
}
