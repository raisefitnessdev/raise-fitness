part of "edit_profile_widgets_imports.dart";

class EditProfileButton extends StatelessWidget {
  final EditProfileController controller;
  const EditProfileButton({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AppTextButton.maxCustom(
          onPressed: () => controller.editProfile(),
          bgColor: context.colors.black,
          txtColor: context.colors.primary,
          textSize: 18,
          maxHeight: 50,
          borderRadius: 50,
          text: "Save",
        );
  }
}