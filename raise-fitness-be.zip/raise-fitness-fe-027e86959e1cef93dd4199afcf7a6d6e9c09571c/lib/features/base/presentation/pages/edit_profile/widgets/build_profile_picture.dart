part of "edit_profile_widgets_imports.dart";

class BuildProfilePicture extends StatelessWidget {
  final EditProfileController controller;
  final UserInfoModel user;
  const BuildProfilePicture(
      {super.key, required this.controller, required this.user});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 50).r,
      child: InkWell(
        onTap: () => controller.getImage(context),
        child: Center(
          child: Stack(
            alignment: FractionalOffset.bottomRight,
            children: [
              Container(
                width: 100.h,
                height: 100.w,
                margin: const EdgeInsets.only(bottom: 8).r,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: ObsValueConsumer<File?>(
                      observable: controller.imageCubit,
                      builder: (context, value) {
                        if (value != null) {
                          return Container(
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  image: FileImage(File(value.path)),
                                  fit: BoxFit.cover,
                                )),
                          );
                        } else {
                          return user.avatar == null
                              ? Image.asset(
                                  Res.avatarSolidLogo,
                                  width: 100.h,
                                  height: 100.w,
                                  fit: BoxFit.fill,
                                )
                              : Container(
                                  width: 100.h,
                                  height: 100.w,
                                  clipBehavior: Clip.antiAliasWithSaveLayer,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                  ),
                                  child: Center(
                                    child: CachedImage(
                                      url: user.avatar ?? "",
                                      width: 100.h,
                                      height: 100.w,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                );
                        }
                      }),
                ),
              ),
              Container(
                  height: 30.h,
                  width: 30.w,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8).r,
                      color: context.colors.secondary),
                  child: Center(
                      child: Icon(
                    CupertinoIcons.camera_fill,
                    size: 20.r,
                    color: context.colors.primary,
                  ))),
            ],
          ),
        ),
      ),
    );
  }
}
