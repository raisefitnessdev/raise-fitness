import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:raise/core/bloc/value_state_manager/value_state_manager_import.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/helpers/validator.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/CachedImage.dart';
import 'package:raise/core/widgets/GenericTextField.dart';
import 'package:raise/core/widgets/app_button.dart';
import 'package:raise/core/widgets/build_country_code.dart';
import 'package:raise/features/auth/data/models/user_info_model/user_info_model.dart';
import 'package:raise/features/base/presentation/pages/edit_profile/edit_profile_imports.dart';
import 'package:raise/res.dart';

part "build_profile_picture.dart";
part "edit_profile_form.dart";
part "edit_profile_button.dart";
