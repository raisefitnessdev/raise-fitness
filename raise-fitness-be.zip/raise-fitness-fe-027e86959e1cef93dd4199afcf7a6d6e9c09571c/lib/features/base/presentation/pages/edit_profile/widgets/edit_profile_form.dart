part of "edit_profile_widgets_imports.dart";

class EditProfileForm extends StatelessWidget {
  final EditProfileController controller;
  const EditProfileForm({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.formKey,
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: GenericTextField(
                  radius: BorderRadius.circular(8).r,
                  controller: controller.firstname,
                  enableBorderColor: context.colors.bgLight,
                  fillColor: context.colors.bgLight,
                  contentPadding: const EdgeInsets.all(10),
                  fieldTypes: FieldTypes.normal,
                  type: TextInputType.text,
                  action: TextInputAction.next,
                  validate: (value) => value?.validateEmpty(),
                  hint: "First name",
                  hintColor: context.colors.primaryGrey,
                  textColor: context.colors.black,
                  margin: const EdgeInsets.only(top: 32).r,
                ),
              ),
              Gaps.hGap16,
              Expanded(
                child: GenericTextField(
                  radius: BorderRadius.circular(8).r,
                  controller: controller.lastname,
                  enableBorderColor: context.colors.bgLight,
                  fillColor: context.colors.bgLight,
                  contentPadding: const EdgeInsets.all(10),
                  fieldTypes: FieldTypes.normal,
                  type: TextInputType.text,
                  action: TextInputAction.next,
                  validate: (value) => value?.validateEmpty(),
                  hint: "Last name",
                  hintColor: context.colors.primaryGrey,
                  textColor: context.colors.black,
                  margin: const EdgeInsets.only(top: 32).r,
                ),
              ),
            ],
          ),
          GenericTextField(
            radius: BorderRadius.circular(8).r,
            controller: controller.email,
            enableBorderColor: context.colors.bgLight,
            fillColor: context.colors.bgLight,
            contentPadding: const EdgeInsets.all(10),
            fieldTypes: FieldTypes.normal,
            type: TextInputType.emailAddress,
            action: TextInputAction.next,
            validate: (value) => value?.validateEmail(),
            hint: "Email",
            hintColor: context.colors.primaryGrey,
            textColor: context.colors.black,
            margin: const EdgeInsets.only(top: 24).r,
          ),
          GenericTextField(
            onTab: () => controller.showDateAlert(context),
            radius: BorderRadius.circular(8).r,
            controller: controller.birthdate,
            enableBorderColor: context.colors.bgLight,
            fillColor: context.colors.bgLight,
            contentPadding: const EdgeInsets.all(10),
            fieldTypes: FieldTypes.clickable,
            type: TextInputType.text,
            action: TextInputAction.next,
            validate: (value) => value?.validateEmpty(),
            hint: "Date of birth",
            hintColor: context.colors.primaryGrey,
            textColor: context.colors.black,
            margin: const EdgeInsets.only(top: 24).r,
            suffixIcon: InkWell(
              onTap: () {},
              child: Icon(
                Icons.calendar_month,
                size: 20,
                color: context.colors.black,
              ),
            ),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 60.h,
                margin: const EdgeInsets.only(top: 24).r,
                decoration: BoxDecoration(
                  color: context.colors.bgLight,
                  borderRadius: BorderRadius.circular(8).r,
                ),
                child: Center(
                  child: BuildCountryCode(
                    color: context.colors.secondary,
                    bloc: controller.countryObs,
                    onTap: (){}, 
                    // => controller.showCountryDialog(context),
                  ),
                ),
              ),
              Gaps.hGap4,
              Expanded(
                child: GenericTextField(
                  radius: BorderRadius.circular(8).r,
                  controller: controller.phone,
                  enableBorderColor: context.colors.bgLight,
                  fillColor: context.colors.bgLight,
                  contentPadding: const EdgeInsets.all(10),
                  fieldTypes: FieldTypes.normal,
                  type: TextInputType.phone,
                  action: TextInputAction.next,
                  validate: (value) => value?.validateEmpty(),
                  hint: "Phone",
                  hintColor: context.colors.primaryGrey,
                  textColor: context.colors.black,
                  margin: const EdgeInsets.only(top: 24).r,
                  // prefixIcon: ,
                ),
              ),
            ],
          ),
          Gaps.vGap24,
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "Your gender",
              style:
                  AppTextStyle.s14_w600(color: context.colors.noticesTextColor),
            ),
          ),
          Gaps.vGap10,
          ObsValueConsumer(
              observable: controller.gendrObs,
              builder: (context, state) {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Radio(
                      fillColor: WidgetStateProperty.resolveWith<Color>(
                          (Set<WidgetState> states) {
                        return context.colors.black;
                      }),
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      visualDensity:
                          const VisualDensity(horizontal: -4, vertical: -4),
                      activeColor: context.colors.black,
                      value: true,
                      groupValue: state,
                      onChanged: (v) {
                        controller.gendrObs.setValue(v!);
                      },
                    ),
                    Gaps.hGap8,
                    Text(
                      "Male",
                      style: AppTextStyle.s15_w500(
                          color: context.colors.black),
                    ),
                    Gaps.hGap22,
                    Radio(
                      fillColor: WidgetStateProperty.resolveWith<Color>(
                          (Set<WidgetState> states) {
                        return context.colors.black;
                      }),
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      visualDensity:
                          const VisualDensity(horizontal: -4, vertical: -4),
                      activeColor: context.colors.black,
                      value: false,
                      groupValue: state,
                      onChanged: (v) {
                        controller.gendrObs.setValue(v!);
                      },
                    ),
                    Gaps.hGap8,
                    Text(
                      "Female",
                      style: AppTextStyle.s15_w500(
                          color: context.colors.black),
                    ),
                  ],
                );
              }),
        ],
      ),
    );
  }
}
