part of "edit_profile_imports.dart";

@RoutePage(name: "EditProfileRoute")
class EditProfile extends StatefulWidget {
  final UserInfoModel user;
  const EditProfile({super.key, required this.user});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  late EditProfileController controller;

  @override
  void initState() {
    controller = EditProfileController(widget.user);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: const DefaultAppBar(
        title: "Edit Profile",
        showBack: true,
        actions: [
          NotificationWidget(),
        ],
      ),
      bottomNavigationBar: const PresistBottomBar(),
      body: Container(
        height: MediaQuery.of(context).size.height * 0.85,
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.all(24).r,
        decoration: BoxDecoration(
          color: context.colors.white,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(50)).r,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              BuildProfilePicture(user: widget.user, controller: controller),
              Gaps.vGap32,
              EditProfileForm(controller: controller),
              Gaps.vGap64,
              EditProfileButton(controller: controller),
              Gaps.vGap64,
            ],
          ),
        ),
      ),
    );
  }
}
