part of "edit_profile_imports.dart";

class EditProfileController {
  EditProfileController(UserInfoModel user) {
    initProfileData(user);
  }

  final GlobalKey<FormState> formKey = GlobalKey();

  final ObsValue<File?> imageCubit = ObsValue.withInit(null);
  ObsValue<bool> gendrObs = ObsValue.withInit(true);

  TextEditingController firstname = TextEditingController();
  TextEditingController lastname = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController birthdate = TextEditingController();

  final ObsValue<Country?> countryObs = ObsValue.withInit(Country(
      phoneCode: "974",
      countryCode: "QA",
      e164Sc: 0,
      geographic: true,
      level: 1,
      name: "Qatar",
      example: "412345678",
      displayName: "Qatar (QA) [+974]",
      displayNameNoCountryCode: "Qatar (QA)",
      e164Key: "974-QA-0"));

  void initProfileData(UserInfoModel user) {
    email = TextEditingController(text: user.email);
    firstname = TextEditingController(text: user.firstname);
    lastname = TextEditingController(text: user.lastname);
    phone = TextEditingController(text: user.phone);
    birthdate = TextEditingController(text: user.birthday);
    gendrObs.setValue(user.gender == "male" ? true : false);
  }

  Future<void> getImage(BuildContext context) async {
    var image =
        await AppFileService().pickImagesFiles(context, allowMulti: false);
    if (image != null) {
      imageCubit.setValue(image.first);
    }
  }

  void showCountryDialog(BuildContext context) async {
    showCountryPicker(
      context: context,
      showPhoneCode: true,
      showWorldWide: false,
      fontFamily: AppTheme.fontFamily,
      favorite: ['+974', 'QA'],
      countryListTheme: CountryListThemeData(
        backgroundColor: context.colors.background,
        textStyle: AppTextStyle.s16_w400(color: context.colors.textColor),
      ),
      buildSearch: (onSearch) {
        return SearchFormField(
          onChange: onSearch,
          onSubmit: onSearch,
        );
      },
      onSelect: (Country country) {
        // codeCubit.onUpdateData("+${country.phoneCode}");
        countryObs.setValue(country);
      },
    );
  }

  void showDateAlert(BuildContext context) async {
    AdaptivePicker.datePicker(
      minDate: DateTime(DateTime.now().year - 120),
      context: context,
      onConfirm: (value) => handleDate(value),
      title: '',
    );
  }

  void handleDate(DateTime? value) {
    birthdate.text = DateFormat("yyyy-MM-dd", "en").format(value!);
  }

  Future<bool> editProfile() async {
    if (_checkFormValidation()) {
      ProfileParams params = profileParams();
      var profileResponse = await getIt<BaseRepository>().editProfile(params);
      return _handleProfileResponse(profileResponse);
    } else {
      return false;
    }
  }

  bool _handleProfileResponse(MyResult<UserInfoModel> response) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (userModel) {
      AppSnackBar.showSimpleToast(
        color: context.colors.black,
        msg: "Your profile updated successfully",
        type: ToastType.success,
      );
      AutoRouter.of(context).push(Dashboard(index: 3));
      return true;
    }, isError: (error) {
      return false;
    });
  }

  ProfileParams profileParams() {
    return ProfileParams(
      firstname: firstname.text,
      lastname: lastname.text,
      phone: countryObs.getValue()!.phoneCode + phone.text,
      email: email.text,
      avatar: imageCubit.getValue(),
      birthday: birthdate.text,
      gender: gendrObs.getValue() ? "male" : "female",
    );
  }

  bool _checkFormValidation() {
    return formKey.currentState!.validate();
  }
}
