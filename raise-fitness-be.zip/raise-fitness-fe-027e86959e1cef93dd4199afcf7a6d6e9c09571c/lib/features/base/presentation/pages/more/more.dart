part of "more_imports.dart";

class More extends StatefulWidget {
  const More({super.key});

  @override
  State<More> createState() => _MoreState();
}

class _MoreState extends State<More> {
  final MoreController controller = MoreController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: const BaseAppBar(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.85,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(24).r,
            decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(50)).r,
            ),
            child: SingleChildScrollView(
              child: RequesterConsumer(
                requester: controller.requester,
                successBuilder: (context, data) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      BuildProfileButton(
                          icon: Res.editProfile,
                          title: "Edit Profile",
                          onTap: () => AutoRouter.of(context)
                              .push(EditProfileRoute(user: data))),
                      // Gaps.vGap20,
                      // BuildProfileButton(
                      //   icon: Res.about,
                      //   title: "About us",
                      //   onTap: () => AutoRouter.of(context).push(SettingsRoute(
                      //       page: data
                      //           .firstWhere((item) => item.key == "about"))),
                      // ),
                      Gaps.vGap20,
                      BuildProfileButton(
                          icon: Res.contact,
                          title: "Support",
                          onTap: () => AutoRouter.of(context)
                              .push(const ContactUsRoute())),
                      // Gaps.vGap20,
                      // BuildProfileButton(
                      //     icon: Res.faq,
                      //     title: "FAQ",
                      //     onTap: () =>
                      //         AutoRouter.of(context).push(const FAQRoute())),
                      Gaps.vGap20,
                      BuildProfileButton(
                        icon: Res.myPackages,
                        title: "Terms & Conditions",
                        onTap: () =>
                            AutoRouter.of(context).push(const SettingsRoute()),
                      ),
                      // Gaps.vGap20,
                      // BuildProfileButton(
                      //     icon: Res.share,
                      //     title: "Share App",
                      //     onTap: () => getIt<ShareServices>().shareApp()),
                      Gaps.vGap64,
                      AppTextButton.maxCustom(
                        onPressed: () => controller.logout(context),
                        bgColor: context.colors.black,
                        txtColor: context.colors.primary,
                        textSize: 18,
                        maxHeight: 55,
                        borderRadius: 50,
                        text: "Logout",
                      ),
                      Gaps.vGap64,
                    ],
                  );
                },
                loadingBuilder: (context) {
                  return BaseShimmerWidget(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        BuildProfileButton(
                            icon: Res.editProfile,
                            title: "Edit Profile",
                            onTap: () {}),
                        // Gaps.vGap20,
                        // BuildProfileButton(
                        //   icon: Res.about,
                        //   title: "About us",
                        //   onTap: () {},
                        // ),
                        Gaps.vGap20,
                        BuildProfileButton(
                            icon: Res.contact,
                            title: "Support",
                            onTap: () => AutoRouter.of(context)
                                .push(const ContactUsRoute())),
                        // Gaps.vGap20,
                        // BuildProfileButton(
                        //     icon: Res.faq,
                        //     title: "FAQ",
                        //     onTap: () =>
                        //         AutoRouter.of(context).push(const FAQRoute())),
                        Gaps.vGap20,
                        BuildProfileButton(
                            icon: Res.myPackages,
                            title: "Terms & Conditions",
                            onTap: () {}),
                        // Gaps.vGap20,
                        // BuildProfileButton(
                        //     icon: Res.share,
                        //     title: "Share App",
                        //     onTap: () => getIt<ShareServices>().shareApp()),
                        Gaps.vGap64,
                      ],
                    ),
                  );
                },
                failureBuilder: (context, error, callback) {
                  return FailureViewWidget(onTap: callback);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
