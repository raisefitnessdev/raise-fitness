part of "more_imports.dart";

class MoreController {
  MoreController() {
    requestProfile();
  }

  ProfileRequester requester = ProfileRequester();

  Future<void> requestProfile() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }

  Future<void> logout(BuildContext context) async {
    UserHelperService.instance.removeUserData();
    GlobalState.instance.set("token", null);
    AppSnackBar.showSimpleToast(
      color: context.colors.black,
      msg: "See you later",
      type: ToastType.success,
    );
    AutoRouter.of(context)
        .pushAndPopUntil(const SplashRoute(), predicate: (route) => true);
  }
}