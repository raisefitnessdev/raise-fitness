part of "contact_us_widgets_imports.dart";

class ContactUsButton extends StatelessWidget {
  final ContactUsController controller;
  const ContactUsButton({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AppTextButton.maxCustom(
          onPressed: () => controller.contactUs(),
          bgColor: context.colors.black,
          txtColor: context.colors.primary,
          textSize: 18,
          maxHeight: 50,
          borderRadius: 50,
          text: "Send",
        );
  }
}