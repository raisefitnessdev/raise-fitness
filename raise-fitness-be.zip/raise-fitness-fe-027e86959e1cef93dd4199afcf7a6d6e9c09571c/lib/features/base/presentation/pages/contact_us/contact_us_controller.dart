part of "contact_us_imports.dart";

class ContactUsController {
  final GlobalKey<FormState> formKey = GlobalKey();

  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController message = TextEditingController();

  final ObsValue<Country?> countryObs = ObsValue.withInit(Country(
      phoneCode: "974",
      countryCode: "QA",
      e164Sc: 0,
      geographic: true,
      level: 1,
      name: "Qatar",
      example: "412345678",
      displayName: "Qatar (QA) [+974]",
      displayNameNoCountryCode: "Qatar (QA)",
      e164Key: "974-QA-0"));

  void showCountryDialog(BuildContext context) async {
    showCountryPicker(
      context: context,
      showPhoneCode: true,
      showWorldWide: false,
      fontFamily: AppTheme.fontFamily,
      favorite: ['+974', 'QA'],
      countryListTheme: CountryListThemeData(
        backgroundColor: context.colors.background,
        textStyle: AppTextStyle.s16_w400(color: context.colors.textColor),
      ),
      buildSearch: (onSearch) {
        return SearchFormField(
          onChange: onSearch,
          onSubmit: onSearch,
        );
      },
      onSelect: (Country country) {
        // codeCubit.onUpdateData("+${country.phoneCode}");
        countryObs.setValue(country);
      },
    );
  }

  Future<bool> contactUs() async {
    if (_checkFormValidation()) {
      ContactUsParams params = contactUsParams();
      var contactResponse = await getIt<BaseRepository>().contactUs(params);
      return _handleContactResponse(contactResponse);
    } else {
      return false;
    }
  }

  bool _handleContactResponse(MyResult<bool> response) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (userModel) {
      AppSnackBar.showSimpleToast(
        color: context.colors.black,
        msg: "Your message sent successfully",
        type: ToastType.success,
      );
      AutoRouter.of(context).push(Dashboard(index: 3));
      return true;
    }, isError: (error) {
      return false;
    });
  }

  ContactUsParams contactUsParams() {
    return ContactUsParams(
      name: name.text,
      phone: countryObs.getValue()!.phoneCode + phone.text,
      email: email.text,
      message: message.text,
    );
  }

  bool _checkFormValidation() {
    return formKey.currentState!.validate();
  }
}
