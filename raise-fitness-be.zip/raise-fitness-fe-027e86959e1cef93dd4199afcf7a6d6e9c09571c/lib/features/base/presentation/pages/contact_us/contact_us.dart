part of "contact_us_imports.dart";

@RoutePage(name: "ContactUsRoute")
class ContactUs extends StatefulWidget {
  const ContactUs({super.key});

  @override
  State<ContactUs> createState() => _ContactUsState();
}

class _ContactUsState extends State<ContactUs> {
  ContactUsController controller = ContactUsController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: const DefaultAppBar(
        title: "Support",
        showBack: true,
        actions: [
          NotificationWidget(),
        ],
      ),
      bottomNavigationBar: const PresistBottomBar(),
      body: Container(
        height: MediaQuery.of(context).size.height * 0.85,
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.all(24).r,
        decoration: BoxDecoration(
          color: context.colors.white,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(50)).r,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Gaps.vGap64,
              Text(
                "Contact",
                style: AppTextStyle.s14_w800(color: context.colors.secondary),
              ),
              Gaps.vGap32,
              BuildSupportButton(onTap: ()=>ShareServices().launchWhatsApp("97466518844", context), icon: Res.whatsapp, title: "+97466518844"),
              Gaps.vGap16,
              BuildSupportButton(onTap: ()=>ShareServices().callPhone(phone: "97466518844"), icon: Res.call, title: "+97466518844"),
              Gaps.vGap16,
              BuildSupportButton(onTap: ()=>ShareServices().sendEmail(email: "Info@raisefitness.qa"), icon: Res.email, title: "Info@raisefitness.qa"),
              Gaps.vGap16,
              BuildSupportButton(onTap: ()=>ShareServices().launchURL(url: "https://www.instagram.com/rumble_qatar?igsh=MXd4aGJycmdlcGZweA=="), icon: Res.instagram, title: "Rumble_qatar"),
             
              // ContactUsForm(controller: controller),
              // Gaps.vGap64,
              // ContactUsButton(controller: controller),
              Gaps.vGap64,
            ],
          ),
        ),
      ),
    );
  }
}
