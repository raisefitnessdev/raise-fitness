part of "contact_us_widgets_imports.dart";

class ContactUsForm extends StatelessWidget {
  final ContactUsController controller;
  const ContactUsForm({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.formKey,
      child: Column(
        children: [
          GenericTextField(
            radius: BorderRadius.circular(8).r,
            controller: controller.name,
            enableBorderColor: context.colors.bgLight,
            fillColor: context.colors.bgLight,
            contentPadding: const EdgeInsets.all(10),
            fieldTypes: FieldTypes.normal,
            type: TextInputType.text,
            action: TextInputAction.next,
            validate: (value) => value?.validateEmpty(),
            hint: "Name",
            hintColor: context.colors.primaryGrey,
            textColor: context.colors.black,
            margin: const EdgeInsets.only(top: 32).r,
          ),
          GenericTextField(
            radius: BorderRadius.circular(8).r,
            controller: controller.email,
            enableBorderColor: context.colors.bgLight,
            fillColor: context.colors.bgLight,
            contentPadding: const EdgeInsets.all(10),
            fieldTypes: FieldTypes.normal,
            type: TextInputType.emailAddress,
            action: TextInputAction.next,
            validate: (value) => value?.validateEmail(),
            hint: "Email",
            hintColor: context.colors.primaryGrey,
            textColor: context.colors.black,
            margin: const EdgeInsets.only(top: 24).r,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 60.h,
                margin: const EdgeInsets.only(top: 24).r,
                decoration: BoxDecoration(
                  color: context.colors.bgLight,
                  borderRadius: BorderRadius.circular(8).r,
                ),
                child: Center(
                  child: BuildCountryCode(
                    color: context.colors.secondary,
                    bloc: controller.countryObs,
                    onTap: () => controller.showCountryDialog(context),
                  ),
                ),
              ),
              Gaps.hGap4,
              Expanded(
                child: GenericTextField(
                  radius: BorderRadius.circular(8).r,
                  controller: controller.phone,
                  enableBorderColor: context.colors.bgLight,
                  fillColor: context.colors.bgLight,
                  contentPadding: const EdgeInsets.all(10),
                  fieldTypes: FieldTypes.normal,
                  type: TextInputType.phone,
                  action: TextInputAction.next,
                  validate: (value) => value?.validateEmpty(),
                  hint: "Phone",
                  hintColor: context.colors.primaryGrey,
                  textColor: context.colors.black,
                  margin: const EdgeInsets.only(top: 24).r,
                  // prefixIcon: ,
                ),
              ),
              
            ],
          ),
          GenericTextField(
                radius: BorderRadius.circular(8).r,
                controller: controller.message,
                enableBorderColor: context.colors.bgLight,
                fillColor: context.colors.bgLight,
                contentPadding: const EdgeInsets.all(10),
                max: 5,
                fieldTypes: FieldTypes.rich,
                type: TextInputType.multiline,
                action: TextInputAction.newline,
                validate: (value) => value?.validateEmpty(),
                hint: "Message",
                hintColor: context.colors.primaryGrey,
                textColor: context.colors.black,
                margin: const EdgeInsets.only(top: 24).r,
              ),
        ],
      ),
    );
  }
}
