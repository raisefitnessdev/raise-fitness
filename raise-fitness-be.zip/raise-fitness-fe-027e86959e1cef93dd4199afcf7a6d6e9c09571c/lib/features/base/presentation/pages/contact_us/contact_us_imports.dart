import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/bloc/value_state_manager/value_state_manager_import.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/flutter-country-picker/lib/country_picker.dart';
import 'package:raise/core/helpers/app_snack_bar_service.dart';
import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/helpers/global_context.dart';
import 'package:raise/core/helpers/share_services.dart';
import 'package:raise/core/http/models/result.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/theme/themes/app_theme.dart';
import 'package:raise/core/widgets/default_app_bar.dart';
import 'package:raise/core/widgets/presist_bottom_bar/presist_bottom_bar_imports.dart';
import 'package:raise/core/widgets/search_form_field/search_form_field.dart';
import 'package:raise/features/base/domain/entity/contact_us_params.dart';
import 'package:raise/features/base/domain/repositories/base_repository.dart';
import 'package:raise/features/base/presentation/widgets/notification_widget/notification_widget_imports.dart';
import 'package:raise/res.dart';

import 'widgets/contact_us_widgets_imports.dart';

part "contact_us.dart";
part "contact_us_controller.dart";
