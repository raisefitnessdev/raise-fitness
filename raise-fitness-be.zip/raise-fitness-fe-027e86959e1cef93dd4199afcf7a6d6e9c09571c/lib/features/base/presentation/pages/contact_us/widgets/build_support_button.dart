part of "contact_us_widgets_imports.dart";

class BuildSupportButton extends StatelessWidget {
  final VoidCallback onTap;
  final String title, icon;
  const BuildSupportButton(
      {super.key,
      required this.onTap,
      required this.icon,
      required this.title});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(icon,
              height: 25.h,
              width: 25.w,
              fit: BoxFit.contain,
              color: context.colors.secondary),
          Gaps.hGap4,
          Text(
            title,
            style: AppTextStyle.s12_w700(color: context.colors.secondary),
          ),
        ],
      ),
    );
  }
}
