part of "online_payment_imports.dart";

class OnlinePaymentController {
  late MFCardPaymentView mfCardView;

  MFCardViewStyle cardViewStyle() {
    MFCardViewStyle cardViewStyle = MFCardViewStyle();
    cardViewStyle.cardHeight = 300;
    cardViewStyle.input?.inputHeight = 40;
    cardViewStyle.hideCardIcons = false;
    cardViewStyle.input?.inputMargin = 5;
    cardViewStyle.label?.display = true;
    cardViewStyle.input?.fontFamily = MFFontFamily.Monaco;
    cardViewStyle.label?.fontWeight = MFFontWeight.Heavy;
    return cardViewStyle;
  }

  void initiate({required String amount, required int orderId}) async {
    mfCardView = MFCardPaymentView(cardViewStyle: cardViewStyle());
    await MFSDK.init(ApiNames.apiKey, MFCountry.QATAR, MFEnvironment.LIVE);

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await initiatePayment(amount: amount);
      await initiateSession();
    });
  }

  Future initiatePayment({required String amount}) async {
    MFInitiatePaymentRequest request = MFInitiatePaymentRequest(
        invoiceAmount: double.parse(amount),
        currencyIso: MFCurrencyISO.QATAR_QAR);
    await MFSDK
        .initiatePayment(request, MFLanguage.ARABIC)
        .then((value) => debugPrint(value.toString()))
        .catchError((error) =>
            {debugPrint("error payment: ${error.message}/${error.code}")});
  }

  Future initiateSession() async {
    MFInitiateSessionRequest initiateSessionRequest =
        MFInitiateSessionRequest();

    await MFSDK
        .initSession(initiateSessionRequest, MFLanguage.ARABIC)
        .then((value) => loadEmbeddedPayment(value))
        .catchError((error) =>
            {debugPrint("error session: ${error.message}/${error.code}")});
  }

  void loadEmbeddedPayment(MFInitiateSessionResponse session) {
    loadCardView(session);
  }

  void loadCardView(MFInitiateSessionResponse session) {
    mfCardView.load(session, (bin) {
      debugPrint(bin);
    });
  }

  void pay({required int orderId, required String amount}) async {
    var executePaymentRequest = MFExecutePaymentRequest(
        invoiceValue: double.parse(amount),
        displayCurrencyIso: MFCurrencyISO.QATAR_QAR);
    // executePaymentRequest.sessionId = sessionId;

    await mfCardView.pay(executePaymentRequest, MFLanguage.ARABIC, (invoiceId) {
      debugPrint(invoiceId);
    }).then((value) {
      debugPrint("start activate");
      activatePackage(
        orderId: orderId,
      );
    }).catchError((error) {
      debugPrint("error: ${error.code}/${error.message}");
      AppSnackBar.showSimpleToast(
        msg: error.message.toString(),
        type: ToastType.error,
      );
      return false;
    });
  }

  Future<bool> activatePackage({required int orderId}) async {
    var codeResponse = await getIt<BaseRepository>().activatePackage(orderId);
    return _handlePayResponse(codeResponse);
  }

  bool _handlePayResponse(MyResult<String> response) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (data) {
      showSuccessPackage(context);
      return true;
    }, isError: (error) {
      return false;
    });
  }

  void showSuccessPackage(BuildContext context) {
    showDialog(
      context: context,
      builder: (cxt) {
        return BuildSuccessAlert(
          onTap: () => AutoRouter.of(context).push(const MyPackagesRoute()),
          isClass: false,
        );
      },
    );
  }
}
