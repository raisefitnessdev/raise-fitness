import 'package:auto_route/auto_route.dart';
import 'package:raise/core/bloc/value_state_manager/value_state_manager_import.dart';
import 'package:raise/core/helpers/app_snack_bar_service.dart';
import 'package:raise/core/helpers/loading_helper.dart';
import 'package:raise/core/http/models/result.dart';
import 'package:raise/core/localization/translate.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/widgets/app_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:myfatoorah_flutter/myfatoorah_flutter.dart';
import 'package:raise/features/base/domain/repositories/base_repository.dart';
import 'package:raise/features/base/presentation/widgets/build_success_alert.dart';

import '../../../../../core/helpers/di.dart';
import '../../../../../core/helpers/global_context.dart';
import '../../../../../core/http/generic_http/api_names.dart';
import '../../../../../core/widgets/default_app_bar.dart';

part "online_payment.dart";
part "online_payment_controller.dart";