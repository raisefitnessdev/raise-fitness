part of "online_payment_imports.dart";

@RoutePage(name: "OnlinePaymentRoute")
class OnlinePayment extends StatefulWidget {
  final String amount;
  final int packageId;
  const OnlinePayment({super.key, required this.amount, required this.packageId});

  @override
  State<OnlinePayment> createState() => _OnlinePaymentState();
}

class _OnlinePaymentState extends State<OnlinePayment> {
  OnlinePaymentController controller = OnlinePaymentController();

  @override
  void initState() {
    super.initState();
    controller.initiate(amount: widget.amount, orderId: widget.packageId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      backgroundColor: context.colors.white,
      appBar: const DefaultAppBar(
        title: "Online Payment",
        showBack: true,
      ),
      body: ListView(
        children: [
          LimitedBox(
            maxHeight: 300,
            child: controller.mfCardView,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 40).r,
            child: AppTextButton.maxCustom(
          onPressed: () => controller.pay(amount: widget.amount, orderId: widget.packageId),
          bgColor: context.colors.black,
          txtColor: context.colors.primary,
          textSize: 18,
          maxHeight: 50,
          borderRadius: 50,
          text: "Confirm",
        ),
          ),
        ],
      ),
    );
  }
}
