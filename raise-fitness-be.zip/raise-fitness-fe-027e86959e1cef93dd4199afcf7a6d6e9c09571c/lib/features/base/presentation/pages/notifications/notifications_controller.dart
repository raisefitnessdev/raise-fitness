part of "notifications_imports.dart";

class NotificationsController {
  NotificationsController() {
    requestNotifications();
  }

  NotificationsRequester requester = NotificationsRequester();

  Future<void> requestNotifications() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }
}
