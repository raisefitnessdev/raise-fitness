part of "notifications_widgets_imports.dart";

class BuildNotificationCard extends StatelessWidget {
  final NotificationModel notification;
  const BuildNotificationCard({super.key, required this.notification});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14).r,
      decoration: BoxDecoration(
        color: context.colors.bgLight,
        borderRadius: BorderRadius.circular(10).r,
      ),
      child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 55.h,
              width: 55.w,
              decoration: BoxDecoration(
                color: context.colors.brown,
                borderRadius: BorderRadius.circular(8).r,
              ),
              child: Center(
                child: Image.asset(
                  Res.notifications,
                  height: 35.h,
                  width: 35.w,
                ),
              ),
            ),
            Gaps.hGap22,
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  notification.title ?? "",
                  style: AppTextStyle.s20_w700(
                    color: context.colors.noticesTextColor,
                  ),
                ),
                Gaps.vGap16,
                Text(
                  notification.details ?? "",
                  style: AppTextStyle.s14_w400(
                    color: context.colors.darkTextColor,
                  ),
                ),
              ],
            ),
            
          ]),
    );
  }
}
