import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/features/base/data/models/notification_model/notification_model.dart';
import 'package:raise/res.dart';

part "build_notification_card.dart";
