import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/requester/consumer/requester_consumer.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/default_app_bar.dart';
import 'package:raise/core/widgets/failure_view_widget.dart';
import 'package:raise/core/widgets/presist_bottom_bar/presist_bottom_bar_imports.dart';
import 'package:raise/core/widgets/shimmers/base_shimmer_widget.dart';
import 'package:raise/features/base/domain/requesters/notifications_requester.dart';
import 'package:raise/res.dart';

import 'widgets/notifications_widgets_imports.dart';

part "notifications.dart";
part "notifications_controller.dart";
