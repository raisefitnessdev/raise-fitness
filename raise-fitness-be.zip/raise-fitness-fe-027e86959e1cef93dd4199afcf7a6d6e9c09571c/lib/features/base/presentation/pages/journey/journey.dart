part of "journey_imports.dart";

@RoutePage(name: "JourneyRoute")
class Journey extends StatefulWidget {
  const Journey({super.key});

  @override
  State<Journey> createState() => _JourneyState();
}

class _JourneyState extends State<Journey> {
  final JourneyController controller = JourneyController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: const DefaultAppBar(
        title: "Bookings",
        showBack: true,
        actions: [
          NotificationWidget(),
        ],
      ),
      bottomNavigationBar: const PresistBottomBar(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.85,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(24).r,
            decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(50)).r,
            ),
            child: RequesterConsumer(
              requester: controller.requester,
              successBuilder: (context, data) {
                return data.isEmpty
                    ? Center(
                        child: Text(
                          "No classes booked yet!",
                          style: AppTextStyle.s18_w400(
                              color: context.colors.darkTextColor),
                        ))
                    : ListView.separated(
                              shrinkWrap: true,
                              scrollDirection: Axis.vertical,
                              padding: EdgeInsets.zero,
                              physics: const BouncingScrollPhysics(),
                              itemBuilder: (context, index) =>
                                  BuildJourneyCard(data: data[index], controller: controller,),
                              separatorBuilder: (context, index) => Gaps.vGap14,
                              itemCount: data.length);
              },
              loadingBuilder: (context) {
                return BaseShimmerWidget(
                        child: ListView.separated(
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            padding: EdgeInsets.zero,
                            physics: const BouncingScrollPhysics(),
                            itemBuilder: (context, index) => Container(
                                  width: MediaQuery.of(context).size.width,
                                  height: 130.h,
                                  decoration: BoxDecoration(
                                    color: context.colors.bgLight,
                                    borderRadius: BorderRadius.circular(10).r,
                                  ),
                                ),
                            separatorBuilder: (context, index) => Gaps.vGap14,
                            itemCount: 14),
                      );
              },
              failureBuilder: (context, error, callback) {
                return FailureViewWidget(onTap: callback);
              },
            ),
          ),
        ],
      ),
    );
  }
}
