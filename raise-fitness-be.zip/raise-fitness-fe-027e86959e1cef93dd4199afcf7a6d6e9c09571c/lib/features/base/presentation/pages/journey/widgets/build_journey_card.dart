part of "journey_widgets_imports.dart";

class BuildJourneyCard extends StatelessWidget {
  final BookingModel data;
  final JourneyController controller;
  const BuildJourneyCard({super.key, required this.data, required this.controller});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () =>
          AutoRouter.of(context).push(JourneyDetailsRoute(details: data)).then((v)=>controller.requestJourney()),
      child: Container(
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10).r,
        decoration: BoxDecoration(
          color: context.colors.bgLight,
          borderRadius: BorderRadius.circular(10).r,
        ),
        child: Stack(
          alignment: FractionalOffset.topRight,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CachedImage(
                  url: data.session?.coach?.image ?? "",
                  height: 70.h,
                  width: 60.w,
                  fit: BoxFit.fill,
                  borderRadius: BorderRadius.circular(8).r,
                ),
                Gaps.hGap14,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      data.session?.category?.title ?? "",
                      style: AppTextStyle.s16_w800(
                        color: context.colors.noticesTextColor,
                      ),
                    ),
                    Gaps.vGap8,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          data.session?.coach?.name ?? "",
                          style: AppTextStyle.s12_w500(
                            color: context.colors.blackOpacity,
                          ),
                        ),
                        Gaps.hGap32,
                        Text(
                          DateFormat("dd/MM/yyyy").format(DateTime.parse(
                              "${data.session?.selectedDate} ${data.session?.selectedTime}")),
                          style: AppTextStyle.s12_w500(
                            color: context.colors.blackOpacity,
                          ),
                        ),
                      ],
                    ),
                    Gaps.vGap8,
                    LimitedBox(
                      maxWidth: MediaQuery.of(context).size.width * 0.62,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.calendar_month,
                            size: 15.r,
                            color: context.colors.noticesTextColor,
                          ),
                          Gaps.hGap4,
                          Text(
                            DateFormat("hh:mm a").format(DateTime.parse(
                                "${data.session?.selectedDate} ${data.session?.selectedTime}")),
                            style: AppTextStyle.s12_w800(
                              color: context.colors.noticesTextColor,
                            ),
                          ),
                          // const Spacer(),
                          // SvgPicture.asset(
                          //   Res.spots,
                          //   height: 15.r,
                          //   width: 15.r,
                          //   fit: BoxFit.contain,
                          //   color: context.colors.noticesTextColor,
                          // ),
                          // Gaps.hGap3,
                          // Text(
                          //   "${(data.numberOfUsers ?? 0 - data.countedUsers!)} spots left",
                          //   style: AppTextStyle.s12_w800(
                          //     color: context.colors.noticesTextColor,
                          //   ),
                          // ),
                          Gaps.hGap14,
                          Icon(
                            Icons.alarm,
                            size: 15.r,
                            color: context.colors.noticesTextColor,
                          ),
                          Gaps.hGap4,
                          Text(
                            "${data.session?.numberOfMinutes}Min.",
                            style: AppTextStyle.s12_w800(
                              color: context.colors.noticesTextColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Visibility(
              visible: data.session?.ladiesOnly == 1,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4).r,
                decoration: BoxDecoration(
                  color: context.colors.primary,
                  borderRadius: BorderRadius.circular(30).r,
                ),
                child: Text(
                  "Ladies only",
                  style: AppTextStyle.s12_w700(
                    color: context.colors.noticesTextColor,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
