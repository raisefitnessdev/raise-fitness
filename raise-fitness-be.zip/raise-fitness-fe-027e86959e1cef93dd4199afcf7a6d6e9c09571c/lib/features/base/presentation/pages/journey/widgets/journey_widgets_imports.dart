import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/CachedImage.dart';
import 'package:raise/features/base/data/models/booking_model/booking_model.dart';
import 'package:raise/features/base/presentation/pages/journey/journey_imports.dart';

part "build_journey_card.dart";
