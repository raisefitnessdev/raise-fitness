part of "journey_imports.dart";

class JourneyController {
  JourneyController() {
    requestJourney();
  }

  MyClassesRequester requester = MyClassesRequester();

  Future<void> requestJourney() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }
}
