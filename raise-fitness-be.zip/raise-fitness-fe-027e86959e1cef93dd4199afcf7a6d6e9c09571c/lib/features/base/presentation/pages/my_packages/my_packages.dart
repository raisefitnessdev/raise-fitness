part of "my_packages_imports.dart";

@RoutePage(name: "MyPackagesRoute")
class MyPackages extends StatefulWidget {
  const MyPackages({super.key});

  @override
  State<MyPackages> createState() => _MyPackagesState();
}

class _MyPackagesState extends State<MyPackages> {
  final MyPackagesController controller = MyPackagesController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: const DefaultAppBar(
        title: "My Packages",
        showBack: true,
        actions: [
          NotificationWidget(),
        ],
      ),
      bottomNavigationBar: const PresistBottomBar(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.85,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(24).r,
            decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(50)).r,
            ),
            child: RequesterConsumer(
              requester: controller.requester,
              successBuilder: (context, data) {
                return data.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            "Subscribe to packages first!",
                            style: AppTextStyle.s18_w400(
                                color: context.colors.darkTextColor),
                          ),
                          Gaps.vGap20,
                          AppTextButton.minCustom(
                            onPressed: ()=>AutoRouter.of(context).push(Dashboard(index: 1)),
                            bgColor: context.colors.black,
                            txtColor: context.colors.primary,
                            textSize: 18,
                            maxHeight: 55,
                            borderRadius: 50,
                            text: "Buy Now",
                          ),
                        ],
                      ))
                    : ListView.separated(
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        padding: const EdgeInsets.only(bottom: 90).r,
                        physics: const BouncingScrollPhysics(),
                        itemBuilder: (context, index) =>
                            MyPackageCard(package: data[index]),
                        separatorBuilder: (context, index) => Gaps.vGap16,
                        itemCount: data.length);
              },
              loadingBuilder: (context) {
                return BaseShimmerWidget(
                  child: ListView.separated(
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      padding: EdgeInsets.zero,
                      physics: const BouncingScrollPhysics(),
                      itemBuilder: (context, index) => Container(
                            width: MediaQuery.of(context).size.width,
                            height: 200.h,
                            decoration: BoxDecoration(
                              color: context.colors.bgLight,
                              borderRadius: BorderRadius.circular(10).r,
                            ),
                          ),
                      separatorBuilder: (context, index) => Gaps.vGap16,
                      itemCount: 14),
                );
              },
              failureBuilder: (context, error, callback) {
                return FailureViewWidget(onTap: callback);
              },
            ),
          ),
        ],
      ),
    );
  }
}
