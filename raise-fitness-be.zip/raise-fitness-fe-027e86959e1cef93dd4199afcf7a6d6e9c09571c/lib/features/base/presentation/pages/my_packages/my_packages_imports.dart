import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/requester/consumer/requester_consumer.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/app_button.dart';
import 'package:raise/core/widgets/default_app_bar.dart';
import 'package:raise/core/widgets/failure_view_widget.dart';
import 'package:raise/core/widgets/presist_bottom_bar/presist_bottom_bar_imports.dart';
import 'package:raise/core/widgets/shimmers/base_shimmer_widget.dart';
import 'package:raise/features/base/domain/requesters/my_packages_requester.dart';
import 'package:raise/features/base/domain/requesters/packages_requester.dart';
import 'package:raise/features/base/presentation/widgets/base_app_bar.dart';
import 'package:raise/features/base/presentation/widgets/build_success_alert.dart';
import 'package:raise/features/base/presentation/widgets/notification_widget/notification_widget_imports.dart';
import 'package:raise/res.dart';

import 'widgets/my_packages_widgets_imports.dart';

part "my_packages.dart";
part "my_packages_controller.dart";
