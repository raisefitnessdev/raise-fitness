part of "my_packages_widgets_imports.dart";

class MyPackageCard extends StatelessWidget {
  final UserPackageModel package;
  const MyPackageCard({super.key, required this.package});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: Container(
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10).r,
        decoration: BoxDecoration(
          color: context.colors.bgLight,
          borderRadius: BorderRadius.circular(10).r,
        ),
        child: Stack(
          alignment: FractionalOffset.topRight,
          children: [
            Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Container(
                  //   height: 70.h,
                  //   width: 70.w,
                  //   decoration: BoxDecoration(
                  //     color: context.colors.white,
                  //     borderRadius: BorderRadius.circular(8).r,
                  //   ),
                  //   child: SvgPicture.asset(
                  //     Res.package,
                  //     height: 35.h,
                  //     width: 35.w,
                  //   ),
                  // ),
                  Gaps.vGap8,
                  Text(
                    package.package?.title ?? "",
                    style: AppTextStyle.s16_w700(
                      color: context.colors.noticesTextColor,
                    ),
                  ),
                  Gaps.vGap8,
                  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "Existing Class ${package.numberOfSessions}",
                          style: AppTextStyle.s12_w800(
                            color: context.colors.noticesTextColor,
                          ),
                        ),
                      ]),
                  Gaps.vGap8,
                  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "Used Class ${package.sessionUsed ?? 0}",
                          style: AppTextStyle.s12_w800(
                            color: context.colors.noticesTextColor,
                          ),
                        ),
                      ]),
                  Gaps.vGap8,
                  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "Available Class ${(package.numberOfSessions ?? 0) - (package.sessionUsed ?? 0)}",
                          style: AppTextStyle.s12_w800(
                            color: context.colors.noticesTextColor,
                          ),
                        ),
                      ]),
                  Gaps.vGap8,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Icon(
                      //   Icons.calendar_month,
                      //   size: 15.r,
                      //   color: context.colors.noticesTextColor,
                      // ),
                      // Gaps.hGap4,
                      Visibility(
                        visible: package.expireDate != null,
                        child: Text(
                          "Expires In ${package.expireDate ?? ""}",
                          style: AppTextStyle.s12_w800(
                            color: context.colors.noticesTextColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                ]),
            Visibility(
              visible: package.isFree == 1,
              child: SvgPicture.asset(
                Res.free,
                height: 30.r,
                width: 50.r,
                color: context.colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}