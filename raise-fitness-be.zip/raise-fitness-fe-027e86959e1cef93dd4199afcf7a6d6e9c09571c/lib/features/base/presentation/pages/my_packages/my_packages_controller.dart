part of "my_packages_imports.dart";

class MyPackagesController {
  MyPackagesController() {
    requestMyPackages();
  }

  MyPackagesRequester requester = MyPackagesRequester();

  Future<void> requestMyPackages() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }

  void showSuccessPackage(BuildContext context) {
    showDialog(
      context: context,
      builder: (cxt) {
        return BuildSuccessAlert(
          onTap: () => AutoRouter.of(context).push(const MyPackagesRoute()),
          isClass: false,
        );
      },
    );
  }
}
