import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:raise/core/bloc/base_bloc/base_bloc.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/requester/consumer/requester_consumer.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/theme/themes/app_theme.dart';
import 'package:raise/core/widgets/default_app_bar.dart';
import 'package:raise/core/widgets/failure_view_widget.dart';
import 'package:raise/core/widgets/shimmers/base_shimmer_widget.dart';
import 'package:raise/features/base/domain/requesters/classes_requester.dart';
import 'package:raise/features/base/presentation/widgets/base_app_bar.dart';
import 'package:raise/res.dart';

import 'widgets/home_widgets_imports.dart';

part "home.dart";
part "home_controller.dart";
