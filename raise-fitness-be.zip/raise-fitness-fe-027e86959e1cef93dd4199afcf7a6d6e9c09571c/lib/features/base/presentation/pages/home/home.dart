part of "home_imports.dart";

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final HomeController controller = HomeController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: const BaseAppBar(icon: Res.rumble),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.85,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(24).r,
            decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(50)).r,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BuildScrollableCalendar(controller: controller),
                Text(
                  "Select Class",
                  textAlign: TextAlign.start,
                  style: AppTextStyle.s16_w600(color: context.colors.textColor)
                      .copyWith(fontFamily: AppTheme.conthraxFamily),
                ),
                Expanded(
                  child: RequesterConsumer(
                    requester: controller.requester,
                    successBuilder: (context, data) {
                      return data.isEmpty
                          ? Center(
                              child: Text(
                              "No classes today!",
                              style: AppTextStyle.s18_w400(
                                  color: context.colors.darkTextColor),
                            ))
                          : ListView.separated(
                              shrinkWrap: true,
                              scrollDirection: Axis.vertical,
                              padding: const EdgeInsets.only(bottom: 100).r,
                              physics: const BouncingScrollPhysics(),
                              itemBuilder: (context, index) =>
                                  BuildClassCard(data: data[index]),
                              separatorBuilder: (context, index) => Gaps.vGap14,
                              itemCount: data.length);
                    },
                    loadingBuilder: (context) {
                      return BaseShimmerWidget(
                        child: ListView.separated(
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            padding: EdgeInsets.zero,
                            physics: const BouncingScrollPhysics(),
                            itemBuilder: (context, index) => Container(
                                  width: MediaQuery.of(context).size.width,
                                  height: 130.h,
                                  decoration: BoxDecoration(
                                    color: context.colors.bgLight,
                                    borderRadius: BorderRadius.circular(10).r,
                                  ),
                                ),
                            separatorBuilder: (context, index) => Gaps.vGap14,
                            itemCount: 14),
                      );
                    },
                    failureBuilder: (context, error, callback) {
                      return FailureViewWidget(onTap: callback);
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
