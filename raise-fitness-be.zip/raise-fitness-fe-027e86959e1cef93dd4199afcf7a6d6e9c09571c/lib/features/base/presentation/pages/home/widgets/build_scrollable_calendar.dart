part of "home_widgets_imports.dart";

class BuildScrollableCalendar extends StatelessWidget {
  final HomeController controller;
  const BuildScrollableCalendar({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return CustomCalendarTimeline(
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 14)),
      onDateSelected: (date) {
        controller.dateCubit.successState(date);
        controller.requestClasses();
      },
      leftMargin: 16.r,
      shrink: true,
      monthColor: context.colors.black,
      dayColor: context.colors.disableGray,
      activeDayColor: context.colors.primary,
      dayNameColor: context.colors.black,
      inactiveDayNameColor: context.colors.black,
      activeBackgroundDayColor: context.colors.black,
      dotsColor: context.colors.primary,
      locale: 'en_ISO',
    );
  }
}
