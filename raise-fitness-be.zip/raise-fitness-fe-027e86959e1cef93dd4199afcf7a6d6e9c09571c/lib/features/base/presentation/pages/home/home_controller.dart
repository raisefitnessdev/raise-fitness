part of "home_imports.dart";

class HomeController {
  HomeController() {
    dateCubit.successState(DateTime.now());
    requestClasses();
  }

  final BaseBloc<DateTime> dateCubit = BaseBloc(DateTime.now());

  late ClassesRequester requester =
      ClassesRequester(date: DateFormat("yyyy-MM-dd").format(dateCubit.data!));

  Future<void> requestClasses() async {
    requester
        .onChangeLocation(DateFormat("yyyy-MM-dd").format(dateCubit.data!));
    await requester.request(fromRemote: false);
    await requester.request();
  }
}
