part of "home_widgets_imports.dart";

class BuildClassCard extends StatelessWidget {
  final ClassModel data;
  const BuildClassCard({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () =>
          AutoRouter.of(context).push(ClassDetailsRoute(details: data)),
      child: Container(
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10).r,
        decoration: BoxDecoration(
          color: context.colors.bgLight,
          borderRadius: BorderRadius.circular(10).r,
        ),
        child: Stack(
          alignment: FractionalOffset.topRight,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CachedImage(
                  url: data.coach?.image ?? "",
                  height: 70.h,
                  width: 65.w,
                  borderRadius: BorderRadius.circular(8).r,
                ),
                Gaps.hGap14,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      data.category?.title ?? "",
                      style: AppTextStyle.s16_w800(
                        color: context.colors.noticesTextColor,
                      ),
                    ),
                    Gaps.vGap8,
                    Text(
                      data.coach?.name ?? "",
                      style: AppTextStyle.s12_w500(
                        color: context.colors.blackOpacity,
                      ),
                    ),
                    Gaps.vGap8,
                    LimitedBox(
                      maxWidth: MediaQuery.of(context).size.width * 0.45,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.watch_later_outlined,
                            size: 15.r,
                            color: context.colors.noticesTextColor,
                          ),
                          Gaps.hGap4,
                          Text(
                            DateFormat("hh:mm a").format(DateTime.parse(
                                "${data.selectedDate} ${data.selectedTime}")),
                            style: AppTextStyle.s12_w800(
                              color: context.colors.noticesTextColor,
                            ),
                          ),
                          // const Spacer(),
                          // SvgPicture.asset(
                          //   Res.spots,
                          //   height: 15.r,
                          //   width: 15.r,
                          //   fit: BoxFit.contain,
                          //   color: context.colors.noticesTextColor,
                          // ),
                          // Gaps.hGap3,
                          // Text(
                          //   "${(data.numberOfUsers ?? 0 - data.countedUsers!)} spots left",
                          //   style: AppTextStyle.s12_w800(
                          //     color: context.colors.noticesTextColor,
                          //   ),
                          // ),
                          Gaps.hGap14,
                          Icon(
                            Icons.alarm,
                            size: 15.r,
                            color: context.colors.noticesTextColor,
                          ),
                          Gaps.hGap4,
                          Text(
                            "${data.numberOfMinutes}Min.",
                            style: AppTextStyle.s12_w800(
                              color: context.colors.noticesTextColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Visibility(
                  visible: data.isBought ?? false,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4)
                            .r,
                    decoration: BoxDecoration(
                      color: context.colors.white,
                      border: Border.all(color: context.colors.black),
                    ),
                    child: Text(
                      "Booked",
                      style: AppTextStyle.s10_w400(
                        color: context.colors.black,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Visibility(
              visible: data.ladiesOnly == 1,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4).r,
                decoration: BoxDecoration(
                  color: context.colors.primary,
                  borderRadius: BorderRadius.circular(30).r,
                ),
                child: Text(
                  "Ladies only",
                  style: AppTextStyle.s12_w700(
                    color: context.colors.noticesTextColor,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
