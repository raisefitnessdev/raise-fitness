import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/CachedImage.dart';
import 'package:raise/core/widgets/custom_calendar/custom_calendar_timeline.dart';
import 'package:raise/features/base/data/models/class_model/class_model.dart';
import 'package:raise/features/base/presentation/pages/home/home_imports.dart';
import 'package:raise/res.dart';

part "build_scrollable_calendar.dart";
part "build_class_card.dart";
