part of 'dashboard_imports.dart';

@RoutePage()
class Dashboard extends StatefulWidget {
  final int index;
  const Dashboard({super.key, this.index = 0});

  @override
  State<StatefulWidget> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with TickerProviderStateMixin {
  late DashboardController controller = DashboardController();
  DateTime? currentBackPressTime;

  @override
  void initState() {
    controller.initBottomNavigation(this, widget.index);
    // NoticesRequester().request();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (_, v) {
        controller.changeSelectPage(0);
        DateTime now = DateTime.now();
        if (currentBackPressTime == null ||
            now.difference(currentBackPressTime ?? DateTime.now()) >
                const Duration(seconds: 2)) {
          currentBackPressTime = now;
          AppSnackBar.showSimpleToast(
            color: context.colors.black,
            msg: "Press twice to exit app",
            type: ToastType.success,
          );
        } else {
          SystemNavigator.pop();
        }
      },
      child: DefaultTabController(
        length: 4,
        initialIndex: widget.index,
        child: Scaffold(
          backgroundColor: context.colors.background,
          extendBody: true,
          body: TabBarView(
            physics: const NeverScrollableScrollPhysics(),
            controller: controller.tabController,
            children: const [
              Home(),
              Packages(),
              Profile(),
              More(),
            ],
          ),
          bottomNavigationBar: BottomNavBarWidget(
            controller: controller,
          ),
        ),
      ),
    );
  }
}
