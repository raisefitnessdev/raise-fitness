part of 'dashboard_imports.dart';

class DashboardController {
  late TabController tabController;
  final ObsValue<int> navigationBarObs = ObsValue<int>.withInit(0);

  List<String> tabs = [
    Res.calendar,
    Res.payment,
    Res.profile,
    Res.settings,
  ];

  List<String> titles = [
    "Home",
    "Packages",
    "Profile",
    "More",
  ];

  void initBottomNavigation(TickerProvider ticker, int index) {
    var context = getIt.get<GlobalContext>().context();
    tabController = TabController(
        length: 4,
        vsync: ticker,
        initialIndex: index);
    tabController.animateTo(index);
    navigationBarObs.setValue(index);
  }

  void changeSelectPage(int index) {
    tabController.animateTo(index);
    navigationBarObs.setValue(index);
  }
}
