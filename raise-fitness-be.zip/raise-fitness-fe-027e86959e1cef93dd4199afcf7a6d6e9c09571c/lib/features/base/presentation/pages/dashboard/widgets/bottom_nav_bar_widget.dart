part of 'dashboard_widgets_imports.dart';

class BottomNavBarWidget extends StatelessWidget {
  final DashboardController controller;
  const BottomNavBarWidget({
    super.key,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return ObsValueConsumer(
      observable: controller.navigationBarObs,
      builder: (context, value) {
        return Padding(
          padding: const EdgeInsets.all(24).r,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(100).r,
            child: AnimatedBottomNavigationBar.builder(
              itemCount: 4,
              onTap: (value) => controller.changeSelectPage(value),
              tabBuilder: (index, isActive) {
                return TabsItemWidget(
                  isActive: isActive,
                  title: controller.titles[index],
                  icon: controller.tabs[index],
                );
              },
              height: 70.h,
              activeIndex: value,
              backgroundColor: context.colors.backgroundLight,
              splashColor: context.colors.primary,
              gapLocation: GapLocation.none,
              splashSpeedInMilliseconds: 200,
            ),
          ),
        );
      },
    );
  }
}
