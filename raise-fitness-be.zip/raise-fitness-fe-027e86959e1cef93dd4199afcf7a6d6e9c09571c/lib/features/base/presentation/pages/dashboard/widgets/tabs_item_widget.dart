part of 'dashboard_widgets_imports.dart';

class TabsItemWidget extends StatelessWidget {
  final bool isActive;
  final String icon, title;
  const TabsItemWidget({
    super.key,
    required this.isActive,
    required this.icon,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 15).r,
      child: Visibility(
        visible: isActive,
        replacement: Container(
          height: 24.h,
          padding: const EdgeInsets.symmetric(vertical: 5).r,
          child: _getTabIcon(context, icon),
        ),
        child: Column(
          children: [
            Text(
              title,
              style: AppTextStyle.s14_w500(
                color: context.colors.primary,
              ),
            ),
            Gaps.vGap12,
            Icon(Icons.circle, size: 6.h, color: context.colors.primary,),
          ],
        ),
      ),
    );
  }

  StatelessWidget _getTabIcon(BuildContext context, icon) {
    return SvgPicture.asset(
      icon,
      height: 24.h,
      width: 24.w,
      fit: BoxFit.contain,
      color: context.colors.darkTextColor,
    );
  }
}
