import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:raise/core/bloc/base_bloc/base_bloc.dart';
import 'package:raise/core/bloc/value_state_manager/value_state_manager_import.dart';
import 'package:raise/core/helpers/app_snack_bar_service.dart';
import 'package:raise/core/helpers/di.dart';
import 'package:raise/core/helpers/global_context.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/features/auth/data/models/user_info_model/user_info_model.dart';
import 'package:raise/features/auth/domain/entity/login_params.dart';
import 'package:raise/features/base/presentation/pages/home/home_imports.dart';
import 'package:raise/features/base/presentation/pages/more/more_imports.dart';
import 'package:raise/features/base/presentation/pages/packages/packages_imports.dart';
import 'package:raise/features/base/presentation/pages/profile/profile_imports.dart';
import 'package:raise/res.dart';

import 'widgets/dashboard_widgets_imports.dart';

part 'dashboard.dart';
part 'dashboard_controller.dart';
