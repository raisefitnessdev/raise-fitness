import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/bloc/value_state_manager/value_state_manager_import.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/localization/translate.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/features/auth/data/models/user_info_model/user_info_model.dart';
import 'package:raise/features/base/presentation/pages/dashboard/dashboard_imports.dart';
import 'package:raise/res.dart';

part 'tabs_item_widget.dart';
part 'bottom_nav_bar_widget.dart';
