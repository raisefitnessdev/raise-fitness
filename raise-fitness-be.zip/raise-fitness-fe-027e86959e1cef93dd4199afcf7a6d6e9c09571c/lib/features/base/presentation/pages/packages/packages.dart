part of "packages_imports.dart";

class Packages extends StatefulWidget {
  const Packages({super.key});

  @override
  State<Packages> createState() => _PackagesState();
}

class _PackagesState extends State<Packages> {
  final PackagesController controller = PackagesController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: const BaseAppBar(icon: Res.rumble),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.85,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(24).r,
            decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(50)).r,
            ),
            child: RequesterConsumer(
              requester: controller.requester,
              successBuilder: (context, data) {
                return data.isEmpty? Center(child: Text("No packages found!", style: AppTextStyle.s18_w400(color: context.colors.darkTextColor),)) : ListView.separated(
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    padding: const EdgeInsets.only(bottom: 90).r,
                    physics: const BouncingScrollPhysics(),
                    itemBuilder: (context, index) =>
                         BuildPackageCard(package: data[index], controller: controller,),
                    separatorBuilder: (context, index) => Gaps.vGap16,
                    itemCount: data.length);
              },
              loadingBuilder: (context) {
                return BaseShimmerWidget(
                  child: ListView.separated(
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      padding: EdgeInsets.zero,
                      physics: const BouncingScrollPhysics(),
                      itemBuilder: (context, index) => Container(
                            width: MediaQuery.of(context).size.width,
                            height: 200.h,
                            decoration: BoxDecoration(
                              color: context.colors.bgLight,
                              borderRadius: BorderRadius.circular(10).r,
                            ),
                          ),
                      separatorBuilder: (context, index) => Gaps.vGap16,
                      itemCount: 14),
                );
              },
              failureBuilder: (context, error, callback) {
                return FailureViewWidget(onTap: callback);
              },
            ),
          ),
        ],
      ),
    );
  }
}
