part of "packages_widgets_imports.dart";

class PurchasePackageSheet extends StatelessWidget {
  final PackagesController controller;
  final PackageModel package;
  const PurchasePackageSheet(
      {super.key, required this.controller, required this.package});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: LimitedBox(
        maxHeight: MediaQuery.of(context).size.height * 0.6,
        maxWidth: MediaQuery.of(context).size.width,
        child: Container(
          decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30))
                  .r),
          child: Stack(
            alignment: FractionalOffset.topLeft,
            children: [
              ListView(
                padding: const EdgeInsets.all(24).r,
                shrinkWrap: true,
                children: [
                  Image.asset(
                    Res.logo,
                    height: 55,
                    width: 125,
                    color: context.colors.black,
                  ),
                  Gaps.vGap18,
                  Center(
                    child: Text(
                      package.title ?? "",
                      style: AppTextStyle.s18_w700(
                          color: context.colors.secondary),
                    ),
                  ),
                  Gaps.vGap24,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Classes",
                        style: AppTextStyle.s16_w700(
                            color: context.colors.secondary),
                      ),
                      Text(
                        "${package.numberOfSessions} Classes",
                        style: AppTextStyle.s16_w700(
                            color: context.colors.secondary),
                      ),
                    ],
                  ),
                  Gaps.vGap24,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Drop in",
                        style: AppTextStyle.s16_w700(
                            color: context.colors.secondary),
                      ),
                      Text(
                        "${package.price} QAR",
                        style: AppTextStyle.s16_w700(
                            color: context.colors.secondary),
                      ),
                    ],
                  ),
                  Gaps.vGap24,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Validaty",
                        style: AppTextStyle.s16_w700(
                            color: context.colors.secondary),
                      ),
                      Text(
                        "${package.validityDays} Days",
                        style: AppTextStyle.s16_w700(
                            color: context.colors.secondary),
                      ),
                    ],
                  ),
                  Gaps.vGap32,
                  RequesterConsumer(
                    requester: controller.profileRequester,
                    successBuilder: (context, user) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20).r,
                        child: AppTextButton.maxCustom(
                          bgColor: context.colors.secondary,
                          onPressed: () => controller.purchasePackage(
                              context, package, user),
                          txtColor: context.colors.primary,
                          textSize: 18,
                          maxHeight: 50,
                          borderRadius: 50,
                          text: "Checkout",
                        ),
                      );
                    },
                    loadingBuilder: (context) {
                      return BaseShimmerWidget(
                        child: Container(
                          height: 50,
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.symmetric(vertical: 20).r,
                          decoration: BoxDecoration(
                            color: context.colors.white,
                            borderRadius: BorderRadius.circular(50).r,
                          ),
                        ),
                      );
                    },
                    failureBuilder: (context, error, callback) {
                      return FailureViewWidget(onTap: callback);
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
