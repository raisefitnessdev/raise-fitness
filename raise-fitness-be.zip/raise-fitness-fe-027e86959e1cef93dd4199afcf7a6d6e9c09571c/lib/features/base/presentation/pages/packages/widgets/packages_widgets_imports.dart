import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/requester/consumer/requester_consumer.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/CachedImage.dart';
import 'package:raise/core/widgets/app_button.dart';
import 'package:raise/core/widgets/failure_view_widget.dart';
import 'package:raise/core/widgets/shimmers/base_shimmer_widget.dart';
import 'package:raise/features/base/data/models/package_model/package_model.dart';
import 'package:raise/features/base/presentation/pages/packages/packages_imports.dart';
import 'package:raise/res.dart';

part "build_package_card.dart";
part "purchase_package_sheet.dart";
