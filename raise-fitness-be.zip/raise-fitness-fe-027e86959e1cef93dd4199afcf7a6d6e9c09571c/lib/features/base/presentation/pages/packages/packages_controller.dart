part of "packages_imports.dart";

class PackagesController {
  PackagesController() {
    requestProfile();
    requestPackages();
  }

  PackagesRequester requester = PackagesRequester();
  ProfileRequester profileRequester = ProfileRequester();

  Future<void> requestProfile() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }

  Future<void> requestPackages() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }

  void purchasePackageSheet(BuildContext context, PackageModel package) {
    AppBottomSheets.showScrollableBody(
      context: context,
      builder: (context) {
        return PurchasePackageSheet(
          controller: this,
          package: package,
        );
      },
    );
  }

  Future<bool> purchasePackage(
      BuildContext context, PackageModel package, UserInfoModel user) async {
    if (user.isBoughtFreePackage == "1" && package.isFree == 1) {
      AppSnackBar.showSimpleToast(
        msg: "You already subscribed to free package",
        type: ToastType.error,
      );
      return false;
    } else {
      PurchasePackageParams params =
          purchasePackageParams(user.id!, package.id!);
      var packageResponse =
          await getIt<BaseRepository>().purchasePackage(params);
      return _handlePackageResponse(packageResponse, package: package);
    }
  }

  bool _handlePackageResponse(MyResult<UserPackageModel> response,
      {required PackageModel package}) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (value) {
      value!.isFree == 1
          ? activatePackage(orderId: value.id!)
          : AutoRouter.of(context).push(OnlinePaymentRoute(
              amount: package.price ?? "0", packageId: value.id!));
      return true;
    }, isError: (error) {
      return false;
    });
  }

  PurchasePackageParams purchasePackageParams(int userId, int packageId) {
    return PurchasePackageParams(
      userId: userId,
      packageId: packageId,
    );
  }

  Future<bool> activatePackage({required int orderId}) async {
    var codeResponse = await getIt<BaseRepository>().activatePackage(orderId);
    return _handlePayResponse(codeResponse);
  }

  bool _handlePayResponse(MyResult<String> response) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (data) {
      AppSnackBar.showSimpleToast(
        msg: "You subscribe package successfully",
        type: ToastType.success,
      );
      AutoRouter.of(context).push(Dashboard(index: 2));
      return true;
    }, isError: (error) {
      return false;
    });
  }
}
