part of "packages_widgets_imports.dart";

class BuildPackageCard extends StatelessWidget {
  final PackageModel package;
  final PackagesController controller;
  const BuildPackageCard(
      {super.key, required this.package, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10).r,
      decoration: BoxDecoration(
        color: context.colors.bgLight,
        borderRadius: BorderRadius.circular(10).r,
      ),
      child: Stack(
        alignment: FractionalOffset.topRight,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Container(
              //   height: 70.h,
              //   width: 70.w,
              //   decoration: BoxDecoration(
              //     color: context.colors.white,
              //     borderRadius: BorderRadius.circular(8).r,
              //   ),
              //   child: SvgPicture.asset(
              //     Res.package,
              //     height: 35.h,
              //     width: 35.w,
              //   ),
              // ),
              // Gaps.vGap8,
              Text(
                package.title ?? "",
                style: AppTextStyle.s16_w700(
                  color: context.colors.noticesTextColor,
                ),
              ),
              Gaps.vGap8,
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [

                  Text(
                    "${package.numberOfSessions} class",
                    style: AppTextStyle.s12_w800(
                      color: context.colors.noticesTextColor,
                    ),
                  ),
                ],
              ),
              Gaps.vGap8,
              Text(
                "Validity for ${package.validityDays} Days",
                style: AppTextStyle.s12_w800(
                  color: context.colors.noticesTextColor,
                ),
              ),
              Visibility(
                visible: package.isFree == 0,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Gaps.vGap8,
                    Text(
                      "${package.price} QAR",
                      style: AppTextStyle.s12_w800(
                        color: context.colors.noticesTextColor,
                      ),
                    ),
                  ],
                ),
              ),
              Gaps.vGap14,
              RequesterConsumer(
                requester: controller.profileRequester,
                successBuilder: (context, user) {
                  return AppTextButton.minCustom(
                    onPressed: user.isBoughtFreePackage == "1" && package.isFree == 1
                        ? (){} : () =>
                            controller.purchasePackageSheet(context, package),
                    bgColor: user.isBoughtFreePackage == "1" && package.isFree == 1
                        ? context.colors.greyWhite
                        : context.colors.black,
                    txtColor: context.colors.primary,
                    textSize: 16,
                    maxHeight: 40,
                    borderRadius: 50,
                    text: "Buy",
                  );
                },
                loadingBuilder: (context) {
                  return BaseShimmerWidget(
                    child: Container(
                      height: 50,
                      width: 120,
                      margin: const EdgeInsets.symmetric(vertical: 20).r,
                      decoration: BoxDecoration(
                        color: context.colors.white,
                        borderRadius: BorderRadius.circular(50).r,
                      ),
                    ),
                  );
                },
                failureBuilder: (context, error, callback) {
                  return FailureViewWidget(onTap: callback);
                },
              ),
            ],
          ),
          Visibility(
            visible: package.isFree == 1,
            child: SvgPicture.asset(
              Res.free,
              height: 30.r,
              width: 50.r,
              color: context.colors.red,
            ),
          ),
        ],
      ),
    );
  }
}
