part of "journey_details_widgets_imports.dart";

class BuildPackageDetails extends StatelessWidget {
  final PackageModel package;
  const BuildPackageDetails({super.key, required this.package});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Package",
          style: AppTextStyle.s16_w600(
            color: context.colors.noticesTextColor,
          ).copyWith(fontFamily: AppTheme.conthraxFamily),
        ),
        Gaps.vGap16,
        Text(
          package.title ?? "",
          style: AppTextStyle.s16_w700(
            color: context.colors.noticesTextColor,
          ),
        ),
        Gaps.vGap8,
        Text(
          "${package.numberOfSessions} class",
          style: AppTextStyle.s12_w800(
            color: context.colors.noticesTextColor,
          ),
        ),
        Gaps.vGap8,
        Text(
          "Validity for ${package.validityDays} Days",
          style: AppTextStyle.s12_w800(
            color: context.colors.noticesTextColor,
          ),
        ),
        Visibility(
          visible: package.isFree == 0,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Gaps.vGap8,
              Text(
                "${package.price} QAR",
                style: AppTextStyle.s12_w800(
                  color: context.colors.noticesTextColor,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
