import 'package:flutter/material.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/theme/themes/app_theme.dart';
import 'package:raise/core/widgets/app_button.dart';
import 'package:raise/features/base/data/models/booking_model/booking_model.dart';
import 'package:raise/features/base/data/models/package_model/package_model.dart';
import 'package:raise/features/base/presentation/pages/journey_details/journey_details_imports.dart';

part "build_journey_button.dart";
part "build_package_details.dart";
