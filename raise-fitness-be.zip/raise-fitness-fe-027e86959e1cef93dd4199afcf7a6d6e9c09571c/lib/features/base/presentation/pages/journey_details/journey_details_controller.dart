part of "journey_details_imports.dart";

class JourneyDetailsController {
  Future<bool> changeStatus(BuildContext context, int id, String status) async {
    ClassStatusParams params = classStatusParams(id, status);
    var statusResponse = await getIt<BaseRepository>().changeStatus(params);
    return _handleStatusResponse(statusResponse, classStatusParams: params);
  }

  bool _handleStatusResponse(MyResult<bool> response,
      {required ClassStatusParams classStatusParams}) {
    final context = getIt<GlobalContext>().context();
    return response.when(isSuccess: (value) {
      AppSnackBar.showSimpleToast(
        color: context.colors.black,
        msg: classStatusParams.status == "cancel"
            ? "Class cancelled successflly"
            : "Class reschaduled successfully",
        type: ToastType.success,
      );
      AutoRouter.of(context).popForced();
      return true;
    }, isError: (error) {
      return false;
    });
  }

  ClassStatusParams classStatusParams(int id, String status) {
    return ClassStatusParams(
      id: id,
      status: status,
    );
  }
}
