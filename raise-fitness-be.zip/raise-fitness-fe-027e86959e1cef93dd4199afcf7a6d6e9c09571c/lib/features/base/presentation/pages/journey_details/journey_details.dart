part of "journey_details_imports.dart";

@RoutePage(name: "JourneyDetailsRoute")
class JourneyDetails extends StatefulWidget {
  final BookingModel details;
  const JourneyDetails({super.key, required this.details});

  @override
  State<JourneyDetails> createState() => _JourneyDetailsState();
}

class _JourneyDetailsState extends State<JourneyDetails> {
  final JourneyDetailsController controller = JourneyDetailsController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: DefaultAppBar(
        title: widget.details.session?.category?.title ?? "",
        showBack: true,
        actions: const [
          NotificationWidget(),
        ],
      ),
      bottomNavigationBar: const PresistBottomBar(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.85,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(24).r,
            decoration: BoxDecoration(
              color: context.colors.white,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(50)).r,
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Gaps.vGap8,
                  BuildClassHeader(details: widget.details.session!),
                  Gaps.vGap32,
                  BuildClassDescription(details: widget.details.session!),
                  Gaps.vGap32,
                  BuildPackageDetails(package: widget.details.package!),
                  Gaps.vGap32,
                  BuildJourneyButton(details: widget.details, controller: controller,),
                  Gaps.vGap64,
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
