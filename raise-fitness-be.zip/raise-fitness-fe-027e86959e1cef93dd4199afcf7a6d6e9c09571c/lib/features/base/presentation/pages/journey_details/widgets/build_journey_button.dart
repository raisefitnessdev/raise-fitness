part of "journey_details_widgets_imports.dart";

class BuildJourneyButton extends StatelessWidget {
  final BookingModel details;
  final JourneyDetailsController controller;
  const BuildJourneyButton(
      {super.key, required this.details, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AppTextButton.maxCustom(
      onPressed: () => controller.changeStatus(context, details.id!,
          details.status == "active" ? "cancel" : "reschedule"),
      bgColor: context.colors.black,
      txtColor: context.colors.primary,
      textSize: 18,
      maxHeight: 50,
      borderRadius: 50,
      text: details.status == "active" ? "Cancel" : "Reschedule",
    );
  }
}
