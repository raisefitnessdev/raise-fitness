part of "settings_imports.dart";

@RoutePage(name: "SettingsRoute")
class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  final SettingsController controller = SettingsController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.colors.background,
      extendBody: true,
      extendBodyBehindAppBar: false,
      appBar: const DefaultAppBar(
        title: "Terms & Conditions",
        showBack: true,
        actions: [
          NotificationWidget(),
        ],
      ),
      bottomNavigationBar: const PresistBottomBar(),
      body: RequesterConsumer(
        requester: controller.requester,
        successBuilder: (context, data) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.85,
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.all(24).r,
                decoration: BoxDecoration(
                  color: context.colors.white,
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(50)).r,
                ),
                child: ListView(
                    padding: const EdgeInsets.only(bottom: 64).r,
                    children: [
                      Html(
                        data: data
                                .firstWhere((item) => item.key == "terms")
                                .details ??
                            "",
                        shrinkWrap: true,
                        style: {
                          "body": Style(
                            fontSize: FontSize(14.0),
                            fontWeight: FontWeight.w700,
                            fontFamily: AppTheme.fontFamily,
                            color: context.colors.black,
                          ),
                        },
                      ),
                    ]),
              ),
            ],
          );
        },
        loadingBuilder: (context) {
          return BaseShimmerWidget(
            child: Container(
              height: MediaQuery.of(context).size.height * 0.85,
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.all(24).r,
              decoration: BoxDecoration(
                color: context.colors.white,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(50)).r,
              ),
            ),
          );
        },
        failureBuilder: (context, error, callback) {
          return FailureViewWidget(onTap: callback);
        },
      ),
    );
  }
}
