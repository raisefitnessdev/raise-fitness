part of "settings_imports.dart";

class SettingsController {
  SettingsController() {
    requestSettings();
  }

  SettingsRequester requester = SettingsRequester();

  Future<void> requestSettings() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }
}
