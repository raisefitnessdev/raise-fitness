import 'package:auto_route/auto_route.dart';
import 'package:raise/core/routes/router_imports.gr.dart';

var baseRoute = [
  AdaptiveRoute(page: ClassDetailsRoute.page),
  AdaptiveRoute(page: MyPackagesRoute.page),
  AdaptiveRoute(page: EditProfileRoute.page),
  AdaptiveRoute(page: OnlinePaymentRoute.page),
  AdaptiveRoute(page: JourneyRoute.page),
  AdaptiveRoute(page: JourneyDetailsRoute.page),
  AdaptiveRoute(page: SettingsRoute.page),
  AdaptiveRoute(page: ContactUsRoute.page),
  AdaptiveRoute(page: FAQRoute.page),
  AdaptiveRoute(page: NotificationsRoute.page),
];
