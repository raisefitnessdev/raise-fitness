import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/constants/gaps.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/app_button.dart';
import 'package:raise/res.dart';

class BuildConfirmAlert extends StatelessWidget {
  final VoidCallback onTap;
  const BuildConfirmAlert({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: context.colors.white,
      shadowColor: context.colors.white,
      surfaceTintColor: context.colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24).r,
      ),
      alignment: Alignment.center,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16).r,
      content: Padding(
        padding: const EdgeInsets.all(24).r,
        child: Text(
          "Are you sure?",
          softWrap: true,
          textAlign: TextAlign.center,
          style: AppTextStyle.s16_w700(color: context.colors.secondary),
        ),
      ),
      actions: [
        Row(
          children: [
            Expanded(
              child: AppTextButton.maxCustom(
                onPressed: onTap,
                txtColor: context.colors.white,
                textSize: 16.sp,
                maxHeight: 55.h,
                borderRadius: 50.r,
                text: "Confirm",
                bgColor: context.colors.secondary,
              ),
            ),
            Gaps.hGap16,
            Expanded(
              child: AppTextButton.maxCustom(
                onPressed: () => AutoRouter.of(context).popForced(),
                txtColor: context.colors.secondary,
                textSize: 16.sp,
                maxHeight: 55.h,
                borderRadius: 50.r,
                text: "Cancel",
                bgColor: context.colors.white,
                borderColor: context.colors.secondary,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
