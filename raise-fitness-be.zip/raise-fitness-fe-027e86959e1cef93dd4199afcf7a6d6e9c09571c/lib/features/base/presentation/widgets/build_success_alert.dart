import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/app_button.dart';
import 'package:raise/res.dart';

class BuildSuccessAlert extends StatelessWidget {
  final VoidCallback onTap;
  final bool isClass;
  const BuildSuccessAlert(
      {super.key, required this.onTap, required this.isClass});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: context.colors.white,
      shadowColor: context.colors.white,
      surfaceTintColor: context.colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24).r,
      ),
      alignment: Alignment.center,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16).r,
      title: SvgPicture.asset(Res.success,
          height: 150.r, width: 150.r, fit: BoxFit.contain),
      content: Padding(
        padding: const EdgeInsets.all(24).r,
        child: Text(
          isClass
              ? "Success\nYour booking is confirmed."
              : "Package Successfully Purchased",
          softWrap: true,
          textAlign: TextAlign.center,
          style: AppTextStyle.s16_w700(color: context.colors.secondary),
        ),
      ),
      actions: [
        AppTextButton.maxCustom(
          onPressed: onTap,
          txtColor: context.colors.white,
          textSize: 16.sp,
          maxHeight: 55.h,
          borderRadius: 50.r,
          text: isClass ? "Bookings" : "My Packages",
          bgColor: context.colors.secondary,
        ),
      ],
    );
  }
}
