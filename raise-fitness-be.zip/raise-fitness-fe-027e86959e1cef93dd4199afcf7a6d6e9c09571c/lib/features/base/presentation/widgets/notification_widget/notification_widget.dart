part of "notification_widget_imports.dart";

class NotificationWidget extends StatefulWidget {
  const NotificationWidget({super.key});

  @override
  State<NotificationWidget> createState() => _NotificationWidgetState();
}

class _NotificationWidgetState extends State<NotificationWidget> {
  final NotificationWidgetController controller =
      NotificationWidgetController();

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => AutoRouter.of(context).push(const NotificationsRoute()),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8).r,
        child: RequesterConsumer(
          requester: controller.requester,
          successBuilder: (context, count) {
            return Stack(
              alignment: FractionalOffset.topRight,
              children: [
                Container(
                  height: 45.h,
                  width: 45.w,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: context.colors.black),
                  child: Center(
                    child: SvgPicture.asset(
                      Res.notification,
                      height: 20.h,
                      width: 20.w,
                    ),
                  ),
                ),
                Visibility(
                  visible: count > 0,
                  child: Icon(
                    Icons.circle,
                    color: context.colors.red,
                    size: 12.r,
                  ),
                ),
              ],
            );
          },
          loadingBuilder: (context) {
            return BaseShimmerWidget(
              child: Container(
                height: 45.h,
                width: 45.w,
                decoration: BoxDecoration(
                    shape: BoxShape.circle, color: context.colors.black),
                child: Center(
                  child: SvgPicture.asset(
                    Res.notification,
                    height: 20.h,
                    width: 20.w,
                  ),
                ),
              ),
            );
          },
          failureBuilder: (context, error, callback) {
            return InkWell(
              onTap: () =>
                  AutoRouter.of(context).push(const NotificationsRoute()),
              child: Container(
                height: 45.h,
                width: 45.w,
                decoration: BoxDecoration(
                    shape: BoxShape.circle, color: context.colors.black),
                child: Center(
                  child: SvgPicture.asset(
                    Res.notification,
                    height: 20.h,
                    width: 20.w,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
