import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/requester/consumer/requester_consumer.dart';
import 'package:raise/core/routes/router_imports.gr.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/core/theme/text/app_text_style.dart';
import 'package:raise/core/widgets/shimmers/base_shimmer_widget.dart';
import 'package:raise/features/base/domain/requesters/notifications_count_requester.dart';
import 'package:raise/res.dart';

part "notification_widget.dart";
part "notification_widget_controller.dart";
