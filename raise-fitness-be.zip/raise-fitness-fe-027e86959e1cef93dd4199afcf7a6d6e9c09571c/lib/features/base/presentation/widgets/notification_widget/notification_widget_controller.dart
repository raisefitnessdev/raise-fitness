part of "notification_widget_imports.dart";

class NotificationWidgetController {
  NotificationWidgetController() {
    requestNotificationsCount();
  }

  NotificationsCountRequester requester = NotificationsCountRequester();

  Future<void> requestNotificationsCount() async {
    await requester.request(fromRemote: false);
    await requester.request();
  }
}