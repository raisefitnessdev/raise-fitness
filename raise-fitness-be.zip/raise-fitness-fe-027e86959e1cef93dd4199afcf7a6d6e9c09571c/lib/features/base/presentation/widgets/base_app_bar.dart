import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:raise/core/theme/colors/colors_extension.dart';
import 'package:raise/features/base/presentation/widgets/notification_widget/notification_widget_imports.dart';
import 'package:raise/res.dart';

class BaseAppBar extends StatelessWidget implements PreferredSizeWidget {
  final bool showBack;
  final String? icon;
  const BaseAppBar({
    super.key,
    this.showBack = false,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Image.asset(
        icon ?? Res.logo,
        height: 70.h,
        width: 200.w,
      ),
      centerTitle: true,
      systemOverlayStyle:
          const SystemUiOverlayStyle(statusBarBrightness: Brightness.light),
      backgroundColor: context.colors.background,
      elevation: 0,
      automaticallyImplyLeading: false,
      shadowColor: context.colors.background,
      foregroundColor: context.colors.background,
      surfaceTintColor: context.colors.background,
      leading: Visibility(
        visible: showBack == true,
        child: InkWell(
          onTap: () => Navigator.of(context).pop(),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Icon(
              Icons.arrow_back_ios_outlined,
              color: context.colors.textColor,
              size: 24,
            ),
          ),
        ),
      ),
      actions: const [
        NotificationWidget(),
      ],
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(65.h);
}
